# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 167.99.71.62 (MySQL 5.7.28-0ubuntu0.18.04.4)
# Database: mc_mizu
# Generation Time: 2020-01-21 02:28:50 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table quiz
# ------------------------------------------------------------

DROP TABLE IF EXISTS `quiz`;

CREATE TABLE `quiz` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `ref_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT 'Parent ID',
  `option1` varchar(255) DEFAULT NULL,
  `option2` varchar(255) DEFAULT NULL,
  `option3` varchar(255) DEFAULT NULL,
  `option4` varchar(255) DEFAULT NULL,
  `option5` varchar(255) DEFAULT NULL,
  `option6` varchar(255) DEFAULT NULL,
  `another` tinyint(1) DEFAULT '0',
  `priority` int(11) NOT NULL DEFAULT '0',
  `language` varchar(10) NOT NULL DEFAULT 'en',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Deleted At',
  `created_user_id` bigint(20) unsigned NOT NULL,
  `updated_user_id` bigint(20) unsigned NOT NULL,
  `deleted_user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`title`),
  KEY `category_ref_id` (`ref_id`),
  KEY `create_user_id` (`created_user_id`) USING BTREE,
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `quiz` WRITE;
/*!40000 ALTER TABLE `quiz` DISABLE KEYS */;

INSERT INTO `quiz` (`id`, `ref_id`, `title`, `option1`, `option2`, `option3`, `option4`, `option5`, `option6`, `another`, `priority`, `language`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_user_id`, `updated_user_id`, `deleted_user_id`)
VALUES
	(1,1,'How can you get the total number of arguments passed to a function?','Using args.length property','Using arguments.length property','Both of the above.','None of the above.',NULL,NULL,NULL,0,'vi',1,'2020-01-10 06:37:21','2020-01-21 02:00:30','2020-01-21 02:00:30',19,19,NULL),
	(2,2,'Which built-in method removes the last element from an array and returns that element?','last()','get()','pop()',NULL,NULL,NULL,1,0,'vi',1,'2020-01-10 06:38:51','2020-01-21 02:00:30','2020-01-21 02:00:30',19,356,NULL),
	(3,3,'III. KỸ NĂNG TẬP HUẤN','Các góp ý, nhận xét khác','Hướng dẫn thực hành tài liệu dành cho học sinh','Phương pháp giáo dục tích cực',NULL,NULL,NULL,0,0,'vi',1,'2020-01-21 02:02:10','2020-01-21 02:02:10',NULL,19,19,NULL),
	(4,4,'II. CHÚNG TA CÓ THỂ LÀM GÌ','HĐ 1: Điệu nhảy rửa tay','HĐ 2: Hùng biện tôi là nước','HĐ 3: Thực hành rửa tay đúng cách và tiết kiệm nước','HĐ 4: Xem phim Tôi yêu nước sạch','HĐ 5: Thí nghiệm lọc nước',NULL,0,0,'vi',1,'2020-01-21 02:15:21','2020-01-21 02:15:21',NULL,19,19,NULL),
	(5,5,'I. NƯỚC BỊ LÀM SAO THẾ','HĐ 1: Các loại nước có trong tự nhiên','HĐ 2: Vòng tuần hoàn nước','HĐ 3: Vai trò của nước trong cuộc sống','HĐ 4: Thực trạng tài nguyên nước','HĐ 5: Hãy tiết kiệm nước',NULL,0,0,'vi',1,'2020-01-21 02:16:48','2020-01-21 02:16:48',NULL,19,19,NULL),
	(6,6,'E. KẾT QUẢ','Tôi đã được chuẩn bị tốt để tham gia một cách chủ động vào khoá học.','Tôi đã thu nhận được những kiến thức cần thiết liên quan đến chủ đề chính của khoá học.','Tôi đã thu nhận được những kinh nghiệm bổ ích từ khóa học.','Tôi cảm thấy thoải mái trong việc áp dụng kiến thức và kỹ năng thu được vào việc dạy học của mình và chia sẻ với người khác.','Tôi tin rằng khoá học đã đạt được các kết quả dự kiến.',NULL,1,0,'vi',1,'2020-01-21 02:18:43','2020-01-21 02:18:43',NULL,19,19,NULL),
	(7,7,'C. PHƯƠNG PHÁP GIẢNG DẠY VÀ GIẢNG VIÊN','Phương pháp giảng dạy là phù hợp để truyền tải nội dung khoá học.','Giảng viên có các kỹ năng cần thiết để thu hút học viên.',NULL,NULL,NULL,NULL,1,0,'vi',1,'2020-01-21 02:24:07','2020-01-21 02:24:07',NULL,19,19,NULL),
	(8,8,'B. NỘI DUNG VÀ THỜI LƯỢNG','Thời lượng của khoá học e-learning là phù hợp với nội dung.','Các chủ đề chính của khoá học đã được trình bày với bố cục tốt, cụ thể và có trọng tâm.','Các bài giảng gần gũi, dễ hiểu.',NULL,NULL,NULL,1,0,'vi',1,'2020-01-21 02:24:36','2020-01-21 02:24:36',NULL,19,19,NULL),
	(9,9,'A. MỤC TIÊU','Mục tiêu của khóa học đã đạt được qua hoạt động của khóa học.',NULL,NULL,NULL,NULL,NULL,0,0,'vi',1,'2020-01-21 02:24:55','2020-01-21 02:24:55',NULL,19,19,NULL);

/*!40000 ALTER TABLE `quiz` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
