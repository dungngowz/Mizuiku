# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 167.99.71.62 (MySQL 5.7.28-0ubuntu0.18.04.4)
# Database: mc_mizu
# Generation Time: 2019-12-17 02:14:33 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table articles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `articles`;

CREATE TABLE `articles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `ref_id` int(10) unsigned DEFAULT NULL COMMENT 'Article REF ID',
  `category_id` int(10) unsigned DEFAULT NULL COMMENT 'Category ID',
  `title` varchar(255) NOT NULL COMMENT 'Title of article',
  `slug` varchar(255) NOT NULL COMMENT 'Slug',
  `thumbnail` varchar(255) DEFAULT NULL,
  `description` text,
  `content` text COMMENT 'Content of article',
  `keyword` varchar(255) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `language` varchar(10) NOT NULL COMMENT 'Language',
  `views` int(11) DEFAULT '0',
  `video_duration` varchar(11) DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Created At',
  `created_user_id` bigint(20) unsigned NOT NULL COMMENT 'Created User ID',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  `updated_user_id` bigint(20) unsigned NOT NULL COMMENT 'Updated User ID',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Deleted At',
  `deleted_user_id` bigint(20) unsigned DEFAULT NULL COMMENT 'Deleted User ID',
  PRIMARY KEY (`id`),
  KEY `created_user_id` (`created_user_id`),
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`),
  KEY `category_id` (`category_id`),
  KEY `article_ref_id` (`ref_id`) USING BTREE,
  CONSTRAINT `articles_ibfk_4` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;

INSERT INTO `articles` (`id`, `ref_id`, `category_id`, `title`, `slug`, `thumbnail`, `description`, `content`, `keyword`, `status`, `url`, `priority`, `language`, `views`, `video_duration`, `created_at`, `created_user_id`, `updated_at`, `updated_user_id`, `deleted_at`, `deleted_user_id`)
VALUES
	(1,1,NULL,'Trung tâm sống và học tập vì môi trường và cộng đồng (Live & Learn)','trung-tam-song-va-hoc-tap-vi-moi-truong-va-cong-dong-live-learn',NULL,'','Trung tâm Sống và Học tập vì Môi trường và Cộng đồng (Live & Learn) là một tổ chức phi lợi nhuận, phi chính phủ, được thành lập theo quyết định 60/QĐ–LHH ngày 15 tháng 1 năm 2009 của Liên hiệp các Hội Khoa học và Kỹ thuật Việt Nam và giấy phép số A-804 của Bộ Khoa học Công nghệ.\r\nLive & Learn là tổ chức hội viên của mạng lưới Live and Learn Environmental Education International – một mạng lưới quốc tế có trụ sở chính tại Úc, hoạt động từ năm 1992 với mục tiêu thúc đẩy nhận thức và hành động của cộng đồng vì một tương lai bền vững thông qua giáo dục, đối thoại và phát triển (http://www.livelearn.org).\r\nTại Việt Nam, Live & Learn hướng tới xây dựng và thực hiện các dự án, chương trình dành cho giáo viên, trường học, cộng đồng và các nhóm đối tượng khác về giáo dục môi trường và phát triển; qua đó thúc đẩy thái độ, giá trị và hành động đúng đắn của cá nhân và cộng đồng vì một môi trường bền vững. Năm 2016, Live & Learn vinh dự là tổ chức Việt Nam duy nhất nhận được giải thưởng quốc tế Stars Impact cho các chương trình với trẻ em và thanh niên.\r\nLive & Learn sớm tham gia cùng Tập đoàn Suntory và Công ty Suntory PepsiCo Việt Nam từ năm đầu triển khai thí điểm chương trình Mizuiku tại Việt Nam (2015). Live & Learn duy trì vai trò là Đơn vị Đồng hành cùng chương trình Mizuiku và phụ trách chuyên môn giáo dục môi trường của chương trình tại khu vực phía Bắc. ','co-organizingboard',1,'',0,'vi',0,'0','2019-12-04 10:15:11',1,'2019-12-05 07:21:14',1,NULL,NULL),
	(2,1,NULL,'Live & Learn','live-learn',NULL,'','Center of Live & Learn for Environment and Community (Live & Learn Center)Center of Live & Learn for Environment and Community (Live &Learn Centeris a non-profit, non-government organization established under Decision 60/QD-LHH dated 15th of January 2009 issued by Vietnam Union of Science and Technology associations and the A-804 licensefrom the Ministry of Science and Technology.\r\n\r\nLive & Learn is a member organization of the Australian-based Live and Learn Environmental Edcational International Network, which has been operating since 1992 with the goal of promoting community awareness and action for a sustainable future through education, dialogue and development (http://www.livelearn.org).\r\n\r\nIn Vietnam, Live & Learn aims to develop and implement programs and program for teachers, schools, communities and other groups in environmental education and development, thereby, promoting the right attitudes, values and actions of individuals and communities for a sustainable environment. In 2016, Live & Learn was honored to be the only Vietnamese organization to receive the International Stars Impact Award for their programs with children and the youth.\r\n\r\nLive & Learn joined hand with Suntory and Suntory PepsiCo Vietnam Beverage onpiloting of the Mizuiku program in Vietnam (2015). Live & Learn maintains its role as a co-implementing partner to the Mziuiku program and is responsible for the environmental education of the program in the North.','co-organizingboard',1,'',0,'en',0,'0','2019-12-04 10:15:11',1,'2019-12-05 07:21:40',1,NULL,NULL),
	(3,3,NULL,'Giới thiệu chương trình','gioi-thieu-chuong-trinh',NULL,'Chương trình “Mizuiku” là sáng kiến tuyên truyền, giáo dục ý thức bảo vệ tài nguyên nước cho học sinh bậc tiểu học được khởi xướng bởi Tập đoàn Suntory và đã triển khai thành công tại Nhật Bản từ năm 2004. Đến nay, chương trình đã thu hút sự tham gia của trên 145 nghìn học sinh tiểu học và phụ huynh, nhận được đánh giá cao từ cộng đồng và xã hội Nhật Bản.','<div class=\"noidung TextSize\">Chương tr&igrave;nh &ldquo;Mizuiku&rdquo; l&agrave; s&aacute;ng kiến tuy&ecirc;n truyền, gi&aacute;o dục &yacute;</div>\r\n<div class=\"noidung TextSize\"><img src=\"http://127.0.0.1:8000/photos/1/Screen Shot 2019-12-07 at 05.00.00.png\" alt=\"\" width=\"100%\" /> thức bảo vệ t&agrave;i nguy&ecirc;n nước cho học sinh bậc tiểu học được khởi xướng bởi Tập đo&agrave;n Suntory v&agrave; đ&atilde; triển khai th&agrave;nh c&ocirc;ng tại Nhật Bản từ năm 2004. Đến nay, Dự &aacute;n đ&atilde; thu h&uacute;t sự tham gia của tr&ecirc;n 127 ngh&igrave;n học sinh tiểu học v&agrave; phụ huynh, nhận được đ&aacute;nh gi&aacute; cao từ cộng đồng v&agrave; x&atilde; hội Nhật Bản.<br />Trước thực tế c&oacute; tới 20% d&acirc;n số Việt Nam hiện chưa từng được tiếp cận với nguồn nước sạch.&nbsp;Trong đ&oacute;, nhiều v&ugrave;ng bị thiếu nước sạch trầm trọng như Bến Tre, Bắc Ninh v&agrave; ngay cả c&aacute;c th&agrave;nh phố lớn như H&agrave; Nội, TP.HCM &ndash; đặc biệt v&agrave;o m&ugrave;a kh&ocirc; (Thống k&ecirc; của Viện Y học Lao động v&agrave; Vệ sinh m&ocirc;i trường), &nbsp;Tập đo&agrave;n Suntory v&agrave; Suntory PepsiCo Việt Nam đ&atilde; triển khai chương tr&igrave;nh Mizuiku &ndash; Em y&ecirc;u nước sạch từ năm 2015 đến nay tại Việt Nam với mong muốn lan tỏa giải ph&aacute;p bền vững gi&uacute;p bảo vệ nguồn nước th&ocirc;ng qua việc cung cấp kiến thức bảo vệ nước sạch đến thế hệ tương lai của Việt Nam<em>.</em>\r\n<div style=\"text-align: center;\"><img style=\"width: 600px;\" src=\"http://127.0.0.1:8000/pic/AboutUs/images/IMG_0002.jpg\" alt=\"\" /></div>\r\nChương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; hướng tới mục ti&ecirc;u n&acirc;ng cao nhận thức của c&aacute;c em học sinh tiểu học về vai tr&ograve; của t&agrave;i nguy&ecirc;n nước v&agrave; c&aacute;ch thức sử dụng hợp l&yacute; nguồn nước sạch, g&oacute;p phần bảo vệ nguồn nước v&agrave; rộng hơn l&agrave; m&ocirc;i trường sống xung quanh. Th&ocirc;ng qua phương ph&aacute;p gi&aacute;o dục lấy học sinh l&agrave;m trung t&acirc;m, chương tr&igrave;nh tạo ra kh&ocirc;ng gian s&aacute;ng tạo, cơ hội thực h&agrave;nh v&agrave; s&acirc;n chơi đa dạng cho c&aacute;c em nhỏ nhằm k&iacute;ch th&iacute;ch &oacute;c quan s&aacute;t, &yacute; tưởng v&agrave; h&agrave;nh động của c&aacute;c em để bảo vệ nguồn nước n&oacute;i ri&ecirc;ng v&agrave; m&ocirc;i trường n&oacute;i chung.<br />&nbsp;<br />Năm 2015-2016, chương tr&igrave;nh được triển khai th&iacute; điểm tại Huyện Thanh Oai v&agrave; Mỹ Đức, H&agrave; Nội, sau đ&oacute; mở rộng ra tỉnh Bắc Ninh v&agrave; Tp. Hồ Ch&iacute; Minh th&ocirc;ng qua sự phối hợp giữa Tập đo&agrave;n Suntory, C&ocirc;ng ty TNHH Nước giải kh&aacute;t Suntory PepsiCo Việt Nam v&agrave; 02 đối t&aacute;c chuy&ecirc;n về gi&aacute;o dục m&ocirc;i trường l&agrave; Trung t&acirc;m Sống v&agrave; Học tập v&igrave; M&ocirc;i trường &amp; Cộng đồng (Live &amp; Learn) v&agrave; Trung t&acirc;m Gi&aacute;o dục Sức khỏe &amp; Ph&aacute;t triển Cộng đồng Tương Lai (Trung t&acirc;m Tương Lai). Qua 3 năm triển khai, chương tr&igrave;nh đ&atilde; tổ chức &nbsp;hơn 660 lớp học cho gần 10.100 học sinh; 26 Ng&agrave;y hội nước cho hơn 11.600 học sinh v&agrave; gi&aacute;o vi&ecirc;n, 25 chuyến tham quan nh&agrave; m&aacute;y Suntory PepsiCo Việt Nam cho 2.500 học sinh v&agrave; gi&aacute;o vi&ecirc;n; x&acirc;y dựng, cải tạo cơ sở vật chất, hệ thống lọc nước tại 26 trường tiểu học tham gia chương tr&igrave;nh. H&agrave;ng ngh&igrave;n học sinh, thầy c&ocirc; gi&aacute;o v&agrave; người d&acirc;n tại c&aacute;c địa phương cũng được hưởng lợi từ hoạt động của chương tr&igrave;nh.\r\n<div style=\"text-align: center;\"><img style=\"width: 600px; height: 460px;\" src=\"http://127.0.0.1:8000/pic/AboutUs/images/Cac%20em%20hoc%20sinh%20duoc%20hoc%20ve%20quy%20trinh%20xu%20ly%20nuoc%20thai%20thong%20qua%20cac%20tro%20choi.JPG\" alt=\"\" /></div>\r\n<br />Từ năm 2017, chương tr&igrave;nh bước sang giai đoạn ph&aacute;t triển mới với mối quan hệ hợp t&aacute;c chiến lược của Tập đo&agrave;n Suntory, c&ocirc;ng ty Nước Giải kh&aacute;t Suntory PepsiCo Việt Nam, Hội đồng Đội Trung ương, Trung Ương Hội Sinh vi&ecirc;n Việt Nam, sự hỗ trợ từ Bộ Gi&aacute;o dục &amp; Đ&agrave;o tạo c&ugrave;ng sự đồng h&agrave;nh về mặt chuy&ecirc;n m&ocirc;n của Trung t&acirc;m Live &amp; Learn v&agrave; Trung t&acirc;m Tương Lai. Với cơ sở đối t&aacute;c vững mạnh, chương tr&igrave;nh mong muốn đẩy mạnh hiệu quả của c&aacute;c hợp phần gi&aacute;o dục, hỗ trợ đồng thời mở rộng v&ugrave;ng thụ hưởng ra phạm vi to&agrave;n quốc.<br /><img style=\"width: 600px;\" src=\"http://127.0.0.1:8000/pic/AboutUs/images/C%C3%A1c%20c%C3%B4%20gi%C3%A1o%20v%C3%A0%20h%E1%BB%8Dc%20sinh%20tr%C6%B0%E1%BB%9Dng%20ti%C3%AAu%20h%E1%BB%8Dc%20B%E1%BA%BFn%20Tre%20h%E1%BA%BFt%20m%C3%ACnh%20trong%20ti%E1%BA%BFt%20h%E1%BB%8Dc%20m%E1%BA%ABu%20c%E1%BB%A7a%20bu%E1%BB%95i%20l%E1%BB%85%20ph%C3%A1t%20%C4%91%E1%BB%99ng%20ch%C6%B0%C6%A1ng%20tr%C3%ACnh%20Mizuiku%20-%20Em%20y%C3%AAu%20n%C6%B0%E1%BB%9Bc%20s%E1%BA%A1ch.jpg\" alt=\"\" />\r\n<div style=\"text-align: center;\">&nbsp;<img style=\"width: 500px; height: 667px;\" src=\"http://127.0.0.1:8000/pic/AboutUs/images/Dong%20song%20que%20em%20MHX.jpg\" alt=\"\" /></div>\r\nChương tr&igrave;nh hi vọng hi vọng đ&oacute;ng g&oacute;p v&agrave;o sự ph&aacute;t triển t&acirc;m hồn v&agrave; thể chất của c&aacute;c em học sinh để g&oacute;p phần bảo tồn v&ograve;ng tuần ho&agrave;n nước cho thế hệ mai sau.<br />&nbsp;<br />&nbsp;<br /><strong><span style=\"font-size: 14.0pt;\">Hoạt động chương tr&igrave;nh: </span></strong><br />&nbsp;<br />\r\n<ul>\r\n<li>Lễ Khởi&nbsp;động chương tr&igrave;nh</li>\r\n<li>Tổ chức tập huấn (TOT) cho gi&aacute;o vi&ecirc;n Tổng phụ tr&aacute;ch Đội, gi&aacute;o vi&ecirc;n chủ nhiệm khối 3-4 tại c&aacute;c trường được lựa chọn triển khai Chương tr&igrave;nh, bồi dưỡng kỹ năng dạy học th&iacute;ch hợp để thực hiện c&aacute;c hoạt động gi&aacute;o dục m&ocirc;i trường v&agrave; c&aacute;c hoạt động ngoại kh&oacute;a về chủ đề nước theo gi&aacute;o &aacute;n ri&ecirc;ng của chương tr&igrave;nh Mizuiku.</li>\r\n<li>Tổ chức giảng dạy cho học sinh khối 3, 4 c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh, gi&aacute;o dục m&ocirc;i trường về chủ đề nước theo gi&aacute;o &aacute;n của chương tr&igrave;nh Mizuiku, trong đ&oacute; mang đến cho c&aacute;c em học sinh kiến thức về c&aacute;c loại nước, v&ograve;ng tuần ho&agrave;n nước, vai tr&ograve; của nước trong cuộc sống, vấn đề của nước h&ocirc;m nay v&agrave; t&aacute;c động của những vấn đề nước đối với cuộc sống, x&acirc;y dựng th&oacute;i quen tiết kiệm nước, bảo vệ m&ocirc;i trường; thực h&agrave;nh th&iacute; nghiệm lọc nước v&agrave; nhiều b&agrave;i tập thực h&agrave;nh kh&aacute;c.</li>\r\n<li>C&aacute;c cuộc thi ph&aacute;t động tr&ecirc;n phạm vi to&agrave;n quốc theo chủ đề bảo vệ m&ocirc;i trường, bảo vệ nguồn nước.</li>\r\n<li>Ng&agrave;y hội Hiệp sĩ Nước sạch tổ chức tại c&aacute;c trường thụ hưởng Chương tr&igrave;nh với nội dung v&agrave; h&igrave;nh thức sinh động như tr&ograve; chơi tương t&aacute;c, t&igrave;m hiểu kiến thức về nước, thi h&ugrave;ng biện v&igrave; m&ocirc;i trường, thi s&aacute;ng kiến m&ocirc; h&igrave;nh bảo vệ m&ocirc;i trường.</li>\r\n<li>Tham quan nh&agrave; m&aacute;y Suntory PepsiCo Việt Nam cho học sinh khối 3, 4 c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh. Tại đ&acirc;y, c&aacute;c em được nghe giới thiệu về nh&agrave; m&aacute;y, quy tr&igrave;nh xử l&yacute; chất thải đạt chuẩn, tham quan d&acirc;y chuyền sản xuất, thực h&agrave;nh th&iacute; nghiệm lọc nước, l&agrave;m nước rửa ch&eacute;n tự nhi&ecirc;n.</li>\r\n<li>Hỗ trợ cơ sở vật chất nước sạch tại c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh, bao gồm những hạng mục hỗ trợ ph&ugrave; hợp để x&acirc;y dựng, lắp đặt hệ thống lọc nước RO, x&acirc;y dựng mới hoặc sửa chữa, n&acirc;ng cấp nh&agrave; vệ sinh cho học sinh, sơn tường c&ocirc;ng tr&igrave;nh, v.v&hellip;</li>\r\n<li>Ra mắt Website v&agrave; hệ thống học tập trực tuyến E-learning để gia tăng cơ hội tiếp cận của c&aacute;c em học sinh tr&ecirc;n to&agrave;n quốc đối với kiến thức bảo vệ nguồn nước v&agrave; c&aacute;c b&agrave;i giảng th&uacute; vị do chương tr&igrave;nh x&acirc;y dựng.</li>\r\n</ul>\r\n</div>','program-introduction',1,'',0,'vi',0,'0','2019-12-04 10:15:11',1,'2019-12-07 04:17:12',1,NULL,NULL),
	(4,3,NULL,'\"Mizuiku - I love clean water\" program introduction','mizuiku-i-love-clean-water-program introduction',NULL,NULL,'<p>Chương tr&igrave;nh &ldquo;Mizuiku&rdquo; l&agrave; s&aacute;ng kiến tuy&ecirc;n truyền, gi&aacute;o dục &yacute; thức bảo vệ t&agrave;i nguy&ecirc;n nước cho học sinh bậc tiểu học được khởi xướng bởi Tập đo&agrave;n Suntory v&agrave; đ&atilde; triển khai th&agrave;nh c&ocirc;ng tại Nhật Bản từ năm 2004. Đến nay, Dự &aacute;n đ&atilde; thu h&uacute;t sự tham gia của tr&ecirc;n 127 ngh&igrave;n học sinh tiểu học v&agrave; phụ huynh, nhận được đ&aacute;nh gi&aacute; cao từ cộng đồng v&agrave; x&atilde; hội Nhật Bản. Trước thực tế c&oacute; tới 20% d&acirc;n số Việt Nam hiện chưa từng được tiếp cận với nguồn nước sạch. Trong đ&oacute;, nhiều v&ugrave;ng bị thiếu nước sạch trầm trọng như Bến Tre, Bắc Ninh v&agrave; ngay cả c&aacute;c th&agrave;nh phố lớn như H&agrave; Nội, TP.HCM &ndash; đặc biệt v&agrave;o m&ugrave;a kh&ocirc; (Thống k&ecirc; của Viện Y học Lao động v&agrave; Vệ sinh m&ocirc;i trường), Tập đo&agrave;n Suntory v&agrave; Suntory PepsiCo Việt Nam đ&atilde; triển khai chương tr&igrave;nh Mizuiku &ndash; Em y&ecirc;u nước sạch từ năm 2015 đến nay tại Việt Nam với mong muốn lan tỏa giải ph&aacute;p bền vững gi&uacute;p bảo vệ nguồn nước th&ocirc;ng qua việc cung cấp kiến thức bảo vệ nước sạch đến thế hệ tương lai của Việt Nam. Chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; hướng tới mục ti&ecirc;u n&acirc;ng cao nhận thức của c&aacute;c em học sinh tiểu học về vai tr&ograve; của t&agrave;i nguy&ecirc;n nước v&agrave; c&aacute;ch thức sử dụng hợp l&yacute; nguồn nước sạch, g&oacute;p phần bảo vệ nguồn nước v&agrave; rộng hơn l&agrave; m&ocirc;i trường sống xung quanh. Th&ocirc;ng qua phương ph&aacute;p gi&aacute;o dục lấy học sinh l&agrave;m trung t&acirc;m, chương tr&igrave;nh tạo ra kh&ocirc;ng gian s&aacute;ng tạo, cơ hội thực h&agrave;nh v&agrave; s&acirc;n chơi đa dạng cho c&aacute;c em nhỏ nhằm k&iacute;ch th&iacute;ch &oacute;c quan s&aacute;t, &yacute; tưởng v&agrave; h&agrave;nh động của c&aacute;c em để bảo vệ nguồn nước n&oacute;i ri&ecirc;ng v&agrave; m&ocirc;i trường n&oacute;i chung. Năm 2015-2016, chương tr&igrave;nh được triển khai th&iacute; điểm tại Huyện Thanh Oai v&agrave; Mỹ Đức, H&agrave; Nội, sau đ&oacute; mở rộng ra tỉnh Bắc Ninh v&agrave; Tp. Hồ Ch&iacute; Minh th&ocirc;ng qua sự phối hợp giữa Tập đo&agrave;n Suntory, C&ocirc;ng ty TNHH Nước giải kh&aacute;t Suntory PepsiCo Việt Nam v&agrave; 02 đối t&aacute;c chuy&ecirc;n về gi&aacute;o dục m&ocirc;i trường l&agrave; Trung t&acirc;m Sống v&agrave; Học tập v&igrave; M&ocirc;i trường &amp; Cộng đồng (Live &amp; Learn) v&agrave; Trung t&acirc;m Gi&aacute;o dục Sức khỏe &amp; Ph&aacute;t triển Cộng đồng Tương Lai (Trung t&acirc;m Tương Lai). Qua 3 năm triển khai, chương tr&igrave;nh đ&atilde; tổ chức hơn 660 lớp học cho gần 10.100 học sinh; 26 Ng&agrave;y hội nước cho hơn 11.600 học sinh v&agrave; gi&aacute;o vi&ecirc;n, 25 chuyến tham quan nh&agrave; m&aacute;y Suntory PepsiCo Việt Nam cho 2.500 học sinh v&agrave; gi&aacute;o vi&ecirc;n; x&acirc;y dựng, cải tạo cơ sở vật chất, hệ thống lọc nước tại 26 trường tiểu học tham gia chương tr&igrave;nh. H&agrave;ng ngh&igrave;n học sinh, thầy c&ocirc; gi&aacute;o v&agrave; người d&acirc;n tại c&aacute;c địa phương cũng được hưởng lợi từ hoạt động của chương tr&igrave;nh. Từ năm 2017, chương tr&igrave;nh bước sang giai đoạn ph&aacute;t triển mới với mối quan hệ hợp t&aacute;c chiến lược của Tập đo&agrave;n Suntory, c&ocirc;ng ty Nước Giải kh&aacute;t Suntory PepsiCo Việt Nam, Hội đồng Đội Trung ương, Trung Ương Hội Sinh vi&ecirc;n Việt Nam, sự hỗ trợ từ Bộ Gi&aacute;o dục &amp; Đ&agrave;o tạo c&ugrave;ng sự đồng h&agrave;nh về mặt chuy&ecirc;n m&ocirc;n của Trung t&acirc;m Live &amp; Learn v&agrave; Trung t&acirc;m Tương Lai. Với cơ sở đối t&aacute;c vững mạnh, chương tr&igrave;nh mong muốn đẩy mạnh hiệu quả của c&aacute;c hợp phần gi&aacute;o dục, hỗ trợ đồng thời mở rộng v&ugrave;ng thụ hưởng ra phạm vi to&agrave;n quốc. Chương tr&igrave;nh hi vọng hi vọng đ&oacute;ng g&oacute;p v&agrave;o sự ph&aacute;t triển t&acirc;m hồn v&agrave; thể chất của c&aacute;c em học sinh để g&oacute;p phần bảo tồn v&ograve;ng tuần ho&agrave;n nước cho thế hệ mai sau. Hoạt động chương tr&igrave;nh: Lễ Khởi động chương tr&igrave;nh Tổ chức tập huấn (TOT) cho gi&aacute;o vi&ecirc;n Tổng phụ tr&aacute;ch Đội, gi&aacute;o vi&ecirc;n chủ nhiệm khối 3-4 tại c&aacute;c trường được lựa chọn triển khai Chương tr&igrave;nh, bồi dưỡng kỹ năng dạy học th&iacute;ch hợp để thực hiện c&aacute;c hoạt động gi&aacute;o dục m&ocirc;i trường v&agrave; c&aacute;c hoạt động ngoại kh&oacute;a về chủ đề nước theo gi&aacute;o &aacute;n ri&ecirc;ng của chương tr&igrave;nh Mizuiku. Tổ chức giảng dạy cho học sinh khối 3, 4 c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh, gi&aacute;o dục m&ocirc;i trường về chủ đề nước theo gi&aacute;o &aacute;n của chương tr&igrave;nh Mizuiku, trong đ&oacute; mang đến cho c&aacute;c em học sinh kiến thức về c&aacute;c loại nước, v&ograve;ng tuần ho&agrave;n nước, vai tr&ograve; của nước trong cuộc sống, vấn đề của nước h&ocirc;m nay v&agrave; t&aacute;c động của những vấn đề nước đối với cuộc sống, x&acirc;y dựng th&oacute;i quen tiết kiệm nước, bảo vệ m&ocirc;i trường; thực h&agrave;nh th&iacute; nghiệm lọc nước v&agrave; nhiều b&agrave;i tập thực h&agrave;nh kh&aacute;c. C&aacute;c cuộc thi ph&aacute;t động tr&ecirc;n phạm vi to&agrave;n quốc theo chủ đề bảo vệ m&ocirc;i trường, bảo vệ nguồn nước. Ng&agrave;y hội Hiệp sĩ Nước sạch tổ chức tại c&aacute;c trường thụ hưởng Chương tr&igrave;nh với nội dung v&agrave; h&igrave;nh thức sinh động như tr&ograve; chơi tương t&aacute;c, t&igrave;m hiểu kiến thức về nước, thi h&ugrave;ng biện v&igrave; m&ocirc;i trường, thi s&aacute;ng kiến m&ocirc; h&igrave;nh bảo vệ m&ocirc;i trường. Tham quan nh&agrave; m&aacute;y Suntory PepsiCo Việt Nam cho học sinh khối 3, 4 c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh. Tại đ&acirc;y, c&aacute;c em được nghe giới thiệu về nh&agrave; m&aacute;y, quy tr&igrave;nh xử l&yacute; chất thải đạt chuẩn, tham quan d&acirc;y chuyền sản xuất, thực h&agrave;nh th&iacute; nghiệm lọc nước, l&agrave;m nước rửa ch&eacute;n tự nhi&ecirc;n. Hỗ trợ cơ sở vật chất nước sạch tại c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh, bao gồm những hạng mục hỗ trợ ph&ugrave; hợp để x&acirc;y dựng, lắp đặt hệ thống lọc nước RO, x&acirc;y dựng mới hoặc sửa chữa, n&acirc;ng cấp nh&agrave; vệ sinh cho học sinh, sơn tường c&ocirc;ng tr&igrave;nh, v.v&hellip; Ra mắt Website v&agrave; hệ thống học tập trực tuyến E-learning để gia tăng cơ hội tiếp cận của c&aacute;c em học sinh tr&ecirc;n to&agrave;n quốc đối với kiến thức bảo vệ nguồn nước v&agrave; c&aacute;c b&agrave;i giảng th&uacute; vị do chương tr&igrave;nh x&acirc;y dựng.</p>','program-introduction',1,'',0,'en',0,'0','2019-12-04 10:15:11',1,'2019-12-07 03:32:33',1,NULL,NULL),
	(12,12,NULL,'General introduction about E-learning course','general-introduction-about-e-learning course',NULL,NULL,'Để góp phần lan tỏa mạnh mẽ hơn thông điệp, ý nghĩa của chương trình “Mizuiku – Em yêu nước sạch”, khóa học trực tuyến E-learning dành cho giáo viên tiểu học và bất cứ ai quan tâm tới vấn đề bảo vệ tài nguyên nước nói riêng và môi trường nói chung được chính thức công bố.\r\nMục tiêu của khóa học:\r\nGiúp học viên nắm rõ mục đích và nội dung, kiến thức về tài nguyên nước, tìm hiểu hiện trạng, cách tiết kiệm và bảo vệ tài nguyên nước theo giáo án của chương trình “Mizuiku – Em yêu nước sạch”\r\nGóp phần nâng cao năng lực trong công tác giảng dạy học sinh về tiết kiệm và bảo vệ nguồn tài nguyên nước theo phương pháp giáo dục tích cực.\r\nTạo điều kiện cho học viên có thể áp dụng triển khai các mô hình lớp học theo giáo án của chương trình “Mizuiku – Em yêu nước sạch” dành cho trẻ em tại trường học và cộng đồng.','e-learning',1,'',0,'en',0,'0','2019-12-04 10:15:11',1,'2019-12-10 15:56:58',1,NULL,NULL),
	(13,12,NULL,'Giới thiệu chung về khóa học E-learning','gioi-thieu-chung-ve-khoa-hoc-e-learning',NULL,'Mo ta chua nhap','<p>Để g&oacute;p phần lan tỏa mạnh mẽ hơn th&ocirc;ng điệp, &yacute; nghĩa của chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo;, kh&oacute;a học trực tuyến E-learning d&agrave;nh cho gi&aacute;o vi&ecirc;n tiểu học v&agrave; bất cứ ai quan t&acirc;m tới vấn đề bảo vệ t&agrave;i nguy&ecirc;n nước n&oacute;i ri&ecirc;ng v&agrave; m&ocirc;i trường n&oacute;i chung được ch&iacute;nh thức c&ocirc;ng bố. Mục ti&ecirc;u của kh&oacute;a học: Gi&uacute;p học vi&ecirc;n nắm r&otilde; mục đ&iacute;ch v&agrave; nội dung, kiến thức về t&agrave;i nguy&ecirc;n nước, t&igrave;m hiểu hiện trạng, c&aacute;ch tiết kiệm v&agrave; bảo vệ t&agrave;i nguy&ecirc;n nước theo gi&aacute;o &aacute;n của chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; G&oacute;p phần n&acirc;ng cao năng lực trong c&ocirc;ng t&aacute;c giảng dạy học sinh về tiết kiệm v&agrave; bảo vệ nguồn t&agrave;i nguy&ecirc;n nước theo phương ph&aacute;p gi&aacute;o dục t&iacute;ch cực. Tạo điều kiện cho học vi&ecirc;n c&oacute; thể &aacute;p dụng triển khai c&aacute;c m&ocirc; h&igrave;nh lớp học theo gi&aacute;o &aacute;n của chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; d&agrave;nh cho trẻ em tại trường học v&agrave; cộng đồng.</p>','e-learning',1,'',0,'vi',3,'0','2019-12-04 10:15:11',1,'2019-12-12 07:14:56',1,NULL,NULL),
	(14,14,NULL,'Điều khoản sử dụng','dieu-khoan-su-dung',NULL,NULL,'<p>Xin vui l&ograve;ng đọc kỹ c&aacute;c Điều khoản Sử dụng dưới đ&acirc;y trước khi sử dụng trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn Trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn, sau đ&acirc;y được gọi l&agrave; &ldquo;website&rdquo; được sở hữu v&agrave; vận h&agrave;nh bởi c&ocirc;ng ty TNHH Nước Giải kh&aacute;t Suntory PepsiCo Việt Nam, sau đ&acirc;y được gọi l&agrave; &ldquo;Suntory PepsiCo&rdquo;, hoặc &ldquo;ch&uacute;ng t&ocirc;i&rdquo;. Bằng việc truy cập v&agrave; sử dụng website n&agrave;y, bạn c&ocirc;ng nhận rằng bạn đ&atilde; đọc, hiểu v&agrave; nhất tr&iacute; với việc tu&acirc;n thủ quy định của những Điều khoản Sử dụng. Suntory PepsiCo c&oacute; to&agrave;n quyền thay đổi nội dung của website cũng như c&aacute;c Điều khoản Sử dụng n&agrave;y v&agrave;o bất kỳ thời điểm n&agrave;o m&agrave; kh&ocirc;ng c&oacute; nghĩa vụ th&ocirc;ng b&aacute;o với bạn. Bạn n&ecirc;n thường xuy&ecirc;n truy cập website để cập nhật về c&aacute;c thay đổi. Bạn đồng &yacute; rằng việc bạn tiếp tục sử dụng website đồng nghĩa với việc bạn đồng &yacute; với những Điều khoản Sử dụng cập nhật nhất tại thời điểm đ&oacute;. VIỆC SỬ DỤNG WEBSITE CỦA BẠN Bạn đồng &yacute; sẽ kh&ocirc;ng sử dụng website cho những mục đích bất hợp ph&aacute;p theo quy định của ph&aacute;p luật Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam hay bị cấm bởi c&aacute;c Điều khoản Sử dụng hay bất cứ điều luật li&ecirc;n quan n&agrave;o kh&aacute;c. Bạn c&oacute; thể truy cập, xem, sao ch&eacute;p v&agrave; tải c&aacute;c nội dung tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc mục đ&iacute;ch phi thương mại với điều kiện bạn kh&ocirc;ng sửa đổi hay x&oacute;a bỏ c&aacute;c bản quyền, thương hiệu c&oacute; tr&ecirc;n c&aacute;c t&agrave;i liệu m&agrave; bạn truy cập, xem, sao ch&eacute;p v&agrave; tải từ website n&agrave;y. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c bao gồm nhưng kh&ocirc;ng giới hạn trong sao ch&eacute;p, sửa đổi, ph&acirc;n phối, truyền, tải, cấp ph&eacute;p, hay tạo ra c&aacute;c biến thể từ c&aacute;c nội dung thu được từ website n&agrave;y m&agrave; kh&ocirc;ng được sự đồng &yacute; bằng văn bản của Suntory PepsiCo đều bị nghi&ecirc;m cấm. Bạn đồng &yacute; kh&ocirc;ng x&acirc;m phạm quyền, giới hạn hoặc ngăn cấm người kh&aacute;c sử dụng website n&agrave;y. Bạn sẽ kh&ocirc;ng can thiệp, x&acirc;m phạm hay ph&aacute; hoại bất kỳ chức năng an ninh n&agrave;o của website n&agrave;y hay kh&ocirc;ng gửi bất kỳ th&ocirc;ng tin hay phần mềm n&agrave;o c&oacute; chứa bất kỳ loại virus, Trojan, s&acirc;u hay bất kỳ th&agrave;nh phần nguy hại n&agrave;o qua website n&agrave;y. NỘI DUNG BẠN CUNG CẤP Bạn đảm bảo rằng bạn sẽ chịu tr&aacute;ch nhiệm trước ph&aacute;p luật với bất kỳ nội dung n&agrave;o m&agrave; bạn đăng tải tr&ecirc;n website n&agrave;y bao gồm t&iacute;nh hợp ph&aacute;p, t&iacute;nh ch&iacute;nh x&aacute;c, ph&ugrave; hợp v&agrave; bản quyền đối với nội dung đ&oacute;. Với việc cung cấp nội dung cho Suntory PepsiCo, bạn đồng &yacute; trao cho ch&uacute;ng t&ocirc;i to&agrave;n bộ quyền v&agrave; cấp ph&eacute;p sử dụng, t&aacute;i sản xuất, chỉnh sửa, l&agrave;m cho ph&ugrave; hợp, xuất bản, dịch, tạo ra c&aacute;c phi&ecirc;n bản kh&aacute;c, ph&acirc;n phối v&agrave; trưng b&agrave;y nội dung được bạn cung cấp tr&ecirc;n phạm vi to&agrave;n cầu bằng bất cứ phương tiện truyền th&ocirc;ng n&agrave;o m&agrave; kh&ocirc;ng đ&ograve;i hỏi th&ugrave; lao. Bạn trao cho ch&uacute;ng t&ocirc;i quyền được sử dụng t&ecirc;n gọi m&agrave; bạn cung cấp li&ecirc;n quan đến nội dung được bạn đăng tải khi cần thiết. Tất cả th&ocirc;ng tin c&aacute; nh&acirc;n được cung cấp tr&ecirc;n website n&agrave;y sẽ được sử dụng v&agrave; quản l&yacute; theo đ&uacute;ng Ch&iacute;nh s&aacute;ch Bảo mật của website n&agrave;y. Bạn bảo đảm rằng bạn sở hữu hoặc c&oacute; tất cả c&aacute;c quyền ph&aacute;p l&yacute; đối với nội dung bạn cung cấp tr&ecirc;n website n&agrave;y; rằng nội dung bạn cung cấp l&agrave; ch&iacute;nh x&aacute;c; rằng việc sử dụng nội dung bạn cung cấp kh&ocirc;ng vi phạm bất kỳ điều khoản n&agrave;o được quy định trong bản Điều khoản sử dụng n&agrave;y v&agrave; sẽ kh&ocirc;ng g&acirc;y ra tổn thất cho bất kỳ ai; rằng bạn sẽ loại trừ ch&uacute;ng t&ocirc;i khỏi tất cả c&aacute;c khiếu nại xuất ph&aacute;t từ nội dung m&agrave; bạn cung cấp. QUYỀN SỞ HỮU TR&Iacute; TUỆ Tất cả c&aacute;c bản quyền, thương hiệu hay bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o thuộc website n&agrave;y đều thuộc sở hữu của Suntory PepsiCo hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ trường hợp được quy định trong bản Điều khoản Sử dụng n&agrave;y, việc bạn truy cập, sử dụng website n&agrave;y kh&ocirc;ng đồng nghĩa với việc trao cho bạn bất kỳ quyền sở hữu hay cấp ph&eacute;p cho bạn đối với bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o n&ecirc;u tr&ecirc;n. Bạn được ph&eacute;p sử dụng bất kỳ nội dung hay t&agrave;i liệu tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc phi thương mại. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c phải c&oacute; c&oacute; sự cho ph&eacute;p bằng văn bản của ch&uacute;ng t&ocirc;i hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ khi được quy định trong Điều khoản quy định n&agrave;y, bất cứ h&agrave;nh vi sử dụng t&agrave;i liệu hay nội dung n&agrave;o thuộc website n&agrave;y, bao gồm sao ch&eacute;p, t&aacute;i sản xuất, truyền, ph&acirc;n phối, khai th&aacute;c cho mục đ&iacute;ch thương mại hay tạo ra c&aacute;c biến thể kh&aacute;c đều bị nghi&ecirc;m cấm. Website n&agrave;y v&agrave; tất cả nội dung thuộc website được bảo hộ theo quy định của Luật Sở hữu tr&iacute; tuệ Việt Nam v&agrave; c&aacute;c văn bản luật li&ecirc;n quan. TỪ CHỐI ĐẢM BẢO BẠN ĐỒNG &Yacute; RẰNG VIỆC SỬ DỤNG WEBSITE N&Agrave;Y THUỘC PHẠM TR&Ugrave; RỦI RO CỦA RI&Ecirc;NG BẠN V&Agrave; KH&Ocirc;NG THUỘC TR&Aacute;CH NHIỆM CỦA CH&Uacute;NG T&Ocirc;I. WEBSITE N&Agrave;Y V&Agrave; NỘI DUNG TR&Ecirc;N WEBSITE N&Agrave;Y, BAO GỒM NHƯNG KH&Ocirc;NG GIỚI HẠN Ở C&Aacute;C TH&Ocirc;NG TIN, T&Agrave;I LIỆU, THIẾT KẾ, ĐỒ HỌA, GIAO DIỆN, H&Igrave;NH ẢNH, M&Atilde; CODE, PHẦN MỀM, NH&Atilde;N HIỆU, T&Ecirc;N THƯƠNG MẠI, C&Aacute;C LOGO, CŨNG NHƯ SẢN PHẨM, DỊCH VỤ THUỘC SỞ HỮU HAY LI&Ecirc;N QUAN ĐẾN SUNTORY PEPSICO HAY BẤT KỲ B&Ecirc;N THỨ BA N&Agrave;O ĐƯỢC CUNG CẤP CHO BẠN TR&Ecirc;N CƠ SỞ &ldquo;NHƯ ĐANG C&Oacute;&rdquo; V&Agrave; CH&Uacute;NG T&Ocirc;I TỪ CHỐI MỌI BẢO ĐẢM THEO BẤT KỲ PHƯƠNG THỨC N&Agrave;O, D&Ugrave; L&Agrave; H&Agrave;M &Yacute; HAY C&Ocirc;NG BỐ, BAO GỒM NHƯNG KH&Ocirc;NG CHỈ GIỚI HẠN TRONG C&Aacute;C BẢO ĐẢM VỀ KHẢ NĂNG B&Aacute;N SẢN PHẨM, CHẤT LƯỢNG, SỰ PH&Ugrave; HỢP VỚI MỘT MỤC Đ&Iacute;CH CỤ THỂ N&Agrave;O Đ&Oacute;, SỰ KH&Ocirc;NG VI PHẠM, SỰ TƯƠNG TH&Iacute;CH, SỰ AN TO&Agrave;N, CH&Iacute;NH X&Aacute;C HAY HO&Agrave;N CHỈNH CỦA BẤT KỲ NỘI DUNG N&Agrave;O TR&Ecirc;N WEBSITE N&Agrave;Y. NGOẠI TRỪ ĐƯỢC QUY ĐỊNH BỞI PH&Aacute;P LUẬT, CH&Uacute;NG T&Ocirc;I KH&Ocirc;NG ĐẢM BẢO RẰNG NỘI DUNG THUỘC WEBSITE N&Agrave;Y, HAY BẤT KỲ T&Iacute;NH NĂNG N&Agrave;O CỦA WEBSITE N&Agrave;Y SẼ KH&Ocirc;NG BỊ GI&Aacute;N ĐOẠN, KH&Ocirc;NG C&Oacute; LỖI, KH&Ocirc;NG C&Oacute; VIRUS, HAY SẼ LU&Ocirc;N TƯƠNG TH&Iacute;CH VỚI BẤT KỲ PHẦN MỀM HAY NỘI DUNG N&Agrave;O KH&Aacute;C. GIỚI HẠN TR&Aacute;CH NHIỆM PH&Aacute;P L&Yacute; Trong bất kỳ trường hợp n&agrave;o, Suntory PepsiCo cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i cũng kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; cho bất kỳ tổn thất n&agrave;o, d&ugrave; l&agrave; trực tiếp, gi&aacute;n tiếp, đặc biệt, bất ngờ, hoặc l&agrave; hậu quả của sự kiện kh&aacute;c, bao gồm nhưng kh&ocirc;ng giới hạn trong c&aacute;c thiệt hại trong kinh doanh hoặc lợi nhuận, thiệt hại ph&aacute;t sinh từ hoặc li&ecirc;n quan đến việc truy cập, sử dụng hoặc hiệu quả hoạt động của website ngay cả khi về khả năng xảy ra c&aacute;c tổn thất đ&oacute; c&oacute; thể nh&igrave;n thấy trước hoặc đ&atilde; được khuyến c&aacute;o trước. Bạn đồng &yacute; v&agrave; thừa nhận cụ thể rằng ch&uacute;ng t&ocirc;i cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; với mọi h&agrave;nh vi n&oacute;i xấu, tấn c&ocirc;ng, kh&ocirc;ng trung thực hoặc c&aacute;c h&agrave;nh vi bất hợp ph&aacute;p kh&aacute;c của bất kỳ người n&agrave;o sử dụng website n&agrave;y. Nếu bạn kh&ocirc;ng bằng l&ograve;ng với bất kỳ nội dụng n&agrave;o của website n&agrave;y th&igrave; biện ph&aacute;p duy nhất d&agrave;nh cho bạn l&agrave; chấm dứt truy cập v&agrave; sử dụng website n&agrave;y. BỒI THƯỜNG Bạn đồng &yacute; bảo vệ, bồi thường v&agrave; loại trừ Suntory PepsiCo khỏi những nghĩa vụ ph&aacute;p l&yacute;, tố tụng, tổn thất, chi ph&iacute; (bao gồm cả chi ph&iacute; cho luật sư) c&oacute; li&ecirc;n quan tới hoặc ph&aacute;t sinh từ việc sử dụng Website n&agrave;y của bạn. LI&Ecirc;N KẾT ĐẾN C&Aacute;C WEBSITE CỦA B&Ecirc;N THỨ BA Bạn thừa nhận v&agrave; đồng &yacute; rằng Suntory PepsiCo kh&ocirc;ng c&oacute; tr&aacute;ch nhiệm với bất kỳ website của c&aacute;c b&ecirc;n thứ ba (kh&ocirc;ng phải c&aacute;c trang do ch&uacute;ng t&ocirc;i quản l&yacute;) được li&ecirc;n kết đến hoặc từ website n&agrave;y. C&aacute;c website của c&aacute;c b&ecirc;n thứ ba được li&ecirc;n kết đến hoặc từ website n&agrave;y được điều h&agrave;nh v&agrave; duy tr&igrave; ho&agrave;n to&agrave;n độc lập bởi c&aacute;c b&ecirc;n thứ ba đ&oacute; v&agrave; c&oacute; c&aacute;c điều khoản v&agrave; điều kiện quy định ri&ecirc;ng kh&ocirc;ng nằm trong quyền điều khiển v&agrave;/hoặc gi&aacute;m s&aacute;t của ch&uacute;ng t&ocirc;i. Ch&uacute;ng t&ocirc;i kh&ocirc;ng đảm bảo hay chịu tr&aacute;ch nhiệm với bất kỳ nội dung, quảng c&aacute;o, sản phẩm hay dịch vụ n&agrave;o xuất hiện hoặc được cung cấp tr&ecirc;n c&aacute;c website li&ecirc;n kết đến v&agrave; đi từ website n&agrave;y, cũng như kh&ocirc;ng chịu tr&aacute;ch nhiệm cho sự mất m&aacute;t hoặc thiệt hại do việc truy cập v&agrave; sử dụng c&aacute;c website đ&oacute;. Việc truy cập c&aacute;c website của b&ecirc;n thứ ba li&ecirc;n kết tới v&agrave; đi từ website n&agrave;y thuộc phạm tr&ugrave; rủi ro của ri&ecirc;ng bạn. TH&Ocirc;NG TIN C&Aacute; NH&Acirc;N Khi truy cập v&agrave; sử dụng website n&agrave;y, để bạn c&oacute; thể sử dụng một số chức năng v&agrave; dịch vụ, ch&uacute;ng t&ocirc;i c&oacute; thể y&ecirc;u cầu bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n cho ch&uacute;ng t&ocirc;i qua website n&agrave;y. QUY ĐỊNH VỀ T&Agrave;I KHOẢN HỌC TRỰC TUYẾN E-LEARNING Về t&agrave;i khoản đăng nhập: Để sử dụng dịch vụ học trực tuyến E-learning của website n&agrave;y, bạn vui l&ograve;ng đăng k&yacute; t&agrave;i khoản bằng c&aacute;ch cung cấp đầy đủ, trung thực v&agrave; ch&iacute;nh x&aacute;c c&aacute;c th&ocirc;ng tin c&aacute; nh&acirc;n của m&igrave;nh như t&ecirc;n, email, số điện thoại, nghề nghiệp, nơi c&ocirc;ng t&aacute;c, &hellip; Đ&acirc;y l&agrave; những th&ocirc;ng tin bắt buộc để tạo điều kiện cho ch&uacute;ng t&ocirc;i cung cấp dịch vụ m&agrave; bạn y&ecirc;u cầu v&agrave; tạo sự thuận lợi cho ch&uacute;ng t&ocirc;i trong việc hỗ trợ người sử dụng dịch vụ học trực tuyến E-learning của ch&uacute;ng t&ocirc;i. Trong trường hợp bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n kh&ocirc;ng ch&iacute;nh x&aacute;c, thiếu trung thực th&igrave; bất cứ một sự cố hay vấn đề n&agrave;o ph&aacute;t sinh trong phạm vi t&agrave;i khoản của bạn th&igrave; đều thuộc tr&aacute;ch nhiệm của bạn. Th&ocirc;ng tin c&aacute; nh&acirc;n của bạn sẽ được quản l&yacute; v&agrave; sử dụng theo Ch&iacute;nh s&aacute;ch Bảo mật. Mật khẩu của t&agrave;i khoản đăng nhập: Trong phần quản l&yacute; t&agrave;i khoản, đối với một t&agrave;i khoản, người sử dụng sẽ c&oacute; một mật khẩu. Mật khẩu được sử dụng để đăng nhập v&agrave;o dịch vụ học trực tuyến E-learning tr&ecirc;n website n&agrave;y. Bạn c&oacute; tr&aacute;ch nhiệm tự bảo mật th&ocirc;ng tin t&agrave;i khoản. Nếu mật khẩu bị lộ ra ngo&agrave;i dưới bất kỳ h&igrave;nh thức n&agrave;o, ch&uacute;ng t&ocirc;i sẽ kh&ocirc;ng chịu tr&aacute;ch nhiệm về mọi tổn thất ph&aacute;t sinh. CHẤM DỨT DỊCH VỤ Suntory PepsiCo c&oacute; to&agrave;n quyền chấm dứt hoạt động của website n&agrave;y, hoặc chấm dứt việc truy cập website n&agrave;y của bạn, với bất kỳ l&yacute; do n&agrave;o, m&agrave; kh&ocirc;ng cần th&ocirc;ng b&aacute;o cho bạn cũng như kh&ocirc;ng c&oacute; bất kỳ tr&aacute;ch nhiệm n&agrave;o với bạn cũng nhưng bất cứ b&ecirc;n thứ ba n&agrave;o. LUẬT &Aacute;P DỤNG Bản Điều khoản Sử dụng n&agrave;y được điều chỉnh v&agrave; giải th&iacute;ch theo luật ph&aacute;p hiện h&agrave;nh của Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam. Th&ocirc;ng qua việc đăng k&yacute; hoặc sử dụng website của ch&uacute;ng t&ocirc;i, bạn đồng &yacute; v&agrave; tu&acirc;n thủ ph&aacute;n x&eacute;t của t&ograve;a &aacute;n Nước Cộng h&ograve;a X&atilde; hội Chủ nghĩa Việt Nam khi xảy ra bất kỳ vi phạm n&agrave;o li&ecirc;n quan đến những Điều khoản Sử dụng n&agrave;y. Một điều khoản sử dụng bị v&ocirc; hiệu theo quyết định của t&ograve;a &aacute;n c&oacute; thẩm quyền sẽ kh&ocirc;ng ảnh hưởng đến t&iacute;nh hiệu lực của c&aacute;c điều khoản c&ograve;n lại. C&aacute;c Điều khoản Sử dụng n&agrave;y c&oacute; hiệu lực kể từ ng&agrave;y website ch&iacute;nh thức đi v&agrave;o hoạt động</p>','tearm-of-use',1,'',0,'vi',0,'0','2019-12-04 10:15:11',1,'2019-12-10 09:21:17',1,NULL,NULL),
	(15,14,NULL,'Terms of Use','terms-of-use',NULL,NULL,'<p>Xin vui l&ograve;ng đọc kỹ c&aacute;c Điều khoản Sử dụng dưới đ&acirc;y trước khi sử dụng trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn Trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn, sau đ&acirc;y được gọi l&agrave; &ldquo;website&rdquo; được sở hữu v&agrave; vận h&agrave;nh bởi c&ocirc;ng ty TNHH Nước Giải kh&aacute;t Suntory PepsiCo Việt Nam, sau đ&acirc;y được gọi l&agrave; &ldquo;Suntory PepsiCo&rdquo;, hoặc &ldquo;ch&uacute;ng t&ocirc;i&rdquo;. Bằng việc truy cập v&agrave; sử dụng website n&agrave;y, bạn c&ocirc;ng nhận rằng bạn đ&atilde; đọc, hiểu v&agrave; nhất tr&iacute; với việc tu&acirc;n thủ quy định của những Điều khoản Sử dụng. Suntory PepsiCo c&oacute; to&agrave;n quyền thay đổi nội dung của website cũng như c&aacute;c Điều khoản Sử dụng n&agrave;y v&agrave;o bất kỳ thời điểm n&agrave;o m&agrave; kh&ocirc;ng c&oacute; nghĩa vụ th&ocirc;ng b&aacute;o với bạn. Bạn n&ecirc;n thường xuy&ecirc;n truy cập website để cập nhật về c&aacute;c thay đổi. Bạn đồng &yacute; rằng việc bạn tiếp tục sử dụng website đồng nghĩa với việc bạn đồng &yacute; với những Điều khoản Sử dụng cập nhật nhất tại thời điểm đ&oacute;. VIỆC SỬ DỤNG WEBSITE CỦA BẠN Bạn đồng &yacute; sẽ kh&ocirc;ng sử dụng website cho những mục đích bất hợp ph&aacute;p theo quy định của ph&aacute;p luật Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam hay bị cấm bởi c&aacute;c Điều khoản Sử dụng hay bất cứ điều luật li&ecirc;n quan n&agrave;o kh&aacute;c. Bạn c&oacute; thể truy cập, xem, sao ch&eacute;p v&agrave; tải c&aacute;c nội dung tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc mục đ&iacute;ch phi thương mại với điều kiện bạn kh&ocirc;ng sửa đổi hay x&oacute;a bỏ c&aacute;c bản quyền, thương hiệu c&oacute; tr&ecirc;n c&aacute;c t&agrave;i liệu m&agrave; bạn truy cập, xem, sao ch&eacute;p v&agrave; tải từ website n&agrave;y. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c bao gồm nhưng kh&ocirc;ng giới hạn trong sao ch&eacute;p, sửa đổi, ph&acirc;n phối, truyền, tải, cấp ph&eacute;p, hay tạo ra c&aacute;c biến thể từ c&aacute;c nội dung thu được từ website n&agrave;y m&agrave; kh&ocirc;ng được sự đồng &yacute; bằng văn bản của Suntory PepsiCo đều bị nghi&ecirc;m cấm. Bạn đồng &yacute; kh&ocirc;ng x&acirc;m phạm quyền, giới hạn hoặc ngăn cấm người kh&aacute;c sử dụng website n&agrave;y. Bạn sẽ kh&ocirc;ng can thiệp, x&acirc;m phạm hay ph&aacute; hoại bất kỳ chức năng an ninh n&agrave;o của website n&agrave;y hay kh&ocirc;ng gửi bất kỳ th&ocirc;ng tin hay phần mềm n&agrave;o c&oacute; chứa bất kỳ loại virus, Trojan, s&acirc;u hay bất kỳ th&agrave;nh phần nguy hại n&agrave;o qua website n&agrave;y. NỘI DUNG BẠN CUNG CẤP Bạn đảm bảo rằng bạn sẽ chịu tr&aacute;ch nhiệm trước ph&aacute;p luật với bất kỳ nội dung n&agrave;o m&agrave; bạn đăng tải tr&ecirc;n website n&agrave;y bao gồm t&iacute;nh hợp ph&aacute;p, t&iacute;nh ch&iacute;nh x&aacute;c, ph&ugrave; hợp v&agrave; bản quyền đối với nội dung đ&oacute;. Với việc cung cấp nội dung cho Suntory PepsiCo, bạn đồng &yacute; trao cho ch&uacute;ng t&ocirc;i to&agrave;n bộ quyền v&agrave; cấp ph&eacute;p sử dụng, t&aacute;i sản xuất, chỉnh sửa, l&agrave;m cho ph&ugrave; hợp, xuất bản, dịch, tạo ra c&aacute;c phi&ecirc;n bản kh&aacute;c, ph&acirc;n phối v&agrave; trưng b&agrave;y nội dung được bạn cung cấp tr&ecirc;n phạm vi to&agrave;n cầu bằng bất cứ phương tiện truyền th&ocirc;ng n&agrave;o m&agrave; kh&ocirc;ng đ&ograve;i hỏi th&ugrave; lao. Bạn trao cho ch&uacute;ng t&ocirc;i quyền được sử dụng t&ecirc;n gọi m&agrave; bạn cung cấp li&ecirc;n quan đến nội dung được bạn đăng tải khi cần thiết. Tất cả th&ocirc;ng tin c&aacute; nh&acirc;n được cung cấp tr&ecirc;n website n&agrave;y sẽ được sử dụng v&agrave; quản l&yacute; theo đ&uacute;ng Ch&iacute;nh s&aacute;ch Bảo mật của website n&agrave;y. Bạn bảo đảm rằng bạn sở hữu hoặc c&oacute; tất cả c&aacute;c quyền ph&aacute;p l&yacute; đối với nội dung bạn cung cấp tr&ecirc;n website n&agrave;y; rằng nội dung bạn cung cấp l&agrave; ch&iacute;nh x&aacute;c; rằng việc sử dụng nội dung bạn cung cấp kh&ocirc;ng vi phạm bất kỳ điều khoản n&agrave;o được quy định trong bản Điều khoản sử dụng n&agrave;y v&agrave; sẽ kh&ocirc;ng g&acirc;y ra tổn thất cho bất kỳ ai; rằng bạn sẽ loại trừ ch&uacute;ng t&ocirc;i khỏi tất cả c&aacute;c khiếu nại xuất ph&aacute;t từ nội dung m&agrave; bạn cung cấp. QUYỀN SỞ HỮU TR&Iacute; TUỆ Tất cả c&aacute;c bản quyền, thương hiệu hay bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o thuộc website n&agrave;y đều thuộc sở hữu của Suntory PepsiCo hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ trường hợp được quy định trong bản Điều khoản Sử dụng n&agrave;y, việc bạn truy cập, sử dụng website n&agrave;y kh&ocirc;ng đồng nghĩa với việc trao cho bạn bất kỳ quyền sở hữu hay cấp ph&eacute;p cho bạn đối với bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o n&ecirc;u tr&ecirc;n. Bạn được ph&eacute;p sử dụng bất kỳ nội dung hay t&agrave;i liệu tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc phi thương mại. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c phải c&oacute; c&oacute; sự cho ph&eacute;p bằng văn bản của ch&uacute;ng t&ocirc;i hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ khi được quy định trong Điều khoản quy định n&agrave;y, bất cứ h&agrave;nh vi sử dụng t&agrave;i liệu hay nội dung n&agrave;o thuộc website n&agrave;y, bao gồm sao ch&eacute;p, t&aacute;i sản xuất, truyền, ph&acirc;n phối, khai th&aacute;c cho mục đ&iacute;ch thương mại hay tạo ra c&aacute;c biến thể kh&aacute;c đều bị nghi&ecirc;m cấm. Website n&agrave;y v&agrave; tất cả nội dung thuộc website được bảo hộ theo quy định của Luật Sở hữu tr&iacute; tuệ Việt Nam v&agrave; c&aacute;c văn bản luật li&ecirc;n quan. TỪ CHỐI ĐẢM BẢO BẠN ĐỒNG &Yacute; RẰNG VIỆC SỬ DỤNG WEBSITE N&Agrave;Y THUỘC PHẠM TR&Ugrave; RỦI RO CỦA RI&Ecirc;NG BẠN V&Agrave; KH&Ocirc;NG THUỘC TR&Aacute;CH NHIỆM CỦA CH&Uacute;NG T&Ocirc;I. WEBSITE N&Agrave;Y V&Agrave; NỘI DUNG TR&Ecirc;N WEBSITE N&Agrave;Y, BAO GỒM NHƯNG KH&Ocirc;NG GIỚI HẠN Ở C&Aacute;C TH&Ocirc;NG TIN, T&Agrave;I LIỆU, THIẾT KẾ, ĐỒ HỌA, GIAO DIỆN, H&Igrave;NH ẢNH, M&Atilde; CODE, PHẦN MỀM, NH&Atilde;N HIỆU, T&Ecirc;N THƯƠNG MẠI, C&Aacute;C LOGO, CŨNG NHƯ SẢN PHẨM, DỊCH VỤ THUỘC SỞ HỮU HAY LI&Ecirc;N QUAN ĐẾN SUNTORY PEPSICO HAY BẤT KỲ B&Ecirc;N THỨ BA N&Agrave;O ĐƯỢC CUNG CẤP CHO BẠN TR&Ecirc;N CƠ SỞ &ldquo;NHƯ ĐANG C&Oacute;&rdquo; V&Agrave; CH&Uacute;NG T&Ocirc;I TỪ CHỐI MỌI BẢO ĐẢM THEO BẤT KỲ PHƯƠNG THỨC N&Agrave;O, D&Ugrave; L&Agrave; H&Agrave;M &Yacute; HAY C&Ocirc;NG BỐ, BAO GỒM NHƯNG KH&Ocirc;NG CHỈ GIỚI HẠN TRONG C&Aacute;C BẢO ĐẢM VỀ KHẢ NĂNG B&Aacute;N SẢN PHẨM, CHẤT LƯỢNG, SỰ PH&Ugrave; HỢP VỚI MỘT MỤC Đ&Iacute;CH CỤ THỂ N&Agrave;O Đ&Oacute;, SỰ KH&Ocirc;NG VI PHẠM, SỰ TƯƠNG TH&Iacute;CH, SỰ AN TO&Agrave;N, CH&Iacute;NH X&Aacute;C HAY HO&Agrave;N CHỈNH CỦA BẤT KỲ NỘI DUNG N&Agrave;O TR&Ecirc;N WEBSITE N&Agrave;Y. NGOẠI TRỪ ĐƯỢC QUY ĐỊNH BỞI PH&Aacute;P LUẬT, CH&Uacute;NG T&Ocirc;I KH&Ocirc;NG ĐẢM BẢO RẰNG NỘI DUNG THUỘC WEBSITE N&Agrave;Y, HAY BẤT KỲ T&Iacute;NH NĂNG N&Agrave;O CỦA WEBSITE N&Agrave;Y SẼ KH&Ocirc;NG BỊ GI&Aacute;N ĐOẠN, KH&Ocirc;NG C&Oacute; LỖI, KH&Ocirc;NG C&Oacute; VIRUS, HAY SẼ LU&Ocirc;N TƯƠNG TH&Iacute;CH VỚI BẤT KỲ PHẦN MỀM HAY NỘI DUNG N&Agrave;O KH&Aacute;C. GIỚI HẠN TR&Aacute;CH NHIỆM PH&Aacute;P L&Yacute; Trong bất kỳ trường hợp n&agrave;o, Suntory PepsiCo cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i cũng kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; cho bất kỳ tổn thất n&agrave;o, d&ugrave; l&agrave; trực tiếp, gi&aacute;n tiếp, đặc biệt, bất ngờ, hoặc l&agrave; hậu quả của sự kiện kh&aacute;c, bao gồm nhưng kh&ocirc;ng giới hạn trong c&aacute;c thiệt hại trong kinh doanh hoặc lợi nhuận, thiệt hại ph&aacute;t sinh từ hoặc li&ecirc;n quan đến việc truy cập, sử dụng hoặc hiệu quả hoạt động của website ngay cả khi về khả năng xảy ra c&aacute;c tổn thất đ&oacute; c&oacute; thể nh&igrave;n thấy trước hoặc đ&atilde; được khuyến c&aacute;o trước. Bạn đồng &yacute; v&agrave; thừa nhận cụ thể rằng ch&uacute;ng t&ocirc;i cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; với mọi h&agrave;nh vi n&oacute;i xấu, tấn c&ocirc;ng, kh&ocirc;ng trung thực hoặc c&aacute;c h&agrave;nh vi bất hợp ph&aacute;p kh&aacute;c của bất kỳ người n&agrave;o sử dụng website n&agrave;y. Nếu bạn kh&ocirc;ng bằng l&ograve;ng với bất kỳ nội dụng n&agrave;o của website n&agrave;y th&igrave; biện ph&aacute;p duy nhất d&agrave;nh cho bạn l&agrave; chấm dứt truy cập v&agrave; sử dụng website n&agrave;y. BỒI THƯỜNG Bạn đồng &yacute; bảo vệ, bồi thường v&agrave; loại trừ Suntory PepsiCo khỏi những nghĩa vụ ph&aacute;p l&yacute;, tố tụng, tổn thất, chi ph&iacute; (bao gồm cả chi ph&iacute; cho luật sư) c&oacute; li&ecirc;n quan tới hoặc ph&aacute;t sinh từ việc sử dụng Website n&agrave;y của bạn. LI&Ecirc;N KẾT ĐẾN C&Aacute;C WEBSITE CỦA B&Ecirc;N THỨ BA Bạn thừa nhận v&agrave; đồng &yacute; rằng Suntory PepsiCo kh&ocirc;ng c&oacute; tr&aacute;ch nhiệm với bất kỳ website của c&aacute;c b&ecirc;n thứ ba (kh&ocirc;ng phải c&aacute;c trang do ch&uacute;ng t&ocirc;i quản l&yacute;) được li&ecirc;n kết đến hoặc từ website n&agrave;y. C&aacute;c website của c&aacute;c b&ecirc;n thứ ba được li&ecirc;n kết đến hoặc từ website n&agrave;y được điều h&agrave;nh v&agrave; duy tr&igrave; ho&agrave;n to&agrave;n độc lập bởi c&aacute;c b&ecirc;n thứ ba đ&oacute; v&agrave; c&oacute; c&aacute;c điều khoản v&agrave; điều kiện quy định ri&ecirc;ng kh&ocirc;ng nằm trong quyền điều khiển v&agrave;/hoặc gi&aacute;m s&aacute;t của ch&uacute;ng t&ocirc;i. Ch&uacute;ng t&ocirc;i kh&ocirc;ng đảm bảo hay chịu tr&aacute;ch nhiệm với bất kỳ nội dung, quảng c&aacute;o, sản phẩm hay dịch vụ n&agrave;o xuất hiện hoặc được cung cấp tr&ecirc;n c&aacute;c website li&ecirc;n kết đến v&agrave; đi từ website n&agrave;y, cũng như kh&ocirc;ng chịu tr&aacute;ch nhiệm cho sự mất m&aacute;t hoặc thiệt hại do việc truy cập v&agrave; sử dụng c&aacute;c website đ&oacute;. Việc truy cập c&aacute;c website của b&ecirc;n thứ ba li&ecirc;n kết tới v&agrave; đi từ website n&agrave;y thuộc phạm tr&ugrave; rủi ro của ri&ecirc;ng bạn. TH&Ocirc;NG TIN C&Aacute; NH&Acirc;N Khi truy cập v&agrave; sử dụng website n&agrave;y, để bạn c&oacute; thể sử dụng một số chức năng v&agrave; dịch vụ, ch&uacute;ng t&ocirc;i c&oacute; thể y&ecirc;u cầu bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n cho ch&uacute;ng t&ocirc;i qua website n&agrave;y. QUY ĐỊNH VỀ T&Agrave;I KHOẢN HỌC TRỰC TUYẾN E-LEARNING Về t&agrave;i khoản đăng nhập: Để sử dụng dịch vụ học trực tuyến E-learning của website n&agrave;y, bạn vui l&ograve;ng đăng k&yacute; t&agrave;i khoản bằng c&aacute;ch cung cấp đầy đủ, trung thực v&agrave; ch&iacute;nh x&aacute;c c&aacute;c th&ocirc;ng tin c&aacute; nh&acirc;n của m&igrave;nh như t&ecirc;n, email, số điện thoại, nghề nghiệp, nơi c&ocirc;ng t&aacute;c, &hellip; Đ&acirc;y l&agrave; những th&ocirc;ng tin bắt buộc để tạo điều kiện cho ch&uacute;ng t&ocirc;i cung cấp dịch vụ m&agrave; bạn y&ecirc;u cầu v&agrave; tạo sự thuận lợi cho ch&uacute;ng t&ocirc;i trong việc hỗ trợ người sử dụng dịch vụ học trực tuyến E-learning của ch&uacute;ng t&ocirc;i. Trong trường hợp bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n kh&ocirc;ng ch&iacute;nh x&aacute;c, thiếu trung thực th&igrave; bất cứ một sự cố hay vấn đề n&agrave;o ph&aacute;t sinh trong phạm vi t&agrave;i khoản của bạn th&igrave; đều thuộc tr&aacute;ch nhiệm của bạn. Th&ocirc;ng tin c&aacute; nh&acirc;n của bạn sẽ được quản l&yacute; v&agrave; sử dụng theo Ch&iacute;nh s&aacute;ch Bảo mật. Mật khẩu của t&agrave;i khoản đăng nhập: Trong phần quản l&yacute; t&agrave;i khoản, đối với một t&agrave;i khoản, người sử dụng sẽ c&oacute; một mật khẩu. Mật khẩu được sử dụng để đăng nhập v&agrave;o dịch vụ học trực tuyến E-learning tr&ecirc;n website n&agrave;y. Bạn c&oacute; tr&aacute;ch nhiệm tự bảo mật th&ocirc;ng tin t&agrave;i khoản. Nếu mật khẩu bị lộ ra ngo&agrave;i dưới bất kỳ h&igrave;nh thức n&agrave;o, ch&uacute;ng t&ocirc;i sẽ kh&ocirc;ng chịu tr&aacute;ch nhiệm về mọi tổn thất ph&aacute;t sinh. CHẤM DỨT DỊCH VỤ Suntory PepsiCo c&oacute; to&agrave;n quyền chấm dứt hoạt động của website n&agrave;y, hoặc chấm dứt việc truy cập website n&agrave;y của bạn, với bất kỳ l&yacute; do n&agrave;o, m&agrave; kh&ocirc;ng cần th&ocirc;ng b&aacute;o cho bạn cũng như kh&ocirc;ng c&oacute; bất kỳ tr&aacute;ch nhiệm n&agrave;o với bạn cũng nhưng bất cứ b&ecirc;n thứ ba n&agrave;o. LUẬT &Aacute;P DỤNG Bản Điều khoản Sử dụng n&agrave;y được điều chỉnh v&agrave; giải th&iacute;ch theo luật ph&aacute;p hiện h&agrave;nh của Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam. Th&ocirc;ng qua việc đăng k&yacute; hoặc sử dụng website của ch&uacute;ng t&ocirc;i, bạn đồng &yacute; v&agrave; tu&acirc;n thủ ph&aacute;n x&eacute;t của t&ograve;a &aacute;n Nước Cộng h&ograve;a X&atilde; hội Chủ nghĩa Việt Nam khi xảy ra bất kỳ vi phạm n&agrave;o li&ecirc;n quan đến những Điều khoản Sử dụng n&agrave;y. Một điều khoản sử dụng bị v&ocirc; hiệu theo quyết định của t&ograve;a &aacute;n c&oacute; thẩm quyền sẽ kh&ocirc;ng ảnh hưởng đến t&iacute;nh hiệu lực của c&aacute;c điều khoản c&ograve;n lại. C&aacute;c Điều khoản Sử dụng n&agrave;y c&oacute; hiệu lực kể từ ng&agrave;y website ch&iacute;nh thức đi v&agrave;o hoạt động</p>','tearm-of-use',1,'',0,'en',0,'0','2019-12-04 10:15:11',1,'2019-12-10 09:21:13',1,NULL,NULL),
	(16,16,NULL,'Private Policy','private-policy',NULL,NULL,'<p>Xin vui l&ograve;ng đọc kỹ c&aacute;c Điều khoản Sử dụng dưới đ&acirc;y trước khi sử dụng trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn Trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn, sau đ&acirc;y được gọi l&agrave; &ldquo;website&rdquo; được sở hữu v&agrave; vận h&agrave;nh bởi c&ocirc;ng ty TNHH Nước Giải kh&aacute;t Suntory PepsiCo Việt Nam, sau đ&acirc;y được gọi l&agrave; &ldquo;Suntory PepsiCo&rdquo;, hoặc &ldquo;ch&uacute;ng t&ocirc;i&rdquo;. Bằng việc truy cập v&agrave; sử dụng website n&agrave;y, bạn c&ocirc;ng nhận rằng bạn đ&atilde; đọc, hiểu v&agrave; nhất tr&iacute; với việc tu&acirc;n thủ quy định của những Điều khoản Sử dụng. Suntory PepsiCo c&oacute; to&agrave;n quyền thay đổi nội dung của website cũng như c&aacute;c Điều khoản Sử dụng n&agrave;y v&agrave;o bất kỳ thời điểm n&agrave;o m&agrave; kh&ocirc;ng c&oacute; nghĩa vụ th&ocirc;ng b&aacute;o với bạn. Bạn n&ecirc;n thường xuy&ecirc;n truy cập website để cập nhật về c&aacute;c thay đổi. Bạn đồng &yacute; rằng việc bạn tiếp tục sử dụng website đồng nghĩa với việc bạn đồng &yacute; với những Điều khoản Sử dụng cập nhật nhất tại thời điểm đ&oacute;. VIỆC SỬ DỤNG WEBSITE CỦA BẠN Bạn đồng &yacute; sẽ kh&ocirc;ng sử dụng website cho những mục đích bất hợp ph&aacute;p theo quy định của ph&aacute;p luật Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam hay bị cấm bởi c&aacute;c Điều khoản Sử dụng hay bất cứ điều luật li&ecirc;n quan n&agrave;o kh&aacute;c. Bạn c&oacute; thể truy cập, xem, sao ch&eacute;p v&agrave; tải c&aacute;c nội dung tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc mục đ&iacute;ch phi thương mại với điều kiện bạn kh&ocirc;ng sửa đổi hay x&oacute;a bỏ c&aacute;c bản quyền, thương hiệu c&oacute; tr&ecirc;n c&aacute;c t&agrave;i liệu m&agrave; bạn truy cập, xem, sao ch&eacute;p v&agrave; tải từ website n&agrave;y. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c bao gồm nhưng kh&ocirc;ng giới hạn trong sao ch&eacute;p, sửa đổi, ph&acirc;n phối, truyền, tải, cấp ph&eacute;p, hay tạo ra c&aacute;c biến thể từ c&aacute;c nội dung thu được từ website n&agrave;y m&agrave; kh&ocirc;ng được sự đồng &yacute; bằng văn bản của Suntory PepsiCo đều bị nghi&ecirc;m cấm. Bạn đồng &yacute; kh&ocirc;ng x&acirc;m phạm quyền, giới hạn hoặc ngăn cấm người kh&aacute;c sử dụng website n&agrave;y. Bạn sẽ kh&ocirc;ng can thiệp, x&acirc;m phạm hay ph&aacute; hoại bất kỳ chức năng an ninh n&agrave;o của website n&agrave;y hay kh&ocirc;ng gửi bất kỳ th&ocirc;ng tin hay phần mềm n&agrave;o c&oacute; chứa bất kỳ loại virus, Trojan, s&acirc;u hay bất kỳ th&agrave;nh phần nguy hại n&agrave;o qua website n&agrave;y. NỘI DUNG BẠN CUNG CẤP Bạn đảm bảo rằng bạn sẽ chịu tr&aacute;ch nhiệm trước ph&aacute;p luật với bất kỳ nội dung n&agrave;o m&agrave; bạn đăng tải tr&ecirc;n website n&agrave;y bao gồm t&iacute;nh hợp ph&aacute;p, t&iacute;nh ch&iacute;nh x&aacute;c, ph&ugrave; hợp v&agrave; bản quyền đối với nội dung đ&oacute;. Với việc cung cấp nội dung cho Suntory PepsiCo, bạn đồng &yacute; trao cho ch&uacute;ng t&ocirc;i to&agrave;n bộ quyền v&agrave; cấp ph&eacute;p sử dụng, t&aacute;i sản xuất, chỉnh sửa, l&agrave;m cho ph&ugrave; hợp, xuất bản, dịch, tạo ra c&aacute;c phi&ecirc;n bản kh&aacute;c, ph&acirc;n phối v&agrave; trưng b&agrave;y nội dung được bạn cung cấp tr&ecirc;n phạm vi to&agrave;n cầu bằng bất cứ phương tiện truyền th&ocirc;ng n&agrave;o m&agrave; kh&ocirc;ng đ&ograve;i hỏi th&ugrave; lao. Bạn trao cho ch&uacute;ng t&ocirc;i quyền được sử dụng t&ecirc;n gọi m&agrave; bạn cung cấp li&ecirc;n quan đến nội dung được bạn đăng tải khi cần thiết. Tất cả th&ocirc;ng tin c&aacute; nh&acirc;n được cung cấp tr&ecirc;n website n&agrave;y sẽ được sử dụng v&agrave; quản l&yacute; theo đ&uacute;ng Ch&iacute;nh s&aacute;ch Bảo mật của website n&agrave;y. Bạn bảo đảm rằng bạn sở hữu hoặc c&oacute; tất cả c&aacute;c quyền ph&aacute;p l&yacute; đối với nội dung bạn cung cấp tr&ecirc;n website n&agrave;y; rằng nội dung bạn cung cấp l&agrave; ch&iacute;nh x&aacute;c; rằng việc sử dụng nội dung bạn cung cấp kh&ocirc;ng vi phạm bất kỳ điều khoản n&agrave;o được quy định trong bản Điều khoản sử dụng n&agrave;y v&agrave; sẽ kh&ocirc;ng g&acirc;y ra tổn thất cho bất kỳ ai; rằng bạn sẽ loại trừ ch&uacute;ng t&ocirc;i khỏi tất cả c&aacute;c khiếu nại xuất ph&aacute;t từ nội dung m&agrave; bạn cung cấp. QUYỀN SỞ HỮU TR&Iacute; TUỆ Tất cả c&aacute;c bản quyền, thương hiệu hay bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o thuộc website n&agrave;y đều thuộc sở hữu của Suntory PepsiCo hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ trường hợp được quy định trong bản Điều khoản Sử dụng n&agrave;y, việc bạn truy cập, sử dụng website n&agrave;y kh&ocirc;ng đồng nghĩa với việc trao cho bạn bất kỳ quyền sở hữu hay cấp ph&eacute;p cho bạn đối với bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o n&ecirc;u tr&ecirc;n. Bạn được ph&eacute;p sử dụng bất kỳ nội dung hay t&agrave;i liệu tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc phi thương mại. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c phải c&oacute; c&oacute; sự cho ph&eacute;p bằng văn bản của ch&uacute;ng t&ocirc;i hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ khi được quy định trong Điều khoản quy định n&agrave;y, bất cứ h&agrave;nh vi sử dụng t&agrave;i liệu hay nội dung n&agrave;o thuộc website n&agrave;y, bao gồm sao ch&eacute;p, t&aacute;i sản xuất, truyền, ph&acirc;n phối, khai th&aacute;c cho mục đ&iacute;ch thương mại hay tạo ra c&aacute;c biến thể kh&aacute;c đều bị nghi&ecirc;m cấm. Website n&agrave;y v&agrave; tất cả nội dung thuộc website được bảo hộ theo quy định của Luật Sở hữu tr&iacute; tuệ Việt Nam v&agrave; c&aacute;c văn bản luật li&ecirc;n quan. TỪ CHỐI ĐẢM BẢO BẠN ĐỒNG &Yacute; RẰNG VIỆC SỬ DỤNG WEBSITE N&Agrave;Y THUỘC PHẠM TR&Ugrave; RỦI RO CỦA RI&Ecirc;NG BẠN V&Agrave; KH&Ocirc;NG THUỘC TR&Aacute;CH NHIỆM CỦA CH&Uacute;NG T&Ocirc;I. WEBSITE N&Agrave;Y V&Agrave; NỘI DUNG TR&Ecirc;N WEBSITE N&Agrave;Y, BAO GỒM NHƯNG KH&Ocirc;NG GIỚI HẠN Ở C&Aacute;C TH&Ocirc;NG TIN, T&Agrave;I LIỆU, THIẾT KẾ, ĐỒ HỌA, GIAO DIỆN, H&Igrave;NH ẢNH, M&Atilde; CODE, PHẦN MỀM, NH&Atilde;N HIỆU, T&Ecirc;N THƯƠNG MẠI, C&Aacute;C LOGO, CŨNG NHƯ SẢN PHẨM, DỊCH VỤ THUỘC SỞ HỮU HAY LI&Ecirc;N QUAN ĐẾN SUNTORY PEPSICO HAY BẤT KỲ B&Ecirc;N THỨ BA N&Agrave;O ĐƯỢC CUNG CẤP CHO BẠN TR&Ecirc;N CƠ SỞ &ldquo;NHƯ ĐANG C&Oacute;&rdquo; V&Agrave; CH&Uacute;NG T&Ocirc;I TỪ CHỐI MỌI BẢO ĐẢM THEO BẤT KỲ PHƯƠNG THỨC N&Agrave;O, D&Ugrave; L&Agrave; H&Agrave;M &Yacute; HAY C&Ocirc;NG BỐ, BAO GỒM NHƯNG KH&Ocirc;NG CHỈ GIỚI HẠN TRONG C&Aacute;C BẢO ĐẢM VỀ KHẢ NĂNG B&Aacute;N SẢN PHẨM, CHẤT LƯỢNG, SỰ PH&Ugrave; HỢP VỚI MỘT MỤC Đ&Iacute;CH CỤ THỂ N&Agrave;O Đ&Oacute;, SỰ KH&Ocirc;NG VI PHẠM, SỰ TƯƠNG TH&Iacute;CH, SỰ AN TO&Agrave;N, CH&Iacute;NH X&Aacute;C HAY HO&Agrave;N CHỈNH CỦA BẤT KỲ NỘI DUNG N&Agrave;O TR&Ecirc;N WEBSITE N&Agrave;Y. NGOẠI TRỪ ĐƯỢC QUY ĐỊNH BỞI PH&Aacute;P LUẬT, CH&Uacute;NG T&Ocirc;I KH&Ocirc;NG ĐẢM BẢO RẰNG NỘI DUNG THUỘC WEBSITE N&Agrave;Y, HAY BẤT KỲ T&Iacute;NH NĂNG N&Agrave;O CỦA WEBSITE N&Agrave;Y SẼ KH&Ocirc;NG BỊ GI&Aacute;N ĐOẠN, KH&Ocirc;NG C&Oacute; LỖI, KH&Ocirc;NG C&Oacute; VIRUS, HAY SẼ LU&Ocirc;N TƯƠNG TH&Iacute;CH VỚI BẤT KỲ PHẦN MỀM HAY NỘI DUNG N&Agrave;O KH&Aacute;C. GIỚI HẠN TR&Aacute;CH NHIỆM PH&Aacute;P L&Yacute; Trong bất kỳ trường hợp n&agrave;o, Suntory PepsiCo cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i cũng kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; cho bất kỳ tổn thất n&agrave;o, d&ugrave; l&agrave; trực tiếp, gi&aacute;n tiếp, đặc biệt, bất ngờ, hoặc l&agrave; hậu quả của sự kiện kh&aacute;c, bao gồm nhưng kh&ocirc;ng giới hạn trong c&aacute;c thiệt hại trong kinh doanh hoặc lợi nhuận, thiệt hại ph&aacute;t sinh từ hoặc li&ecirc;n quan đến việc truy cập, sử dụng hoặc hiệu quả hoạt động của website ngay cả khi về khả năng xảy ra c&aacute;c tổn thất đ&oacute; c&oacute; thể nh&igrave;n thấy trước hoặc đ&atilde; được khuyến c&aacute;o trước. Bạn đồng &yacute; v&agrave; thừa nhận cụ thể rằng ch&uacute;ng t&ocirc;i cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; với mọi h&agrave;nh vi n&oacute;i xấu, tấn c&ocirc;ng, kh&ocirc;ng trung thực hoặc c&aacute;c h&agrave;nh vi bất hợp ph&aacute;p kh&aacute;c của bất kỳ người n&agrave;o sử dụng website n&agrave;y. Nếu bạn kh&ocirc;ng bằng l&ograve;ng với bất kỳ nội dụng n&agrave;o của website n&agrave;y th&igrave; biện ph&aacute;p duy nhất d&agrave;nh cho bạn l&agrave; chấm dứt truy cập v&agrave; sử dụng website n&agrave;y. BỒI THƯỜNG Bạn đồng &yacute; bảo vệ, bồi thường v&agrave; loại trừ Suntory PepsiCo khỏi những nghĩa vụ ph&aacute;p l&yacute;, tố tụng, tổn thất, chi ph&iacute; (bao gồm cả chi ph&iacute; cho luật sư) c&oacute; li&ecirc;n quan tới hoặc ph&aacute;t sinh từ việc sử dụng Website n&agrave;y của bạn. LI&Ecirc;N KẾT ĐẾN C&Aacute;C WEBSITE CỦA B&Ecirc;N THỨ BA Bạn thừa nhận v&agrave; đồng &yacute; rằng Suntory PepsiCo kh&ocirc;ng c&oacute; tr&aacute;ch nhiệm với bất kỳ website của c&aacute;c b&ecirc;n thứ ba (kh&ocirc;ng phải c&aacute;c trang do ch&uacute;ng t&ocirc;i quản l&yacute;) được li&ecirc;n kết đến hoặc từ website n&agrave;y. C&aacute;c website của c&aacute;c b&ecirc;n thứ ba được li&ecirc;n kết đến hoặc từ website n&agrave;y được điều h&agrave;nh v&agrave; duy tr&igrave; ho&agrave;n to&agrave;n độc lập bởi c&aacute;c b&ecirc;n thứ ba đ&oacute; v&agrave; c&oacute; c&aacute;c điều khoản v&agrave; điều kiện quy định ri&ecirc;ng kh&ocirc;ng nằm trong quyền điều khiển v&agrave;/hoặc gi&aacute;m s&aacute;t của ch&uacute;ng t&ocirc;i. Ch&uacute;ng t&ocirc;i kh&ocirc;ng đảm bảo hay chịu tr&aacute;ch nhiệm với bất kỳ nội dung, quảng c&aacute;o, sản phẩm hay dịch vụ n&agrave;o xuất hiện hoặc được cung cấp tr&ecirc;n c&aacute;c website li&ecirc;n kết đến v&agrave; đi từ website n&agrave;y, cũng như kh&ocirc;ng chịu tr&aacute;ch nhiệm cho sự mất m&aacute;t hoặc thiệt hại do việc truy cập v&agrave; sử dụng c&aacute;c website đ&oacute;. Việc truy cập c&aacute;c website của b&ecirc;n thứ ba li&ecirc;n kết tới v&agrave; đi từ website n&agrave;y thuộc phạm tr&ugrave; rủi ro của ri&ecirc;ng bạn. TH&Ocirc;NG TIN C&Aacute; NH&Acirc;N Khi truy cập v&agrave; sử dụng website n&agrave;y, để bạn c&oacute; thể sử dụng một số chức năng v&agrave; dịch vụ, ch&uacute;ng t&ocirc;i c&oacute; thể y&ecirc;u cầu bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n cho ch&uacute;ng t&ocirc;i qua website n&agrave;y. QUY ĐỊNH VỀ T&Agrave;I KHOẢN HỌC TRỰC TUYẾN E-LEARNING Về t&agrave;i khoản đăng nhập: Để sử dụng dịch vụ học trực tuyến E-learning của website n&agrave;y, bạn vui l&ograve;ng đăng k&yacute; t&agrave;i khoản bằng c&aacute;ch cung cấp đầy đủ, trung thực v&agrave; ch&iacute;nh x&aacute;c c&aacute;c th&ocirc;ng tin c&aacute; nh&acirc;n của m&igrave;nh như t&ecirc;n, email, số điện thoại, nghề nghiệp, nơi c&ocirc;ng t&aacute;c, &hellip; Đ&acirc;y l&agrave; những th&ocirc;ng tin bắt buộc để tạo điều kiện cho ch&uacute;ng t&ocirc;i cung cấp dịch vụ m&agrave; bạn y&ecirc;u cầu v&agrave; tạo sự thuận lợi cho ch&uacute;ng t&ocirc;i trong việc hỗ trợ người sử dụng dịch vụ học trực tuyến E-learning của ch&uacute;ng t&ocirc;i. Trong trường hợp bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n kh&ocirc;ng ch&iacute;nh x&aacute;c, thiếu trung thực th&igrave; bất cứ một sự cố hay vấn đề n&agrave;o ph&aacute;t sinh trong phạm vi t&agrave;i khoản của bạn th&igrave; đều thuộc tr&aacute;ch nhiệm của bạn. Th&ocirc;ng tin c&aacute; nh&acirc;n của bạn sẽ được quản l&yacute; v&agrave; sử dụng theo Ch&iacute;nh s&aacute;ch Bảo mật. Mật khẩu của t&agrave;i khoản đăng nhập: Trong phần quản l&yacute; t&agrave;i khoản, đối với một t&agrave;i khoản, người sử dụng sẽ c&oacute; một mật khẩu. Mật khẩu được sử dụng để đăng nhập v&agrave;o dịch vụ học trực tuyến E-learning tr&ecirc;n website n&agrave;y. Bạn c&oacute; tr&aacute;ch nhiệm tự bảo mật th&ocirc;ng tin t&agrave;i khoản. Nếu mật khẩu bị lộ ra ngo&agrave;i dưới bất kỳ h&igrave;nh thức n&agrave;o, ch&uacute;ng t&ocirc;i sẽ kh&ocirc;ng chịu tr&aacute;ch nhiệm về mọi tổn thất ph&aacute;t sinh. CHẤM DỨT DỊCH VỤ Suntory PepsiCo c&oacute; to&agrave;n quyền chấm dứt hoạt động của website n&agrave;y, hoặc chấm dứt việc truy cập website n&agrave;y của bạn, với bất kỳ l&yacute; do n&agrave;o, m&agrave; kh&ocirc;ng cần th&ocirc;ng b&aacute;o cho bạn cũng như kh&ocirc;ng c&oacute; bất kỳ tr&aacute;ch nhiệm n&agrave;o với bạn cũng nhưng bất cứ b&ecirc;n thứ ba n&agrave;o. LUẬT &Aacute;P DỤNG Bản Điều khoản Sử dụng n&agrave;y được điều chỉnh v&agrave; giải th&iacute;ch theo luật ph&aacute;p hiện h&agrave;nh của Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam. Th&ocirc;ng qua việc đăng k&yacute; hoặc sử dụng website của ch&uacute;ng t&ocirc;i, bạn đồng &yacute; v&agrave; tu&acirc;n thủ ph&aacute;n x&eacute;t của t&ograve;a &aacute;n Nước Cộng h&ograve;a X&atilde; hội Chủ nghĩa Việt Nam khi xảy ra bất kỳ vi phạm n&agrave;o li&ecirc;n quan đến những Điều khoản Sử dụng n&agrave;y. Một điều khoản sử dụng bị v&ocirc; hiệu theo quyết định của t&ograve;a &aacute;n c&oacute; thẩm quyền sẽ kh&ocirc;ng ảnh hưởng đến t&iacute;nh hiệu lực của c&aacute;c điều khoản c&ograve;n lại. C&aacute;c Điều khoản Sử dụng n&agrave;y c&oacute; hiệu lực kể từ ng&agrave;y website ch&iacute;nh thức đi v&agrave;o hoạt động</p>','private-policy',1,'',0,'en',0,'0','2019-12-04 10:15:11',1,'2019-12-10 09:21:02',1,NULL,NULL),
	(17,16,NULL,'Chính sách bảo mật','chinh-sach-bao-mat',NULL,NULL,'<p>Ch&iacute;nh s&aacute;ch bảo mật Xin vui l&ograve;ng đọc kỹ c&aacute;c Điều khoản Sử dụng dưới đ&acirc;y trước khi sử dụng trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn Trang th&ocirc;ng tin điện tử *Mizuiku-emyeunuocsach.vn, sau đ&acirc;y được gọi l&agrave; &ldquo;website&rdquo; được sở hữu v&agrave; vận h&agrave;nh bởi c&ocirc;ng ty TNHH Nước Giải kh&aacute;t Suntory PepsiCo Việt Nam, sau đ&acirc;y được gọi l&agrave; &ldquo;Suntory PepsiCo&rdquo;, hoặc &ldquo;ch&uacute;ng t&ocirc;i&rdquo;. Bằng việc truy cập v&agrave; sử dụng website n&agrave;y, bạn c&ocirc;ng nhận rằng bạn đ&atilde; đọc, hiểu v&agrave; nhất tr&iacute; với việc tu&acirc;n thủ quy định của những Điều khoản Sử dụng. Suntory PepsiCo c&oacute; to&agrave;n quyền thay đổi nội dung của website cũng như c&aacute;c Điều khoản Sử dụng n&agrave;y v&agrave;o bất kỳ thời điểm n&agrave;o m&agrave; kh&ocirc;ng c&oacute; nghĩa vụ th&ocirc;ng b&aacute;o với bạn. Bạn n&ecirc;n thường xuy&ecirc;n truy cập website để cập nhật về c&aacute;c thay đổi. Bạn đồng &yacute; rằng việc bạn tiếp tục sử dụng website đồng nghĩa với việc bạn đồng &yacute; với những Điều khoản Sử dụng cập nhật nhất tại thời điểm đ&oacute;. VIỆC SỬ DỤNG WEBSITE CỦA BẠN Bạn đồng &yacute; sẽ kh&ocirc;ng sử dụng website cho những mục đích bất hợp ph&aacute;p theo quy định của ph&aacute;p luật Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam hay bị cấm bởi c&aacute;c Điều khoản Sử dụng hay bất cứ điều luật li&ecirc;n quan n&agrave;o kh&aacute;c. Bạn c&oacute; thể truy cập, xem, sao ch&eacute;p v&agrave; tải c&aacute;c nội dung tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc mục đ&iacute;ch phi thương mại với điều kiện bạn kh&ocirc;ng sửa đổi hay x&oacute;a bỏ c&aacute;c bản quyền, thương hiệu c&oacute; tr&ecirc;n c&aacute;c t&agrave;i liệu m&agrave; bạn truy cập, xem, sao ch&eacute;p v&agrave; tải từ website n&agrave;y. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c bao gồm nhưng kh&ocirc;ng giới hạn trong sao ch&eacute;p, sửa đổi, ph&acirc;n phối, truyền, tải, cấp ph&eacute;p, hay tạo ra c&aacute;c biến thể từ c&aacute;c nội dung thu được từ website n&agrave;y m&agrave; kh&ocirc;ng được sự đồng &yacute; bằng văn bản của Suntory PepsiCo đều bị nghi&ecirc;m cấm. Bạn đồng &yacute; kh&ocirc;ng x&acirc;m phạm quyền, giới hạn hoặc ngăn cấm người kh&aacute;c sử dụng website n&agrave;y. Bạn sẽ kh&ocirc;ng can thiệp, x&acirc;m phạm hay ph&aacute; hoại bất kỳ chức năng an ninh n&agrave;o của website n&agrave;y hay kh&ocirc;ng gửi bất kỳ th&ocirc;ng tin hay phần mềm n&agrave;o c&oacute; chứa bất kỳ loại virus, Trojan, s&acirc;u hay bất kỳ th&agrave;nh phần nguy hại n&agrave;o qua website n&agrave;y. NỘI DUNG BẠN CUNG CẤP Bạn đảm bảo rằng bạn sẽ chịu tr&aacute;ch nhiệm trước ph&aacute;p luật với bất kỳ nội dung n&agrave;o m&agrave; bạn đăng tải tr&ecirc;n website n&agrave;y bao gồm t&iacute;nh hợp ph&aacute;p, t&iacute;nh ch&iacute;nh x&aacute;c, ph&ugrave; hợp v&agrave; bản quyền đối với nội dung đ&oacute;. Với việc cung cấp nội dung cho Suntory PepsiCo, bạn đồng &yacute; trao cho ch&uacute;ng t&ocirc;i to&agrave;n bộ quyền v&agrave; cấp ph&eacute;p sử dụng, t&aacute;i sản xuất, chỉnh sửa, l&agrave;m cho ph&ugrave; hợp, xuất bản, dịch, tạo ra c&aacute;c phi&ecirc;n bản kh&aacute;c, ph&acirc;n phối v&agrave; trưng b&agrave;y nội dung được bạn cung cấp tr&ecirc;n phạm vi to&agrave;n cầu bằng bất cứ phương tiện truyền th&ocirc;ng n&agrave;o m&agrave; kh&ocirc;ng đ&ograve;i hỏi th&ugrave; lao. Bạn trao cho ch&uacute;ng t&ocirc;i quyền được sử dụng t&ecirc;n gọi m&agrave; bạn cung cấp li&ecirc;n quan đến nội dung được bạn đăng tải khi cần thiết. Tất cả th&ocirc;ng tin c&aacute; nh&acirc;n được cung cấp tr&ecirc;n website n&agrave;y sẽ được sử dụng v&agrave; quản l&yacute; theo đ&uacute;ng Ch&iacute;nh s&aacute;ch Bảo mật của website n&agrave;y. Bạn bảo đảm rằng bạn sở hữu hoặc c&oacute; tất cả c&aacute;c quyền ph&aacute;p l&yacute; đối với nội dung bạn cung cấp tr&ecirc;n website n&agrave;y; rằng nội dung bạn cung cấp l&agrave; ch&iacute;nh x&aacute;c; rằng việc sử dụng nội dung bạn cung cấp kh&ocirc;ng vi phạm bất kỳ điều khoản n&agrave;o được quy định trong bản Điều khoản sử dụng n&agrave;y v&agrave; sẽ kh&ocirc;ng g&acirc;y ra tổn thất cho bất kỳ ai; rằng bạn sẽ loại trừ ch&uacute;ng t&ocirc;i khỏi tất cả c&aacute;c khiếu nại xuất ph&aacute;t từ nội dung m&agrave; bạn cung cấp. QUYỀN SỞ HỮU TR&Iacute; TUỆ Tất cả c&aacute;c bản quyền, thương hiệu hay bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o thuộc website n&agrave;y đều thuộc sở hữu của Suntory PepsiCo hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ trường hợp được quy định trong bản Điều khoản Sử dụng n&agrave;y, việc bạn truy cập, sử dụng website n&agrave;y kh&ocirc;ng đồng nghĩa với việc trao cho bạn bất kỳ quyền sở hữu hay cấp ph&eacute;p cho bạn đối với bất kỳ quyền sở hữu tr&iacute; tuệ n&agrave;o n&ecirc;u tr&ecirc;n. Bạn được ph&eacute;p sử dụng bất kỳ nội dung hay t&agrave;i liệu tr&ecirc;n website n&agrave;y cho mục đ&iacute;ch c&aacute; nh&acirc;n hoặc phi thương mại. C&aacute;c h&agrave;nh vi sử dụng website n&agrave;y cho bất kỳ mục đ&iacute;ch n&agrave;o kh&aacute;c phải c&oacute; c&oacute; sự cho ph&eacute;p bằng văn bản của ch&uacute;ng t&ocirc;i hoặc b&ecirc;n thứ ba cấp ph&eacute;p cho ch&uacute;ng t&ocirc;i. Trừ khi được quy định trong Điều khoản quy định n&agrave;y, bất cứ h&agrave;nh vi sử dụng t&agrave;i liệu hay nội dung n&agrave;o thuộc website n&agrave;y, bao gồm sao ch&eacute;p, t&aacute;i sản xuất, truyền, ph&acirc;n phối, khai th&aacute;c cho mục đ&iacute;ch thương mại hay tạo ra c&aacute;c biến thể kh&aacute;c đều bị nghi&ecirc;m cấm. Website n&agrave;y v&agrave; tất cả nội dung thuộc website được bảo hộ theo quy định của Luật Sở hữu tr&iacute; tuệ Việt Nam v&agrave; c&aacute;c văn bản luật li&ecirc;n quan. TỪ CHỐI ĐẢM BẢO BẠN ĐỒNG &Yacute; RẰNG VIỆC SỬ DỤNG WEBSITE N&Agrave;Y THUỘC PHẠM TR&Ugrave; RỦI RO CỦA RI&Ecirc;NG BẠN V&Agrave; KH&Ocirc;NG THUỘC TR&Aacute;CH NHIỆM CỦA CH&Uacute;NG T&Ocirc;I. WEBSITE N&Agrave;Y V&Agrave; NỘI DUNG TR&Ecirc;N WEBSITE N&Agrave;Y, BAO GỒM NHƯNG KH&Ocirc;NG GIỚI HẠN Ở C&Aacute;C TH&Ocirc;NG TIN, T&Agrave;I LIỆU, THIẾT KẾ, ĐỒ HỌA, GIAO DIỆN, H&Igrave;NH ẢNH, M&Atilde; CODE, PHẦN MỀM, NH&Atilde;N HIỆU, T&Ecirc;N THƯƠNG MẠI, C&Aacute;C LOGO, CŨNG NHƯ SẢN PHẨM, DỊCH VỤ THUỘC SỞ HỮU HAY LI&Ecirc;N QUAN ĐẾN SUNTORY PEPSICO HAY BẤT KỲ B&Ecirc;N THỨ BA N&Agrave;O ĐƯỢC CUNG CẤP CHO BẠN TR&Ecirc;N CƠ SỞ &ldquo;NHƯ ĐANG C&Oacute;&rdquo; V&Agrave; CH&Uacute;NG T&Ocirc;I TỪ CHỐI MỌI BẢO ĐẢM THEO BẤT KỲ PHƯƠNG THỨC N&Agrave;O, D&Ugrave; L&Agrave; H&Agrave;M &Yacute; HAY C&Ocirc;NG BỐ, BAO GỒM NHƯNG KH&Ocirc;NG CHỈ GIỚI HẠN TRONG C&Aacute;C BẢO ĐẢM VỀ KHẢ NĂNG B&Aacute;N SẢN PHẨM, CHẤT LƯỢNG, SỰ PH&Ugrave; HỢP VỚI MỘT MỤC Đ&Iacute;CH CỤ THỂ N&Agrave;O Đ&Oacute;, SỰ KH&Ocirc;NG VI PHẠM, SỰ TƯƠNG TH&Iacute;CH, SỰ AN TO&Agrave;N, CH&Iacute;NH X&Aacute;C HAY HO&Agrave;N CHỈNH CỦA BẤT KỲ NỘI DUNG N&Agrave;O TR&Ecirc;N WEBSITE N&Agrave;Y. NGOẠI TRỪ ĐƯỢC QUY ĐỊNH BỞI PH&Aacute;P LUẬT, CH&Uacute;NG T&Ocirc;I KH&Ocirc;NG ĐẢM BẢO RẰNG NỘI DUNG THUỘC WEBSITE N&Agrave;Y, HAY BẤT KỲ T&Iacute;NH NĂNG N&Agrave;O CỦA WEBSITE N&Agrave;Y SẼ KH&Ocirc;NG BỊ GI&Aacute;N ĐOẠN, KH&Ocirc;NG C&Oacute; LỖI, KH&Ocirc;NG C&Oacute; VIRUS, HAY SẼ LU&Ocirc;N TƯƠNG TH&Iacute;CH VỚI BẤT KỲ PHẦN MỀM HAY NỘI DUNG N&Agrave;O KH&Aacute;C. GIỚI HẠN TR&Aacute;CH NHIỆM PH&Aacute;P L&Yacute; Trong bất kỳ trường hợp n&agrave;o, Suntory PepsiCo cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i cũng kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; cho bất kỳ tổn thất n&agrave;o, d&ugrave; l&agrave; trực tiếp, gi&aacute;n tiếp, đặc biệt, bất ngờ, hoặc l&agrave; hậu quả của sự kiện kh&aacute;c, bao gồm nhưng kh&ocirc;ng giới hạn trong c&aacute;c thiệt hại trong kinh doanh hoặc lợi nhuận, thiệt hại ph&aacute;t sinh từ hoặc li&ecirc;n quan đến việc truy cập, sử dụng hoặc hiệu quả hoạt động của website ngay cả khi về khả năng xảy ra c&aacute;c tổn thất đ&oacute; c&oacute; thể nh&igrave;n thấy trước hoặc đ&atilde; được khuyến c&aacute;o trước. Bạn đồng &yacute; v&agrave; thừa nhận cụ thể rằng ch&uacute;ng t&ocirc;i cũng như c&ocirc;ng ty mẹ, hoặc c&aacute;c chi nh&aacute;nh, cũng như Ban Gi&aacute;m đốc, nh&acirc;n vi&ecirc;n, cổ đ&ocirc;ng hay đại diện của ch&uacute;ng t&ocirc;i kh&ocirc;ng chịu tr&aacute;ch nhiệm ph&aacute;p l&yacute; với mọi h&agrave;nh vi n&oacute;i xấu, tấn c&ocirc;ng, kh&ocirc;ng trung thực hoặc c&aacute;c h&agrave;nh vi bất hợp ph&aacute;p kh&aacute;c của bất kỳ người n&agrave;o sử dụng website n&agrave;y. Nếu bạn kh&ocirc;ng bằng l&ograve;ng với bất kỳ nội dụng n&agrave;o của website n&agrave;y th&igrave; biện ph&aacute;p duy nhất d&agrave;nh cho bạn l&agrave; chấm dứt truy cập v&agrave; sử dụng website n&agrave;y. BỒI THƯỜNG Bạn đồng &yacute; bảo vệ, bồi thường v&agrave; loại trừ Suntory PepsiCo khỏi những nghĩa vụ ph&aacute;p l&yacute;, tố tụng, tổn thất, chi ph&iacute; (bao gồm cả chi ph&iacute; cho luật sư) c&oacute; li&ecirc;n quan tới hoặc ph&aacute;t sinh từ việc sử dụng Website n&agrave;y của bạn. LI&Ecirc;N KẾT ĐẾN C&Aacute;C WEBSITE CỦA B&Ecirc;N THỨ BA Bạn thừa nhận v&agrave; đồng &yacute; rằng Suntory PepsiCo kh&ocirc;ng c&oacute; tr&aacute;ch nhiệm với bất kỳ website của c&aacute;c b&ecirc;n thứ ba (kh&ocirc;ng phải c&aacute;c trang do ch&uacute;ng t&ocirc;i quản l&yacute;) được li&ecirc;n kết đến hoặc từ website n&agrave;y. C&aacute;c website của c&aacute;c b&ecirc;n thứ ba được li&ecirc;n kết đến hoặc từ website n&agrave;y được điều h&agrave;nh v&agrave; duy tr&igrave; ho&agrave;n to&agrave;n độc lập bởi c&aacute;c b&ecirc;n thứ ba đ&oacute; v&agrave; c&oacute; c&aacute;c điều khoản v&agrave; điều kiện quy định ri&ecirc;ng kh&ocirc;ng nằm trong quyền điều khiển v&agrave;/hoặc gi&aacute;m s&aacute;t của ch&uacute;ng t&ocirc;i. Ch&uacute;ng t&ocirc;i kh&ocirc;ng đảm bảo hay chịu tr&aacute;ch nhiệm với bất kỳ nội dung, quảng c&aacute;o, sản phẩm hay dịch vụ n&agrave;o xuất hiện hoặc được cung cấp tr&ecirc;n c&aacute;c website li&ecirc;n kết đến v&agrave; đi từ website n&agrave;y, cũng như kh&ocirc;ng chịu tr&aacute;ch nhiệm cho sự mất m&aacute;t hoặc thiệt hại do việc truy cập v&agrave; sử dụng c&aacute;c website đ&oacute;. Việc truy cập c&aacute;c website của b&ecirc;n thứ ba li&ecirc;n kết tới v&agrave; đi từ website n&agrave;y thuộc phạm tr&ugrave; rủi ro của ri&ecirc;ng bạn. TH&Ocirc;NG TIN C&Aacute; NH&Acirc;N Khi truy cập v&agrave; sử dụng website n&agrave;y, để bạn c&oacute; thể sử dụng một số chức năng v&agrave; dịch vụ, ch&uacute;ng t&ocirc;i c&oacute; thể y&ecirc;u cầu bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n cho ch&uacute;ng t&ocirc;i qua website n&agrave;y. QUY ĐỊNH VỀ T&Agrave;I KHOẢN HỌC TRỰC TUYẾN E-LEARNING Về t&agrave;i khoản đăng nhập: Để sử dụng dịch vụ học trực tuyến E-learning của website n&agrave;y, bạn vui l&ograve;ng đăng k&yacute; t&agrave;i khoản bằng c&aacute;ch cung cấp đầy đủ, trung thực v&agrave; ch&iacute;nh x&aacute;c c&aacute;c th&ocirc;ng tin c&aacute; nh&acirc;n của m&igrave;nh như t&ecirc;n, email, số điện thoại, nghề nghiệp, nơi c&ocirc;ng t&aacute;c, &hellip; Đ&acirc;y l&agrave; những th&ocirc;ng tin bắt buộc để tạo điều kiện cho ch&uacute;ng t&ocirc;i cung cấp dịch vụ m&agrave; bạn y&ecirc;u cầu v&agrave; tạo sự thuận lợi cho ch&uacute;ng t&ocirc;i trong việc hỗ trợ người sử dụng dịch vụ học trực tuyến E-learning của ch&uacute;ng t&ocirc;i. Trong trường hợp bạn cung cấp th&ocirc;ng tin c&aacute; nh&acirc;n kh&ocirc;ng ch&iacute;nh x&aacute;c, thiếu trung thực th&igrave; bất cứ một sự cố hay vấn đề n&agrave;o ph&aacute;t sinh trong phạm vi t&agrave;i khoản của bạn th&igrave; đều thuộc tr&aacute;ch nhiệm của bạn. Th&ocirc;ng tin c&aacute; nh&acirc;n của bạn sẽ được quản l&yacute; v&agrave; sử dụng theo Ch&iacute;nh s&aacute;ch Bảo mật. Mật khẩu của t&agrave;i khoản đăng nhập: Trong phần quản l&yacute; t&agrave;i khoản, đối với một t&agrave;i khoản, người sử dụng sẽ c&oacute; một mật khẩu. Mật khẩu được sử dụng để đăng nhập v&agrave;o dịch vụ học trực tuyến E-learning tr&ecirc;n website n&agrave;y. Bạn c&oacute; tr&aacute;ch nhiệm tự bảo mật th&ocirc;ng tin t&agrave;i khoản. Nếu mật khẩu bị lộ ra ngo&agrave;i dưới bất kỳ h&igrave;nh thức n&agrave;o, ch&uacute;ng t&ocirc;i sẽ kh&ocirc;ng chịu tr&aacute;ch nhiệm về mọi tổn thất ph&aacute;t sinh. CHẤM DỨT DỊCH VỤ Suntory PepsiCo c&oacute; to&agrave;n quyền chấm dứt hoạt động của website n&agrave;y, hoặc chấm dứt việc truy cập website n&agrave;y của bạn, với bất kỳ l&yacute; do n&agrave;o, m&agrave; kh&ocirc;ng cần th&ocirc;ng b&aacute;o cho bạn cũng như kh&ocirc;ng c&oacute; bất kỳ tr&aacute;ch nhiệm n&agrave;o với bạn cũng nhưng bất cứ b&ecirc;n thứ ba n&agrave;o. LUẬT &Aacute;P DỤNG Bản Điều khoản Sử dụng n&agrave;y được điều chỉnh v&agrave; giải th&iacute;ch theo luật ph&aacute;p hiện h&agrave;nh của Nước Cộng ho&agrave; X&atilde; hội Chủ nghĩa Việt Nam. Th&ocirc;ng qua việc đăng k&yacute; hoặc sử dụng website của ch&uacute;ng t&ocirc;i, bạn đồng &yacute; v&agrave; tu&acirc;n thủ ph&aacute;n x&eacute;t của t&ograve;a &aacute;n Nước Cộng h&ograve;a X&atilde; hội Chủ nghĩa Việt Nam khi xảy ra bất kỳ vi phạm n&agrave;o li&ecirc;n quan đến những Điều khoản Sử dụng n&agrave;y. Một điều khoản sử dụng bị v&ocirc; hiệu theo quyết định của t&ograve;a &aacute;n c&oacute; thẩm quyền sẽ kh&ocirc;ng ảnh hưởng đến t&iacute;nh hiệu lực của c&aacute;c điều khoản c&ograve;n lại. C&aacute;c Điều khoản Sử dụng n&agrave;y c&oacute; hiệu lực kể từ ng&agrave;y website ch&iacute;nh thức đi v&agrave;o hoạt động</p>','private-policy',1,'',0,'vi',0,'0','2019-12-04 10:15:11',1,'2019-12-10 09:20:48',1,NULL,NULL),
	(18,18,2,'LỄ TỔNG KẾT CHƯƠNG TRÌNH “MIZUIKU – EM YÊU NƯỚC SẠCH” NĂM 2019','le-tong-ket-chuong-trinh-mizuiku-em-yeu-nuoc-sach-nam-2019','news/2019/12/5def663eca316_76952858__637109873901314906.jpg','Tham dự lễ tổng kết có bà Yuko Koshiishi, Giám đốc cấp cao phòng Chiến lược phát triển bền vững, Tập đoàn Suntory Holdings Limited; Bà Wu MaySan, Phó..','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Về ph&iacute;a Trung Ương Đo&agrave;n TNCS Hồ Ch&iacute; Minh c&oacute; đồng ch&iacute; B&ugrave;i Minh Tuấn, Ủy vi&ecirc;n Ban Chấp h&agrave;nh Trung ương Đo&agrave;n, Ph&oacute; Chủ tịch Trung ương Hội Sinh vi&ecirc;n Việt Nam; Đồng ch&iacute; Nguyễn Phạm Duy Trang, Ủy vi&ecirc;n Ban Thường vụ Trung ương Đo&agrave;n, Ph&oacute; Chủ tịch thường trực Hội đồng Đội Trung ương; đại diện Trung t&acirc;m Live &amp; Learn đại diện c&aacute;c đơn vị t&agrave;i trợ; l&atilde;nh đạo đại diện c&aacute;c bộ, ban, ng&agrave;nh, đo&agrave;n thể Trung ương; c&aacute;c đồng ch&iacute; l&atilde;nh đạo, c&aacute;n bộ c&aacute;c ban, đơn vị thuộc Trung ương Đo&agrave;n, Hội đồng Đội Trung ương; l&atilde;nh đạo tỉnh Quảng Nam; đại diện Hội đồng Đội, Hội Sinh vi&ecirc;n một số tỉnh, th&agrave;nh phố triển khai chương tr&igrave;nh; đại diện Ban Gi&aacute;m hiệu v&agrave; c&aacute;c thầy c&ocirc; tham gia chương tr&igrave;nh tr&ecirc;n địa b&agrave;n tỉnh Quảng Nam, c&aacute;c thầy c&ocirc; gi&aacute;o v&agrave; gần 300 em thiếu nhi trường Tiểu học Duy Th&agrave;nh &nbsp;c&ugrave;ng tham dự.</span></p>\r\n<p style=\"text-align: center;\"><img src=\"http://127.0.0.1:8000/photos/1/2.jpg\" alt=\"\" width=\"100%\" /></p>',NULL,1,NULL,0,'vi',0,'0','2019-12-10 09:31:49',1,'2019-12-11 15:59:47',1,'2019-12-11 15:59:47',1),
	(19,19,2,'LỄ TỔNG KẾT CHƯƠNG TRÌNH “MIZUIKU – EM YÊU NƯỚC SẠCH” NĂM 2019','le-tong-ket-chuong-trinh-mizuiku-em-yeu-nuoc-sach-nam-2019-1','news/2019/12/5df11262743ab_78695012_481642575788018_1000115321358516224_n.jpg','Tham dự lễ tổng kết có bà Yuko Koshiishi, Giám đốc cấp cao phòng Chiến lược phát triển bền vững, Tập đoàn Suntory Holdings Limited; Bà Wu MaySan,','<p>Về ph&iacute;a Trung Ương Đo&agrave;n TNCS Hồ Ch&iacute; Minh c&oacute; đồng ch&iacute; B&ugrave;i Minh Tuấn, Ủy vi&ecirc;n Ban Chấp h&agrave;nh Trung ương Đo&agrave;n, Ph&oacute; Chủ tịch Trung ương Hội Sinh vi&ecirc;n Việt Nam; Đồng ch&iacute; Nguyễn Phạm Duy Trang, Ủy vi&ecirc;n Ban Thường vụ Trung ương Đo&agrave;n, Ph&oacute; Chủ tịch thường trực Hội đồng Đội Trung ương; đại diện Trung t&acirc;m Live &amp; Learn đại diện c&aacute;c đơn vị t&agrave;i trợ; l&atilde;nh đạo đại diện c&aacute;c bộ, ban, ng&agrave;nh, đo&agrave;n thể Trung ương; c&aacute;c đồng ch&iacute; l&atilde;nh đạo, c&aacute;n bộ c&aacute;c ban, đơn vị thuộc Trung ương Đo&agrave;n, Hội đồng Đội Trung ương; l&atilde;nh đạo tỉnh Quảng Nam; đại diện Hội đồng Đội, Hội Sinh vi&ecirc;n một số tỉnh, th&agrave;nh phố triển khai chương tr&igrave;nh; đại diện Ban Gi&aacute;m hiệu v&agrave; c&aacute;c thầy c&ocirc; tham gia chương tr&igrave;nh tr&ecirc;n địa b&agrave;n tỉnh Quảng Nam, c&aacute;c thầy c&ocirc; gi&aacute;o v&agrave; gần 300 em thiếu nhi trường Tiểu học Duy Th&agrave;nh &nbsp;c&ugrave;ng tham dự.<br /><br /><img src=\"https://mizuiku-emyeunuocsach.vn/pic/News/images/78695012_481642575788018_1000115321358516224_n.jpg\" alt=\"\" /><br /><em>C&aacute;c em học sinh chụp h&igrave;nh lưu niệm c&ugrave;ng đại biểu chương tr&igrave;nh Mizuiku &ndash; Em y&ecirc;u nước sạch 2019</em><br /><br />Chương tr&igrave;nh &ldquo;Mizuiku - Em y&ecirc;u nước sạch&rdquo; l&agrave; chương tr&igrave;nh gi&aacute;o dục về bảo vệ nguồn t&agrave;i nguy&ecirc;n nước d&agrave;nh cho học sinh tiểu học v&agrave; l&agrave; một trong những s&aacute;ng kiến được tập đo&agrave;n Suntory triển khai th&agrave;nh c&ocirc;ng tại Nhật Bản từ năm 2004. Từ năm 2015, chương tr&igrave;nh được tập đo&agrave;n Suntory, Suntory PepsiCo Việt Nam phối hợp với c&aacute;c đối t&aacute;c tại địa phương triển khai th&iacute; điểm th&agrave;nh c&ocirc;ng tại khu vực ph&iacute;a Bắc, sau đ&oacute; l&agrave; c&aacute;c tỉnh th&agrave;nh kh&aacute;c th&ocirc;ng qua việc đổi mới v&agrave; điều chỉnh ph&ugrave; hợp dựa tr&ecirc;n nền tảng &yacute; tưởng nguy&ecirc;n mẫu tại Nhật Bản, với nhiều s&aacute;ng kiến mới để tạo n&ecirc;n một chương tr&igrave;nh hấp dẫn, ph&ugrave; hợp với m&ocirc;i trường thực tiễn tại Việt Nam. Đến năm 2017, Hội đồng Đội Trung ương, Trung ương Hội Sinh vi&ecirc;n Việt Nam, Bộ Gi&aacute;o dục v&agrave; Đ&agrave;o tạo phối hợp với tập đo&agrave;n Suntory, Suntory PepsiCo Việt Nam triển khai chương tr&igrave;nh với quy m&ocirc; to&agrave;n quốc. Việt Nam l&agrave; quốc gia đầu ti&ecirc;n ngo&agrave;i Nhật Bản được Suntory lựa chọn triển khai chương tr&igrave;nh ngo&agrave;i Nhật Bản. Học hỏi từ m&ocirc; h&igrave;nh th&agrave;nh c&ocirc;ng tại Việt Nam, năm 2019 Suntory đ&atilde; mở rộng triển khai chương tr&igrave;nh tại Indonesia v&agrave; Th&aacute;i Lan.<br />&nbsp;<img src=\"https://mizuiku-emyeunuocsach.vn/pic/News/images/78119882_488120955381074_160307798897328128_n(1).jpg\" alt=\"\" /><br /><br /><em>B&agrave; Yuko Koshiishi, Gi&aacute;m đốc cấp cao ph&ograve;ng Chiến lược ph&aacute;t triển bền vững, Tập đo&agrave;n Suntory Holdings Limited ph&aacute;t biểu tại lễ tổng kết</em><br />&nbsp;<br />Ph&aacute;t biểu tại buổi lễ, b&agrave; Yuko Koshiishi cho biết trong năm 2019, chương tr&igrave;nh được triển khai tại 4 tỉnh th&agrave;nh l&agrave; Lạng Sơn, Quảng Nam, Bến Tre, Đồng Nai với 17 trường được thụ hưởng chương tr&igrave;nh. Trong đ&oacute;, 20 c&ocirc;ng tr&igrave;nh nước sạch v&agrave; nh&agrave; vệ sinh đ&atilde; được triển khai, gần 20.000 học sinh v&agrave; người d&acirc;n địa phương đ&atilde; được thụ hưởng từ c&aacute;c hoạt động của chương tr&igrave;nh năm nay bao gồm c&aacute;c lớp học Mizuiku, hệ thống m&aacute;y lọc nước, c&ocirc;ng tr&igrave;nh vệ sinh, c&aacute;c tương t&aacute;c fanpage v&agrave; website Mizuiku. Bộ truyện tranh &ldquo;Mizu &ndash; Giọt Nước Biết N&oacute;i&rdquo; về kiến thức bảo vệ nước sạch d&agrave;nh cho trẻ em từ 4 đến 10 tuổi đ&atilde; được xuất bản.<br />&nbsp;<br /><img src=\"https://mizuiku-emyeunuocsach.vn/pic/News/images/77023060_482799929025777_7212490742827057152_n.jpg\" alt=\"\" /><br />&nbsp;<br /><em>Trao tặng chứng nhận cho hội đồng đội c&aacute;c tỉnh triển khai chương tr&igrave;nh.</em><br />Tại chương tr&igrave;nh, Ban Tổ chức cũng trao tặng chứng nhận cho Hội đồng Đội c&aacute;c tỉnh Lạng Sơn, Quảng Nam, Bến Tre, Đồng Nai v&agrave; đại diện 17 trường tiểu học thụ hưởng chương tr&igrave;nh. Chương tr&igrave;nh sẽ tiếp tục được triển khai tại Việt Nam trong giai đoạn 2020 &ndash; 2022. Điểm mới của chương tr&igrave;nh trong c&aacute;c năm tới l&agrave; kiến thức về ph&acirc;n loại r&aacute;c thải sẽ được t&iacute;ch hợp v&agrave;o chương tr&igrave;nh giảng dạy, tiếp tục mở rộng hệ thống học trực tuyến E-learning, phối hợp với c&aacute;c t&igrave;nh nguyện vi&ecirc;n M&ugrave;a H&egrave; Xanh trong c&ocirc;ng t&aacute;c tổ chức lớp học, mở rộng chương tr&igrave;nh tới c&aacute;c nh&oacute;m đối tượng kh&aacute;c như trẻ em ở c&aacute;c trường quốc tế. Dự kiến sẽ tiếp tục phối hợp với Bộ Gi&aacute;o Dục &amp; Đ&agrave;o Tạo nhằm hướng đến việc giới thiệu c&aacute;c t&agrave;i liệu của chương tr&igrave;nh Muzuiku như t&agrave;i liệu tham khảo phục vụ cho c&aacute;c hoạt động trải nghiệm ngo&agrave;i giờ l&ecirc;n lớp trong c&aacute;c trường tiểu học tại Việt Nam.</p>',NULL,1,NULL,0,'vi',1,'0','2019-12-11 15:59:35',1,'2019-12-12 07:01:40',1,NULL,NULL),
	(20,20,2,'Hoạt động học tập và trải nghiệm thực tế Nông trại du lịch tại Bến Tre','hoat-dong-hoc-tap-va-trai-nghiem-thuc-te-nong-trai-du-lich-tai-ben-tre','news/2019/12/5df113d799001_DSCN239_637109870116432922.jpeg','Trong 05 ngày từ 21/10 - 26/10/2019 vừa qua, tập đoàn Suntory Holdings Limited, Công ty TNHH nước giải khát Suntory PepsiCo Việt Nam, Hội Đồng Đội TƯ','<p>Trong 05 ng&agrave;y từ 21/10 - 26/10/2019 vừa qua, tập đo&agrave;n Suntory Holdings Limited, C&ocirc;ng ty TNHH nước giải kh&aacute;t Suntory PepsiCo Việt Nam, Hội Đồng Đội TƯ, c&ugrave;ng tỉnh đo&agrave;n Bến Tre phối hợp tổ chức hoạt động d&atilde; ngoại tại N&ocirc;ng trại du lịch S&acirc;n chim V&agrave;m Hồ, học t&acirc;p v&agrave; trải nghiệm thi&ecirc;n nhi&ecirc;n thực tế, thuộc khu&ocirc;n khổ Chương tr&igrave;nh Mizuiku - Em y&ecirc;u nước sạch 2019 cho 500 em học sinh tiểu học khối lớp 3, 4; c&aacute;n bộ, gi&aacute;o vi&ecirc;n, Tổng phụ tr&aacute;ch Đội của trường Tiểu học An B&igrave;nh T&acirc;y, trường Tiểu học An H&ograve;a T&acirc;y, trường Tiểu học An Thủy 2, trường Tiểu học An Ph&uacute; Trung v&agrave; trường Tiểu học An Hiệp 2, thị x&atilde; Ba Tri, tỉnh Bế Tre.<br />&nbsp;<br /><img src=\"file:///C:/Users/80010435/AppData/Local/Temp/msohtmlclip1/01/clip_image002.jpg\" width=\"624\" height=\"468\" /><br />&nbsp;<br /><em>C&aacute;c em học sinh c&ugrave;ng lưu giữ khoảnh khắc đ&aacute;ng nhớ c&ugrave;ng thầy c&ocirc;</em><br /><br />Chuyến tham quan học tập v&agrave; trải nghiệm thực tế trong thi&ecirc;n nhi&ecirc;n theo m&ocirc; h&igrave;nh chương tr&igrave;nh Mizuiku tại Nhật Bản, hơn 500 em học sinh lớp 3 v&agrave; 4 đ&atilde; c&oacute; cơ hội t&igrave;m hiểu về bảo vệ rừng, bảo vệ m&ocirc;i trường, đặc biệt l&agrave; bảo vệ nguồn nước. C&aacute;c em được học về vai tr&ograve; giữ nước của lớp l&aacute; v&agrave; đất. C&aacute;c bạn được chia th&agrave;nh c&aacute;c nh&oacute;m nhỏ, tham quan quanh khu vực để cảm nhận về tầng địa sinh v&agrave; đưa ra nhận x&eacute;t với sự hướng dẫn của c&aacute;c chuy&ecirc;n gia v&agrave; gi&aacute;o vi&ecirc;n. C&aacute;c em sẽ được giới thiệu về th&aacute;c nước, tham gia c&aacute;c hoạt động t&igrave;m hiểu về c&aacute;c tầng thủy sinh quan s&aacute;t được tại th&aacute;c nước v&agrave; vẽ m&ocirc; phỏng tr&ecirc;n giấy hoặc thể hiện tr&ecirc;n chai nước v&agrave; thuyết tr&igrave;nh (tầng đ&aacute;y l&agrave; c&aacute;t, sỏi nhỏ, sỏi vừa, nước...), thực hiện c&aacute;c th&iacute; nghiệm về lọc nước, chơi c&aacute;c tr&ograve; chơi li&ecirc;n quan đến chủ đề m&ocirc;i trường,&hellip;<br />&nbsp;<br /><img src=\"file:///C:/Users/80010435/AppData/Local/Temp/msohtmlclip1/01/clip_image004.jpg\" width=\"624\" height=\"468\" /><br /><img src=\"file:///C:/Users/80010435/AppData/Local/Temp/msohtmlclip1/01/clip_image006.jpg\" width=\"624\" height=\"416\" /><br /><em>C&aacute;c bạn nhỏ rất h&agrave;o hứng với hoạt động nh&oacute;m độc đ&aacute;o</em><br />&nbsp;<br />C&aacute;c bạn học sinh được chia th&agrave;nh c&aacute;c nh&oacute;m, c&ugrave;ng trải nghiệm c&aacute;c hoạt động t&igrave;m hiểu về t&agrave;i nguy&ecirc;n nước, tầng địa sinh trong l&ograve;ng đất, chơi c&aacute;c tr&ograve; chơi li&ecirc;n quan đến m&ocirc;i trường&hellip;<br />&nbsp;<br />Chương tr&igrave;nh Mizuiku &ndash; Em y&ecirc;u nước sạch 2019, hoạt động học tập v&agrave; trải nghiệm thi&ecirc;n nhi&ecirc;n thực tế nhằm n&acirc;ng cao nhận thức của c&aacute;c em học sinh về vai tr&ograve; của t&agrave;i nguy&ecirc;n nước v&agrave; c&aacute;ch thức sử dụng hợp l&yacute; nguồn nước sạch, g&oacute;p phần bảo vệ nguồn nước v&agrave; rộng hơn l&agrave; m&ocirc;i trường sống xung quanh.<br /><br />Đồng thời, th&ocirc;ng qua chương tr&igrave;nh, tạo ra kh&ocirc;ng gian s&aacute;ng tạo, cơ hội thực h&agrave;nh v&agrave; s&acirc;n chơi đa dạng cho c&aacute;c em nhỏ nhằm k&iacute;ch th&iacute;ch &oacute;c quan s&aacute;t, &yacute; tưởng v&agrave; h&agrave;nh động của c&aacute;c em để bảo vệ nguồn nước n&oacute;i ri&ecirc;ng v&agrave; m&ocirc;i trường n&oacute;i chung.<br /><br />Chương tr&igrave;nh &ldquo;Mizuiku - Em y&ecirc;u nước sạch&rdquo; được tổ chức tại Bến Tre hứa hẹn sẽ g&oacute;p phần mang đến những chuyển biến t&iacute;ch cực trong việc n&acirc;ng cao &yacute; thức về tiết kiệm v&agrave; bảo vệ nguồn nước sạch qu&yacute; gi&aacute; cho c&aacute;c em học sinh</p>',NULL,1,NULL,0,'vi',1,'0','2019-12-11 16:03:18',1,'2019-12-12 07:01:37',1,NULL,NULL),
	(21,21,2,'Cùng Mizuiku trải nghiệm chuyến tham quan nhà máy Suntory PepsiCo Việt Nam.','cung-mizuiku-trai-nghiem-chuyen-tham-quan-nha-may-suntory-pepsico-viet-nam','news/2019/12/5df113a4ab02f_DSCN195_637109865044562736.jpeg','Hơn 1.200 học sinh và hơn 120 giáo viên, tổng phụ trách từ 12 trường thụ hưởng Chương trình Mizuiku – Em yêu nước sạch trong năm 2019 đã có chuyến','<div>C&ugrave;ng Mizuiku trải nghiệm chuyến tham quan nh&agrave; m&aacute;y Suntory PepsiCo Việt Nam.</div>\r\n<div>&nbsp;</div>\r\n<div>Hơn 1.200 học sinh v&agrave; hơn 120 gi&aacute;o vi&ecirc;n, tổng phụ tr&aacute;ch từ 12 trường thụ hưởng Chương tr&igrave;nh Mizuiku</div>\r\n<div>&ndash; Em y&ecirc;u nước sạch trong năm 2019 đ&atilde; c&oacute; chuyến tham quan &yacute; nghĩa tại 3 nh&agrave; m&aacute;y của c&ocirc;ng ty Suntory</div>\r\n<div>Pepsico Việt Nam ở Bắc Ninh, Quảng Nam v&agrave; Đồng Nai.</div>\r\n<div>&nbsp;</div>\r\n<div>C&aacute;c em học sinh v&agrave; thầy c&ocirc; chụp ảnh lưu niệm c&ugrave;ng đại diện nh&agrave; m&aacute;y</div>\r\n<div>&nbsp;</div>\r\n<div>Hoạt động n&agrave;y gi&uacute;p c&aacute;c em vận dụng kiến thức đ&atilde; học trong Chương tr&igrave;nh v&agrave;o thực tế, trực tiếp quan</div>\r\n<div>s&aacute;t, t&igrave;m hiểu c&aacute;c hoạt động tiết kiệm nước v&agrave; hệ thống xử l&yacute; nước thải tại c&aacute;c d&acirc;y chuyền sản xuất của</div>\r\n<div>nh&agrave; m&aacute;y</div>\r\n<div>&nbsp;</div>\r\n<div>Tham quan d&acirc;y chuyền sản xuất trong nh&agrave; m&aacute;y</div>\r\n<div>&nbsp;</div>\r\n<div>Trong chuyến đi, c&aacute;c em được tự m&igrave;nh quan s&aacute;t v&agrave; trải nghiệm c&ocirc;ng nghệ d&acirc;y chuyền kh&eacute;p k&iacute;n để sản</div>\r\n<div>xuất ra c&aacute;c sản phẩm nước giải kh&aacute;t quen thuộc trong cuộc sống hằng ng&agrave;y, để hiểu th&ecirc;m về c&ocirc;ng nghệ</div>\r\n<div>tiết kiệm nước v&agrave; xử l&yacute; nước thải của Suntory PepsiCo Việt Nam; đồng thời tham gia nhiều hoạt động</div>\r\n<div>th&uacute; vị như: đố vui, th&iacute; nghiệm về vai tr&ograve; của nước đối với tr&aacute;i đất, trải nghiệm ăn trưa tại nh&agrave; m&aacute;y&hellip;</div>\r\n<div>&nbsp;</div>\r\n<div>C&aacute;c em học sinh tham gia th&iacute; nghiệm lọc nước</div>\r\n<div>&nbsp;</div>\r\n<div>Chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; th&ocirc;ng qua phương ph&aacute;p gi&aacute;o dục lấy học sinh l&agrave;m trung</div>\r\n<div>t&acirc;m, chương tr&igrave;nh tạo ra kh&ocirc;ng gian s&aacute;ng tạo, cơ hội thực h&agrave;nh v&agrave; s&acirc;n chơi đa dạng cho c&aacute;c em nhỏ</div>\r\n<div>nhằm k&iacute;ch th&iacute;ch &oacute;c quan s&aacute;t, &yacute; tưởng v&agrave; h&agrave;nh động của c&aacute;c em để bảo vệ nguồn nước n&oacute;i ri&ecirc;ng v&agrave; m&ocirc;i</div>\r\n<div>trường n&oacute;i chung Cảm ơn c&aacute;c bạn nhỏ, thầy c&ocirc; đ&atilde; lu&ocirc;n đồng h&agrave;nh c&ugrave;ng chương tr&igrave;nh Mizuiku &ndash; Em y&ecirc;u</div>\r\n<div>nước sạch!</div>',NULL,1,NULL,0,'vi',1,'0','2019-12-11 16:04:56',1,'2019-12-12 07:01:33',1,NULL,NULL),
	(22,22,1,'Giải quyết bài toán ô nhiễm nước','giai-quyet-bai-toan-o-nhiem-nuoc','news/2019/12/5df115c5dc667_EN03_637069227525501530.jpg','Ô nhiễm nước đã nổi lên trở thành một mối đe dọa kinh tế liên quan đến nước lớn nhất cho Việt Nam.\r\nKinh nghiệm đã chỉ ra một cách thống nhất rằng ít có tác động nào mang lại lợi ích phát triển lớn và ngay lập tức như cung cấp nước sạch. Vì thế, tái sử dụng nước thải sẽ góp phần giải quyết vấn đề ô nhiễm nước một cách triệt để.','<p><strong>&Ocirc; nhiễm nước đ&atilde; nổi l&ecirc;n trở th&agrave;nh một mối đe dọa kinh tế li&ecirc;n quan đến nước lớn nhất cho Việt Nam.</strong></p>\r\n<p>Kinh nghiệm đ&atilde; chỉ ra một c&aacute;ch thống nhất rằng &iacute;t c&oacute; t&aacute;c động n&agrave;o mang lại lợi &iacute;ch ph&aacute;t triển lớn v&agrave; ngay lập tức như cung cấp nước sạch. V&igrave; thế, t&aacute;i sử dụng nước thải sẽ g&oacute;p phần giải quyết vấn đề &ocirc; nhiễm nước một c&aacute;ch triệt để.<br />&nbsp;<br /><strong>Chất lượng nước đang suy tho&aacute;i</strong><br /><br />Việt Nam hiện đang phải đối mặt với g&aacute;nh nặng ph&aacute;t triển k&eacute;p do c&aacute;c vấn đề về chất lượng nước nội tại. C&aacute;c chất g&acirc;y &ocirc; nhiễm ph&aacute;t sinh bởi c&ocirc;ng nghiệp h&oacute;a nhanh đ&atilde; l&agrave;m nảy sinh dịch bệnh v&agrave; rủi ro mới cho năng suất v&agrave; tăng trưởng, ngay cả trước khi quốc gia giải quyết được những vấn đề v&igrave; k&eacute;m ph&aacute;t triển như ti&ecirc;u chảy v&agrave; suy dinh dưỡng do vệ sinh k&eacute;m. Trong qu&aacute; khứ, nguồn nước bị suy tho&aacute;i được cho l&agrave; t&aacute;c nh&acirc;n h&agrave;ng đầu đến sức khỏe con người, do g&acirc;y ra bệnh ti&ecirc;u chảy v&agrave; c&aacute;c bệnh truyền nhiễm kh&aacute;c. C&aacute;c nghi&ecirc;n cứu gần đ&acirc;y cho thấy một loạt c&aacute;c chất g&acirc;y &ocirc; nhiễm mới, bằng nhiều con đường t&aacute;c động đến c&aacute;c kết quả kinh tế, từ năng suất lao động đến nguồn cung lao động.<br />&nbsp;</p>\r\n<p><img src=\"https://mizuiku-emyeunuocsach.vn/pic/News/images/EN031.jpg\" alt=\"\" /></p>\r\n<p><em>Tr&ecirc;n lưu vực s&ocirc;ng M&ecirc; C&ocirc;ng đ&atilde; xuất hiện t&igrave;nh trạng x&acirc;m nhập mặn.</em></p>\r\n<p>Chất lượng nước ở Việt Nam suy tho&aacute;i một c&aacute;ch đ&aacute;ng lo ngại, với dấu hiệu của độc t&iacute;nh ph&aacute;t sinh từ c&aacute;c th&agrave;nh phố, khu c&ocirc;ng nghiệp v&agrave; n&ocirc;ng nghiệp. D&ograve;ng chảy qua c&aacute;c th&agrave;nh phố lớn bị &ocirc; nhiễm nặng. Nước dưới đất ở nhiều v&ugrave;ng đ&atilde; bị &ocirc; nhiễm, khai th&aacute;c qu&aacute; mức đ&atilde; dẫn đến gia tăng độ mặn v&agrave; nồng độ c&aacute;c chất &ocirc; nhiễm. Tr&ecirc;n s&ocirc;ng M&ecirc; C&ocirc;ng v&agrave; s&ocirc;ng Hồng, vấn đề n&agrave;y c&ograve;n xảy ra c&ugrave;ng với x&acirc;m nhập mặn.<br /><br />Nước thải đ&ocirc; thị l&agrave; g&oacute;p phần lớn nhất đối với &ocirc; nhiễm nguồn nước, với chỉ 12,5% nước thải đ&ocirc; thị được xử l&yacute; trước khi xả v&agrave;o m&ocirc;i trường. Đ&acirc;y l&agrave; hậu quả của lịch sử l&acirc;u d&agrave;i để lại do kh&ocirc;ng quan t&acirc;m xử l&yacute; nước ti&ecirc;u tho&aacute;t v&agrave; nước thải của c&aacute;c đ&ocirc; thị. Do sự phổ biến của c&aacute;c hệ thống cống kết hợp (thu gom chung cho cả nước thải v&agrave; nước mưa), nước thải sinh hoạt chiếm 30% lượng nước thải ra c&aacute;c hồ, k&ecirc;nh v&agrave; s&ocirc;ng. Th&agrave;nh phố như H&agrave; Nội v&agrave; Hồ Ch&iacute; Minh xả v&agrave;o m&ocirc;i trường khoảng 700.000 - 900.000m3/ng&agrave;y. T&igrave;nh trạng n&agrave;y l&agrave; hệ quả của tỉ lệ kết nối với mạng lưới tho&aacute;t nước thấp; thiếu đầu tư tr&ecirc;n diện rộng v&agrave;o thu gom v&agrave; xử l&yacute; nước thải; thiếu quan t&acirc;m đến t&aacute;i sử dụng nước thải; mức ph&iacute; nước thải thấp kh&ocirc;ng đủ b&ugrave; chi ph&iacute;; v&agrave; hệ thống quản l&yacute; k&eacute;m hiệu quả.<br /><br />Chất thải rắn ph&aacute;t sinh từ c&aacute;c đ&ocirc; thị l&agrave; mối đe dọa đến nguồn nước mặt. Ch&ocirc;n lấp chất thải rắn bất hợp ph&aacute;p, khu vực ch&ocirc;n lấp thiếu vệ sinh nằm gần nguồn nước, v&agrave; thiếu thu gom chất thải rắn đ&atilde; dẫn đến t&igrave;nh trạng r&aacute;c thải g&acirc;y &ocirc; nhiễm nguồn nước. Trong khi Việt Nam c&oacute; 660 b&atilde;i r&aacute;c đang hoạt động th&igrave; chỉ c&oacute; 203 b&atilde;i ch&ocirc;n lấp l&agrave; hợp vệ sinh. C&aacute;c b&atilde;i r&aacute;c c&ograve;n lại kh&ocirc;ng thu gom v&agrave; xử l&yacute; nước rỉ r&aacute;c (chất lỏng tho&aacute;t ra từ b&atilde;i ch&ocirc;n lấp) g&acirc;y &ocirc; nhiễm cho đất v&agrave; nước.<br /><br />Con số tin cậy về tỉ lệ thu gom chất thải rắn đ&ocirc; thị rất kh&oacute; để theo d&otilde;i, nhưng con số n&agrave;y được ước t&iacute;nh l&agrave; 86% ở khu vực th&agrave;nh thị v&agrave;o năm 2018 nhưng dưới 20% ở khu vực n&ocirc;ng th&ocirc;n v&agrave; đ&ocirc; thị ngh&egrave;o v&agrave;o năm 2004. Khoảng 70% chất thải rắn được thu gom v&agrave; ch&ocirc;n lấp. B&aacute;o c&aacute;o gần đ&acirc;y chỉ ra rằng khối lượng chất thải từ Việt Nam cao hơn một c&aacute;ch kh&ocirc;ng c&acirc;n xứng so với quy m&ocirc; của đất nước: 60% chất thải nhựa thải ra biển tr&ecirc;n thế giới bắt nguồn chỉ từ năm quốc gia. T&igrave;nh trạng n&agrave;y đ&atilde; l&agrave;m r&otilde; t&iacute;nh nghi&ecirc;m trọng của t&igrave;nh trạng chất thải rắn ở Việt Nam.<br /><br />Ngo&agrave;i ra, &ocirc; nhiễm nước từ n&ocirc;ng nghiệp cũng đang ng&agrave;y c&agrave;ng gia tăng. Hằng năm Việt Nam ti&ecirc;u thụ khoảng 11 triệu tấn ph&acirc;n b&oacute;n, trong đ&oacute; ph&acirc;n b&oacute;n v&ocirc; cơ l&agrave; 90% v&agrave; hữu cơ l&agrave; 10%. Lượng sử dụng trung b&igrave;nh khoảng 195-200 kg NPK/ha, dao động nhiều giữa loại c&acirc;y trồng, giống, vị tr&iacute;, loại đất v&agrave; h&igrave;nh thức b&oacute;n. Canh t&aacute;c l&uacute;a chiếm 65% tổng lượng ph&acirc;n b&oacute;n ti&ecirc;u thụ ở Việt Nam. Hầu hết n&ocirc;ng d&acirc;n trồng l&uacute;a sử dụng ph&acirc;n b&oacute;n cao hơn mức khuyến c&aacute;o. Chỉ khoảng 45-50% lượng ph&acirc;n b&oacute;n được sử dụng hiệu quả, số c&ograve;n lại bị rửa tr&ocirc;i.<br /><br /><strong>T&aacute;i sử dụng nước thải - giải ph&aacute;p giảm thiểu &ocirc; nhiễm nguồn nước</strong><br /><br />Theo c&aacute;c chuy&ecirc;n gia, mặc d&ugrave; chương tr&igrave;nh cải c&aacute;ch to&agrave;n diện về xử l&yacute; nước thải đ&atilde; được th&ocirc;ng qua năm 2007 (Nghị định 88/2007), &ocirc; nhiễm vẫn c&oacute; xu hướng gia tăng. C&aacute;c vấn đề ch&iacute;nh đang được đặt ra hiện nay l&agrave;: &Ocirc; nhiễm từ nước thải sinh hoạt, nước thải c&ocirc;ng nghiệp v&agrave; c&aacute;c l&agrave;ng nghề; &Ocirc; nhiễm do h&oacute;a chất trừ s&acirc;u v&agrave; ph&acirc;n b&oacute;n trong n&ocirc;ng nghiệp; Hệ thống quy định ph&aacute;p l&yacute; k&eacute;m thực thi; Tỉ lệ kết nối thấp với mạng lưới tho&aacute;t nước; Đầu tư thấp ở mọi kh&acirc;u trong thu gom, xử l&yacute; nước thải v&agrave; b&ugrave;n thải; Bỏ qua khả năng t&aacute;i sử dụng nước thải; Mức ph&iacute; thấp dẫn đến thu kh&ocirc;ng đủ để b&ugrave; chi.<br />&nbsp;</p>\r\n<p><img src=\"https://mizuiku-emyeunuocsach.vn/pic/News/images/EN032.jpg\" alt=\"\" /></p>\r\n<p><em>Nước thải sau khi xử l&yacute; sẽ được t&aacute;i sử dụng.</em></p>\r\n<p>Một lĩnh vực quan trọng cần nghi&ecirc;n cứu l&agrave; x&aacute;c định tại sao c&aacute;c cấu tr&uacute;c ph&aacute;p l&yacute; v&agrave; khuyến kh&iacute;ch lại chưa hiệu quả. Theo Ng&acirc;n h&agrave;ng Thế giới (WB), cần phải c&oacute; khuyến kh&iacute;ch tốt hơn cho đầu tư v&agrave;o dịch vụ nước thải. Đ&acirc;y l&agrave; dịch vụ h&agrave;ng h&oacute;a c&ocirc;ng cộng. Phần lớn được cung cấp v&agrave; chi trả bởi c&aacute;c cơ quan chức năng của th&agrave;nh phố, bởi c&ocirc;ng ty cấp nước hay bởi c&ocirc;ng ty xử l&yacute; nước thải ri&ecirc;ng biệt hoặc một cơ quan của th&agrave;nh phố.<br /><br />B&aacute;o c&aacute;o của Nh&oacute;m T&agrave;i nguy&ecirc;n nước 2030 (2030WRG, 2017) đ&atilde; x&aacute;c định xử l&yacute; v&agrave; t&aacute;i sử dụng nước thải l&agrave; một lĩnh vực ưu ti&ecirc;n đầu tư v&agrave; lĩnh vực n&agrave;y c&oacute; thể hấp dẫn nếu như lợi &iacute;ch, t&aacute;i sử dụng nước thải đ&atilde; qua xử l&yacute; - c&oacute; thể tạo ra nguồn thu. B&aacute;o c&aacute;o cho rằng, việc t&aacute;i sử dụng nước thải đ&ocirc; thị c&oacute; khả năng l&agrave;m giảm &aacute;p lực về t&agrave;i nguy&ecirc;n nước của TP. HCM về mức &ldquo;căng thẳng thấp&rdquo; v&agrave;o năm 2030. Đ&acirc;y l&agrave; việc c&oacute; gi&aacute; trị, nhưng vấn đề đặt ra l&agrave;m thế n&agrave;o để hiện thực h&oacute;a v&agrave; cần sửa đổi quy định như thế n&agrave;o. Tương tự, xử l&yacute; nước thải từ c&aacute;c cụm c&ocirc;ng nghiệp dọc s&ocirc;ng Nhuệ- Đ&aacute;y gần H&agrave; Nội c&oacute; thể cải thiện đ&aacute;ng kể chất lượng nước mặt, nhưng một lần nữa c&aacute;c lợi &iacute;ch cần phải được chi trả.<br /><br />B&aacute;o c&aacute;o của Nh&oacute;m T&agrave;i nguy&ecirc;n nước 2030 cũng cho rằng, t&aacute;i sử dụng trong c&ocirc;ng nghiệp c&oacute; thể biến việc xử l&yacute; nước thải th&agrave;nh cơ hội kinh doanh thương mại v&agrave; đề xuất ba c&aacute;ch thức: tận dụng đầu tư cho nước thải từ c&aacute;c tổ chức c&ocirc;ng v&agrave; tư nh&acirc;n theo thỏa thuận đối t&aacute;c c&ocirc;ng tư PPP; l&agrave;m việc với c&aacute;c c&ocirc;ng ty ph&aacute;t triển hạ tầng về thương mại h&oacute;a c&aacute;c nh&agrave; m&aacute;y xử l&yacute; v&agrave; hệ thống t&aacute;i sử dụng nước thải c&ocirc;ng nghiệp; v&agrave; y&ecirc;u cầu (trong một số trường hợp) ng&agrave;nh c&ocirc;ng nghiệp phải sử dụng nước thải đ&atilde; qua xử l&yacute; cho c&aacute;c quy tr&igrave;nh sản xuất. Một giải ph&aacute;p đ&ocirc;i b&ecirc;n c&ugrave;ng c&oacute; lợi, đặc biệt l&agrave; tại c&aacute;c điểm n&oacute;ng căng thẳng về nguồn nước, c&oacute; thể l&agrave; đầu tư v&agrave;o xử l&yacute; v&agrave; t&aacute;i sử dụng nước thải.<br /><br />Ngo&agrave;i ra, để ứng ph&oacute; với &ocirc; nhiễm n&ocirc;ng nghiệp, khung ph&aacute;p l&yacute; phải được thực thi, v&agrave; gi&aacute;o dục, c&aacute;c ưu đ&atilde;i sửa đổi phải được &aacute;p dụng. Ch&iacute;nh phủ nhận thức r&otilde; c&aacute;c vấn đề &ocirc; nhiễm n&ocirc;ng nghiệp v&agrave; th&ocirc;ng qua Đề &aacute;n T&aacute;i cơ cấu n&ocirc;ng nghiệp của Bộ NNPTNT năm 2014, đ&atilde; n&ecirc;u sự cần thiết giảm thiểu t&aacute;c động của n&ocirc;ng nghiệp đến m&ocirc;i trường.<br /><br />Một b&aacute;o c&aacute;o gần đ&acirc;y của Ng&acirc;n h&agrave;ng Thế giới về &ocirc; nhiễm n&ocirc;ng nghiệp khuyến c&aacute;o rằng n&ocirc;ng d&acirc;n cần được cung cấp c&aacute;c lựa chọn kỹ thuật tốt hơn v&agrave; cơ cấu khuyến kh&iacute;ch - t&iacute;ch cực v&agrave; ti&ecirc;u cực &ndash; cần phải được sửa đổi để khuyến kh&iacute;ch h&agrave;nh vi kh&ocirc;ng xả thải. C&aacute;c chương tr&igrave;nh của Ch&iacute;nh phủ th&uacute;c đẩy thực h&agrave;nh tốt, nhưng cần c&oacute; gi&aacute;m s&aacute;t v&agrave; cưỡng chế, hỗ trợ bởi sự hợp t&aacute;c li&ecirc;n cơ quan. Những thực h&agrave;nh n&ocirc;ng nghiệp tốt đ&atilde; được ph&aacute;t triển cần phải được nh&acirc;n rộng. Với c&aacute;c chương tr&igrave;nh ph&ugrave; hợp kết hợp với phổ biến, tuy&ecirc;n truyền, điều chỉnh việc sử dụng ph&acirc;n b&oacute;n v&agrave; thuốc trừ s&acirc;u c&oacute; thể tạo ra kết quả c&oacute; lợi cho c&aacute;c b&ecirc;n- hiệu quả cao hơn, giảm thiểu &ocirc; nhiễm v&agrave; thu nhập cao hơn.<br />&nbsp;<br /><em>Nguồn: https://www.moitruongvadothi.vn/tai-nguyen/nuoc/giai-quyet-bai-toan-o-nhiem-nuoc-a55961.html</em></p>',NULL,1,NULL,0,'vi',0,'0','2019-12-11 16:14:11',1,'2019-12-11 16:14:11',1,NULL,NULL),
	(23,23,1,'Lễ ký kết Biên bản ghi nhớ giữa Bộ Tài nguyên và Môi trường Liên minh Tái chế Bao bì Việt Nam','le-ky-ket-bien-ban-ghi-nho-giua-bo-tai-nguyen-va-moi-truong-lien-minh-tai-che-bao-bi-viet-nam','news/2019/12/5df1161394f0d_0-118_637055440265667756.jpeg','Ngày 11 tháng 09 năm 2019, tại Khách sạn JW Marriott Hà Nội đã diễn ra Lễ ký kết Biên bản ghi nhớ giữa Bộ Tài Nguyên và Môi Trường và các thành viên của Liên Minh tái chế Bao bì Việt Nam (Packaging Recycling Organzation Viet Nam – PRO Việt Nam) nhằm chia sẻ mục tiêu, tầm nhìn và trách nhiệm trong việc thúc đẩy nền kinh tế tuần hoàn tại Việt Nam thông qua các hoạt động giảm thiểu, phân loại, thu gom, tái chế chất thải. Tham dự buổi lễ có Bộ trưởng Bộ Tài Nguyên Môi Trường Trần Hồng Hà, đại diện PRO Việt Nam cùng 13 thành viên của PRO Việt Nam và các cơ quan Chính phủ, các Bộ, ngành; các tổ chức quốc tế và các tổ chức phi chính phủ có hoạt động liên quan.','<div>Ng&agrave;y&nbsp;11 th&aacute;ng 09 năm 2019, tại Kh&aacute;ch sạn JW Marriott H&agrave; Nội đ&atilde; diễn ra Lễ k&yacute; kết Bi&ecirc;n bản ghi nhớ giữa Bộ T&agrave;i Nguy&ecirc;n v&agrave; M&ocirc;i Trường v&agrave; c&aacute;c th&agrave;nh vi&ecirc;n của Li&ecirc;n Minh t&aacute;i chế Bao b&igrave; Việt Nam (Packaging Recycling Organzation Viet Nam &ndash; PRO Việt Nam) nhằm chia sẻ mục ti&ecirc;u, tầm nh&igrave;n v&agrave; tr&aacute;ch nhiệm trong việc th&uacute;c đẩy nền kinh tế tuần ho&agrave;n tại Việt Nam th&ocirc;ng qua c&aacute;c hoạt động giảm thiểu, ph&acirc;n loại, thu gom, t&aacute;i chế chất thải. Tham dự buổi lễ c&oacute; Bộ trưởng Bộ T&agrave;i Nguy&ecirc;n M&ocirc;i Trường Trần Hồng H&agrave;, đại diện PRO Việt Nam c&ugrave;ng 13 th&agrave;nh vi&ecirc;n của PRO Việt Nam v&agrave; c&aacute;c cơ quan Ch&iacute;nh phủ, c&aacute;c Bộ, ng&agrave;nh; c&aacute;c tổ chức quốc tế v&agrave; c&aacute;c tổ chức phi ch&iacute;nh phủ c&oacute; hoạt động li&ecirc;n quan.<br /><br />&nbsp;Nhận thức được vai tr&ograve; v&agrave; sứ mệnh trong việc giải quyết cuộc khủng hoảng r&aacute;c thải nhựa to&agrave;n cầu, Việt Nam &ndash; một th&agrave;nh vi&ecirc;n c&oacute; tr&aacute;ch nhiệm của Li&ecirc;n hợp quốc &ndash; đ&atilde; cam kết h&agrave;nh động giảm thiểu chất thải nhựa để bảo vệ m&ocirc;i trường sinh th&aacute;i biển v&agrave; đại dương. Th&aacute;ng 12 năm 2017, Việt Nam ch&iacute;nh thức gia nhập danh s&aacute;ch 127 quốc gia th&ocirc;ng qua Nghị quyết của Hội đồng M&ocirc;i trường của Li&ecirc;n hợp quốc về xử l&yacute; r&aacute;c thải nhựa v&agrave; r&aacute;c thải biển. Thủ tướng Ch&iacute;nh phủ Nguyễn Xu&acirc;n Ph&uacute;c cũng k&ecirc;u gọi hợp t&aacute;c to&agrave;n cầu trong việc giải quyết vấn đề nhựa tr&ecirc;n biển tại Hội nghị thượng đỉnh G7 ở Canada năm 2018. C&ugrave;ng năm, Bộ T&agrave;i nguy&ecirc;n v&agrave; M&ocirc;i trường đ&atilde; tổ chức ph&aacute;t động phong tr&agrave;o &ldquo;Chống r&aacute;c thải nhựa&rdquo; nhằm hưởng ứng chiến dịch l&agrave;m cho thế giới sạch hơn năm 2018. Phong tr&agrave;o n&agrave;y được Thủ tướng Ch&iacute;nh phủ n&acirc;ng tầm qua &ldquo;Lễ ra qu&acirc;n to&agrave;n quốc &ldquo;phong tr&agrave;o chống r&aacute;c thải nhựa&rdquo; nhằm n&acirc;ng cao nhận thức chung của to&agrave;n x&atilde; hội trong việc&nbsp;n&oacute;i kh&ocirc;ng với t&uacute;i nilon v&agrave; đồ nhựa d&ugrave;ng một lần v&agrave;o ng&agrave;y 06/09/2019 vừa qua. Tuy nhi&ecirc;n, để giải quyết căn cơ vấn đề r&aacute;c thải rắn n&oacute;i chung v&agrave; r&aacute;c thải nhựa n&oacute;i ri&ecirc;ng, Bộ T&agrave;i nguy&ecirc;n v&agrave; M&ocirc;i trường đ&atilde; v&agrave; đang t&iacute;ch cực hợp t&aacute;c với c&aacute;c b&ecirc;n li&ecirc;n quan nhằm c&ugrave;ng t&igrave;m kiếm giải ph&aacute;p bảo vệ m&ocirc;i trường v&agrave; bảo tồn t&agrave;i nguy&ecirc;n biển th&ocirc;ng qua việc tăng cường hiệu quả quản l&yacute; chất thải rắn, th&uacute;c đẩy nền kinh tế tuần ho&agrave;n, x&acirc;y dựng cơ chế Tr&aacute;ch nhiệm mở rộng của c&aacute;c nh&agrave; sản xuất, hỗ trợ c&aacute;c s&aacute;ng kiến th&acirc;n thiện m&ocirc;i trường hướng tới một Việt Nam ph&aacute;t triển bền vững.<br /><br />&nbsp;Chia sẻ mục ti&ecirc;u, tầm nh&igrave;n v&agrave; tr&aacute;ch nhiệm về th&uacute;c đẩy nền kinh tế tuần ho&agrave;n tại Việt Nam, Bộ T&agrave;i nguy&ecirc;n v&agrave; M&ocirc;i trường hợp t&aacute;c với c&aacute;c th&agrave;nh vi&ecirc;n của Li&ecirc;n minh T&aacute;i chế bao b&igrave; Việt Nam (PRO Việt Nam) nhằm th&uacute;c đẩy hoạt động giảm thiểu, ph&acirc;n loại, thu gom v&agrave; t&aacute;i chế r&aacute;c thải. Bi&ecirc;n bản ghi nhớ được k&yacute; kết giữa Bộ trưởng Bộ T&agrave;i Nguy&ecirc;n M&ocirc;i Trường Trần Hồng H&agrave; v&agrave; &Ocirc;ng Phạm Ph&uacute; Ngọc Trai &ndash; Chủ tịch PRO Việt Nam c&ugrave;ng 12 th&agrave;nh vi&ecirc;n PRO Việt Nam tập trung v&agrave;o c&aacute;c nội dung sau:<br /><br />1.&nbsp;Th&uacute;c đẩy, hỗ trợ c&aacute;c hoạt động giảm thiểu, ph&acirc;n loại chất thải tại nguồn.<br />2.&nbsp;Hỗ trợ, tăng cường năng lực, hiệu quả của hệ thống thu gom, vận chuyển, xử l&yacute; v&agrave; t&aacute;i chế chất thải.<br />3.&nbsp;Tăng cường tr&aacute;ch nhiệm của nh&agrave; sản xuất, chủ sở hữu thương hiệu, nh&agrave; ph&acirc;n phối, b&aacute;n lẻ hiện đại v&agrave; truyền thống v&agrave; nh&agrave; nhập khẩu trong việc quản l&yacute; r&aacute;c thải sau ti&ecirc;u d&ugrave;ng v&agrave; t&aacute;i chế.<br />4.&nbsp;Th&uacute;c đẩy h&igrave;nh th&agrave;nh ng&agrave;nh c&ocirc;ng nghiệp t&aacute;i chế v&agrave; hỗ trợ c&aacute;c sản phẩm t&aacute;i chế, th&acirc;n thiện m&ocirc;i trường.<br />5.&nbsp;Truyền th&ocirc;ng, n&acirc;ng cao nhận thức cộng đồng về giảm thiểu, ph&acirc;n loại, thu gom, t&aacute;i chế chất thải v&agrave; nền kinh tế tuần ho&agrave;n.<br />6.&nbsp;C&aacute;c nội dung kh&aacute;c m&agrave; hai B&ecirc;n c&ugrave;ng quan t&acirc;m.<br /><br />&nbsp;Sự hợp t&aacute;c n&agrave;y thể hiện cam kết mạnh mẽ của cả hai b&ecirc;n c&ugrave;ng th&uacute;c đẩy c&aacute;c chương tr&igrave;nh h&agrave;nh động cụ thể v&agrave; thiết thực nhằm hướng đến tầm nh&igrave;n &ldquo;V&igrave; một Việt Nam Xanh, Sạch, Đẹp&rdquo;của PRO Việt Nam v&agrave; bảo vệ m&ocirc;i trường v&agrave; bảo tồn t&agrave;i nguy&ecirc;n cho một Việt Nam ph&aacute;t triển bền vững của Bộ T&agrave;i nguy&ecirc;n v&agrave; M&ocirc;i trường.<br /><br />&nbsp;Tại buổi lễ, Bộ trưởng Bộ T&agrave;i nguy&ecirc;n v&agrave; M&ocirc;i trường Trần Hồng H&agrave; chia sẻ: &ldquo;T&ocirc;i đ&aacute;nh gi&aacute; cao sự &yacute; thức v&agrave; chủ động của c&aacute;c th&agrave;nh vi&ecirc;n Li&ecirc;n minh t&aacute;i chế bao b&igrave; Việt Nam (PRO Việt Nam) trong việc c&ugrave;ng Bộ chia sẻ tr&aacute;ch nhiệm giải quyết vấn đề r&aacute;c thải tại Việt Nam, đặc biệt l&agrave; r&aacute;c thải nhựa trong ng&agrave;nh bao b&igrave;. R&otilde; r&agrave;ng Doanh nghiệp kh&ocirc;ng chỉ l&agrave; một phần của vấn đề m&agrave; ho&agrave;n to&agrave;n c&oacute; thể trở th&agrave;nh một phần quan trọng của giải ph&aacute;p. T&ocirc;i kỳ vọng sự ti&ecirc;n phong của c&aacute;c th&agrave;nh vi&ecirc;n Li&ecirc;n minh t&aacute;i chế bao b&igrave; Việt Nam sẽ tạo th&agrave;nh phong tr&agrave;o kết nối th&ecirc;m nhiều doanh nghiệp c&ugrave;ng h&agrave;nh động c&oacute; tr&aacute;ch nhiệm với m&ocirc;i trường v&agrave; đất nước v&agrave; c&ugrave;ng nhau ph&aacute;t triển bền vững.<br /><br />&nbsp;Tại buổi lễ, &ocirc;ng Phạm Ph&uacute; Ngọc Trai, Chủ tịch PRO Việt Nam chia sẻ: Thực hiện sứ mệnh &ldquo;Th&uacute;c đẩy nền kinh tế tuần ho&agrave;n&nbsp;ở Việt Nam&nbsp;v&agrave; hỗ trợ việc t&aacute;i chế bao b&igrave; trở n&ecirc;n dễ tiếp cận&nbsp;v&agrave;&nbsp;bền&nbsp;vững&nbsp;hơn&rdquo;, PRO Việt Nam c&oacute; tham vọng đến năm 2030, c&aacute;c bao b&igrave; đồng g&oacute;i do c&aacute;c&nbsp;th&agrave;nh vi&ecirc;n đưa ra ti&ecirc;u thụ tr&ecirc;n thị trường sẽ c&oacute; khả năng thu gom để t&aacute;i chế, m&agrave; trọng t&acirc;m l&agrave; x&acirc;y dựng v&agrave; ph&aacute;t triển hệ thống&nbsp;thu gom bao b&igrave; tr&ecirc;n cơ&nbsp;sở hợp t&aacute;c với ch&iacute;nh quyền địa phương v&agrave;&nbsp;c&aacute;c b&ecirc;n li&ecirc;n quan trong ng&agrave;nh để th&uacute;c đẩy t&aacute;i chế với c&aacute;c hoạt động như:&nbsp;Gi&aacute;o dục, Thu gom, T&aacute;i chế v&agrave; đặc biệt Hợp t&aacute;c với c&aacute;c cơ quan Ch&iacute;nh phủ trong vai tr&ograve; Doanh nghiệp C&ocirc;ng d&acirc;n của m&igrave;nh.<br /><br /><strong><u>TH&Ocirc;NG TIN VỀ LI&Ecirc;N MINH T&Aacute;I CHẾ BAO B&Igrave; VIỆT NAM (PRO VIỆT NAM)</u></strong><br /><br />PRO&nbsp;VIỆT NAM l&agrave; li&ecirc;n minh gồm 12 th&agrave;nh vi&ecirc;n, với 9 th&agrave;nh vi&ecirc;n s&aacute;ng lập gồm:&nbsp;&nbsp;Coca-Cola Việt Nam, FrieslandCampina Việt Nam, La Vie Việt Nam, Nestl&eacute; Việt Nam, NutiFood, Suntory PepsiCo Việt Nam, Tetra Pak, TH Group, URC Việt Nam, v&agrave;&nbsp;3 th&agrave;nh vi&ecirc;n chủ chốt gồm&nbsp;Annam Group,&nbsp;Polytex Far Eastern (Việt Nam) v&agrave; Saigon Co.op.<br /><br />&nbsp;PRO&nbsp;Việt Nam&nbsp;dựa tr&ecirc;n&nbsp;bốn&nbsp;trụ cột hoạt động ch&iacute;nh để hiện thực ho&aacute; tham vọng của tổ chức: (1) n&acirc;ng cao nhận thức người ti&ecirc;u d&ugrave;ng về t&aacute;i chế v&agrave; ph&acirc;n loại r&aacute;c; (2) l&agrave;m vững mạnh hệ sinh th&aacute;i thu gom bao b&igrave; sẵn c&oacute;; v&agrave; (3) hỗ trợ c&aacute;c chương tr&igrave;nh t&aacute;i chế của nh&agrave; m&aacute;y xử l&yacute; v&agrave; c&aacute;c nh&agrave; m&aacute;y sản xuất nguy&ecirc;n liệu t&aacute;i chế&nbsp;(4)&nbsp;PRO&nbsp;Việt Nam&nbsp;cũng hợp t&aacute;c với Ch&iacute;nh Phủ trong kh&iacute;a cạnh &ldquo;Recycle - T&aacute;i chế\" của bộ nguy&ecirc;n tắc 3R (Reduce - Giảm thiểu, Reuse - T&aacute;i sử dụng v&agrave; Recycle - T&aacute;i chế), trong đ&oacute; Giảm thiểu v&agrave; T&aacute;i sử dụng sẽ l&agrave; cơ hội cho những cải tiến về bao b&igrave;. PRO Việt Nam cũng sẽ phối hợp với c&aacute;c trung t&acirc;m nghi&ecirc;n cứu của c&aacute;c trường Đại học&nbsp;nhằm t&igrave;m ra c&aacute;c giải ph&aacute;p ph&ugrave; hợp với m&ocirc;i trường của Việt Nam. Li&ecirc;n minh PRO Việt Nam ch&uacute; trọng c&aacute;c chương tr&igrave;nh truyền th&ocirc;ng, mức thưởng kh&iacute;ch lệ v&agrave; c&ocirc;ng nghệ để x&acirc;y dựng nhận thức của người ti&ecirc;u d&ugrave;ng v&agrave; gia tăng khả năng thu hồi bao b&igrave; sau sử dụng, với sự hợp t&aacute;c của ch&iacute;nh quyền v&agrave; c&aacute;c nh&agrave; l&atilde;nh đạo trong ng&agrave;nh c&ocirc;ng nghiệp nhằm tăng tỷ lệ t&aacute;i chế.<br /><br />&nbsp;PRO Việt Nam&nbsp;lu&ocirc;n ch&agrave;o đ&oacute;n những c&ocirc;ng ty v&agrave; những b&ecirc;n li&ecirc;n quan kh&aacute;c tại Việt Nam tham gia v&agrave;o li&ecirc;n&nbsp;minh&nbsp;n&agrave;y. Nguy&ecirc;n tắc căn bản của PRO&nbsp;Việt Nam&nbsp;đ&oacute; l&agrave; ch&uacute;ng t&ocirc;i tin&nbsp;rằng&nbsp;khi ch&uacute;ng ta chung tay h&agrave;nh động hướng đến mục ti&ecirc;u t&aacute;i chế chung, ch&uacute;ng ta sẽ đạt được kết quả nhanh hơn v&agrave; hiệu quả cao&nbsp;hơn so với khi h&agrave;nh động ri&ecirc;ng rẽ.</div>\r\n<div><img src=\"https://mizuiku-emyeunuocsach.vn/pic/News/images/0-1180.jpeg\" alt=\"\" /></div>\r\n<div><br /><em>Nguồn:&nbsp;</em><em>https://suntorypepsico.vn/News/Index/-le-ky-ket-bien-ban-ghi-nho-giua-bo-tai-nguyen-va-moi-truong-lien-minh-tai-che-bao-bi-viet-nam</em></div>',NULL,1,NULL,0,'vi',2,'0','2019-12-11 16:15:17',1,'2019-12-12 07:01:46',1,NULL,NULL),
	(24,24,NULL,'Tập huấn Mizuiku cho sinh viên Mùa hè xanh tại Thái Nguyên','ta-p-hua-n-mizuiku-cho-sinh-vien-mu-a-he-xanh-ta-i-tha-i-nguyen','library/2019/12/5df117995fc17_2407_637032927335535151.jpeg',NULL,NULL,'photo',1,NULL,0,'vi',0,'0','2019-12-11 16:23:18',1,'2019-12-11 16:23:18',1,NULL,NULL),
	(25,25,NULL,'Mizuiku - Giving Back to Society','mizuiku-giving-back-to-society','library/2019/12/5df118acd9c80_0.jpg',NULL,NULL,'video',1,'https://www.youtube.com/watch?v=9mDCs5-tS4I',0,'vi',0,'0','2019-12-11 16:26:24',1,'2019-12-12 02:12:43',1,NULL,NULL),
	(26,26,NULL,'Lễ khởi động chương trình Mizuiku - Em yêu nước sạch 2017 tại Bến Tre','le-khoi-dong-chuong-trinh-mizuiku-em-yeu-nuoc-sach-2017-tai-ben-tre','library/2019/12/5df11a2b8462c_118_636351089874681363.jpg',NULL,NULL,'photo',1,NULL,0,'vi',0,'0','2019-12-11 16:32:46',1,'2019-12-11 16:35:17',1,'2019-12-11 16:35:17',1),
	(27,27,NULL,'60 thiếu nhi tham quan Nhà máy Suntory PepsiCo Đồng Nai','60-thieu-nhi-tham-quan-nha-may-suntory-pepsico-dong-nai','library/2019/12/5df11ba262482_267_636676797073490967.jpg',NULL,NULL,'photo',1,NULL,0,'vi',2,'0','2019-12-11 16:39:00',1,'2019-12-12 03:52:02',1,NULL,NULL),
	(28,28,NULL,'Hoạt động học tập và trải nghiệm thiên nhiên thực tế tại Hà Giang','hoat-dong-hoc-tap-va-trai-nghiem-thien-nhien-thuc-te-tai-ha-giang','library/2019/12/5df11cd0286d9_326_636803741495889748.jpg',NULL,NULL,'photo',1,NULL,0,'vi',7,'0','2019-12-11 16:44:02',1,'2019-12-12 07:10:47',1,NULL,NULL),
	(29,29,NULL,'Gallery 1','gallery-1',NULL,NULL,NULL,'photo',1,NULL,0,'vi',0,'0','2019-12-13 07:59:31',1,'2019-12-13 07:59:31',1,NULL,NULL);

/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table banners
# ------------------------------------------------------------

DROP TABLE IF EXISTS `banners`;

CREATE TABLE `banners` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `ref_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'home',
  `title` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `language` varchar(10) NOT NULL DEFAULT 'en',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Deleted At',
  `created_user_id` bigint(20) unsigned NOT NULL,
  `updated_user_id` bigint(20) unsigned NOT NULL,
  `deleted_user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `category_ref_id` (`ref_id`),
  KEY `create_user_id` (`created_user_id`) USING BTREE,
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;

INSERT INTO `banners` (`id`, `ref_id`, `type`, `title`, `thumbnail`, `url`, `slug`, `priority`, `language`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_user_id`, `updated_user_id`, `deleted_user_id`)
VALUES
	(1,1,'home','Banner 3','banners/2019/12/5df0b5c005f6c_3.jpg',NULL,'banner-3',0,'vi',1,'2019-12-11 07:33:56','2019-12-11 09:24:18',NULL,1,1,NULL),
	(2,2,'home','Banner 2','banners/2019/12/5df0b68232fb1_1.jpg',NULL,'banner-2',0,'vi',1,'2019-12-11 07:34:12','2019-12-11 09:27:31',NULL,1,1,NULL),
	(3,3,'home','Banner 1','banners/2019/12/5df0b69e997e7_1.jpg',NULL,'banner-1',0,'vi',1,'2019-12-11 07:34:28','2019-12-11 09:28:01',NULL,1,1,NULL),
	(4,1,'home','Banner 3','banners/2019/12/5df0b6fb727d5_3.jpg',NULL,'banner-3-1',0,'en',1,'2019-12-11 07:34:48','2019-12-11 09:29:35',NULL,1,1,NULL),
	(5,2,'home','Banner 2','banners/2019/12/5df0bb9d4a8a5_1.jpg',NULL,'banner-2-1',0,'en',1,'2019-12-11 07:35:04','2019-12-11 09:49:19',NULL,1,1,NULL),
	(6,3,'home','Banner 1','banners/2019/12/5df09c35bb615_1.jpg',NULL,'banner-1-1',0,'en',1,'2019-12-11 07:35:24','2019-12-11 07:35:24',NULL,1,1,NULL);

/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `categories`;

CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `ref_id` int(10) unsigned DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL COMMENT 'Parent ID',
  `type` varchar(255) NOT NULL COMMENT 'Article Type',
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT '0',
  `language` varchar(10) NOT NULL DEFAULT 'en',
  `content` text,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Deleted At',
  `created_user_id` bigint(20) unsigned NOT NULL,
  `updated_user_id` bigint(20) unsigned NOT NULL,
  `deleted_user_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  KEY `category_ref_id` (`ref_id`),
  KEY `create_user_id` (`created_user_id`) USING BTREE,
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;

INSERT INTO `categories` (`id`, `ref_id`, `parent_id`, `type`, `title`, `slug`, `priority`, `language`, `content`, `status`, `created_at`, `updated_at`, `deleted_at`, `created_user_id`, `updated_user_id`, `deleted_user_id`)
VALUES
	(1,1,NULL,'news','Tin tức môi trường','tin-tuc-moi-truong',0,'vi',NULL,1,'2019-12-04 02:25:11','2019-12-04 02:25:11',NULL,1,1,NULL),
	(2,2,NULL,'news','Tin tức chương trình','tin-tuc-chuong-trinh',0,'vi',NULL,1,'2019-12-04 02:25:24','2019-12-04 02:25:24',NULL,1,1,NULL),
	(3,1,NULL,'news','Environmental news','environmental-news',0,'en',NULL,1,'2019-12-04 02:27:20','2019-12-04 02:27:20',NULL,1,1,NULL),
	(4,2,NULL,'news','Program news','program-news',0,'en',NULL,1,'2019-12-04 02:27:39','2019-12-04 02:27:39',NULL,1,1,NULL),
	(5,5,NULL,'news','test','test',0,'vi',NULL,1,'2019-12-07 08:25:37','2019-12-07 08:29:07','2019-12-07 08:29:07',1,1,1);

/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table comment
# ------------------------------------------------------------

DROP TABLE IF EXISTS `comment`;

CREATE TABLE `comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) NOT NULL DEFAULT 'articles',
  `post_id` int(10) unsigned NOT NULL,
  `content` text NOT NULL,
  `status` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_user_id` int(10) unsigned NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_user_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `model_record_id` (`post_id`),
  KEY `created_user_id` (`created_user_id`),
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table contacts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `contacts`;

CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `fullname` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `content` text,
  `ip` varchar(255) DEFAULT NULL,
  `language` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_user_id` int(10) unsigned DEFAULT NULL COMMENT 'Created User ID',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  `updated_user_id` int(10) unsigned DEFAULT NULL COMMENT 'Updated User ID',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Deleted At',
  `deleted_user_id` int(10) unsigned DEFAULT NULL COMMENT 'Deleted User ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;

INSERT INTO `contacts` (`id`, `fullname`, `phone`, `email`, `content`, `ip`, `language`, `created_at`, `created_user_id`, `updated_at`, `updated_user_id`, `deleted_at`, `deleted_user_id`)
VALUES
	(1,'Dung ngo','0908946595','dung.ngowz@gmail.com','Content Test','127.0.0.1','vi','2019-12-06 07:31:34',NULL,'2019-12-06 07:31:34',NULL,NULL,NULL);

/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table failed_jobs
# ------------------------------------------------------------

DROP TABLE IF EXISTS `failed_jobs`;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table gallery
# ------------------------------------------------------------

DROP TABLE IF EXISTS `gallery`;

CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) NOT NULL DEFAULT 'articles',
  `post_id` int(10) unsigned NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `size` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_user_id` int(10) unsigned NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_user_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `model_record_id` (`post_id`),
  KEY `created_user_id` (`created_user_id`),
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `gallery` WRITE;
/*!40000 ALTER TABLE `gallery` DISABLE KEYS */;

INSERT INTO `gallery` (`id`, `table_name`, `post_id`, `file_name`, `file_path`, `size`, `created_at`, `created_user_id`, `updated_at`, `updated_user_id`, `deleted_at`, `deleted_user_id`)
VALUES
	(3,'articles',24,'EN03_637069227525501530.jpg','library/1576081388.jpeg',NULL,'2019-12-11 16:23:18',1,'2019-12-11 16:23:18',1,NULL,NULL),
	(4,'articles',24,'78695012_481642575788018_1000115321358516224_n.jpg','library/1576081396.jpeg',NULL,'2019-12-11 16:23:18',1,'2019-12-11 16:23:18',1,NULL,NULL),
	(5,'articles',26,'118_636351089874681363.jpg','library/1576081953.jpeg',NULL,'2019-12-11 16:32:46',1,'2019-12-11 16:32:46',1,NULL,NULL),
	(6,'articles',26,'118_636351089854370201.jpg','library/1576081953.jpeg',NULL,'2019-12-11 16:32:46',1,'2019-12-11 16:32:46',1,NULL,NULL),
	(7,'articles',26,'118_636351089874681363.jpg','library/1576082021.jpeg',NULL,'2019-12-11 16:33:54',1,'2019-12-11 16:33:54',1,NULL,NULL),
	(8,'articles',26,'78695012_481642575788018_1000115321358516224_n.jpg','library/1576082064.jpeg',NULL,'2019-12-11 16:34:25',1,'2019-12-11 16:34:25',1,NULL,NULL),
	(9,'articles',27,'267_636676797063521372.jpg','library/1576082328.jpeg',NULL,'2019-12-11 16:39:00',1,'2019-12-11 16:39:00',1,NULL,NULL),
	(10,'articles',27,'267_636676797073490967.jpg','library/1576082328.jpeg',NULL,'2019-12-11 16:39:00',1,'2019-12-11 16:39:00',1,NULL,NULL),
	(11,'articles',28,'326_636803741495889748.jpg','library/1576082606.jpeg',NULL,'2019-12-11 16:44:02',1,'2019-12-11 16:44:02',1,NULL,NULL),
	(12,'articles',28,'326_636803741504197736 (1).jpg','library/1576082629.jpeg',NULL,'2019-12-11 16:44:02',1,'2019-12-11 16:44:02',1,NULL,NULL),
	(13,'articles',27,'Screen Shot 2019-12-12 at 10.51.53.png','library/1576122718.png',NULL,'2019-12-12 03:52:00',1,'2019-12-12 03:52:00',1,NULL,NULL),
	(14,'articles',28,'Screen Shot 2019-12-12 at 2.06.05 PM.png','library/1576134372.png',NULL,'2019-12-12 07:06:14',1,'2019-12-12 07:06:14',1,NULL,NULL),
	(15,'articles',29,'Screen Shot 2019-12-13 at 14.01.23.png','library/library/2019/12/5df344e204e1a.png',NULL,'2019-12-13 07:59:31',1,'2019-12-13 08:01:29',1,'2019-12-13 08:01:29',NULL),
	(16,'articles',29,'Screen Shot 2019-12-13 at 14.09.14.png','library/library/2019/12/5df344e21d2ea.png',NULL,'2019-12-13 07:59:31',1,'2019-12-13 08:01:29',1,'2019-12-13 08:01:29',NULL),
	(17,'articles',29,'Screen Shot 2019-12-13 at 14.01.23.png','library/2019/12/5df3455845100.png',NULL,'2019-12-13 08:01:29',1,'2019-12-13 08:01:37',1,'2019-12-13 08:01:37',NULL);

/*!40000 ALTER TABLE `gallery` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table learning_outcomes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `learning_outcomes`;

CREATE TABLE `learning_outcomes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `video_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_user_id` int(10) unsigned NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_user_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_user_id` (`created_user_id`),
  KEY `updated_user_id` (`updated_user_id`),
  KEY `deleted_user_id` (`deleted_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`id`, `migration`, `batch`)
VALUES
	(1,'2014_10_12_000000_create_users_table',1),
	(2,'2014_10_12_100000_create_password_resets_table',1),
	(3,'2019_08_19_000000_create_failed_jobs_table',1);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



# Dump of table program_timeline
# ------------------------------------------------------------

DROP TABLE IF EXISTS `program_timeline`;

CREATE TABLE `program_timeline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `ref_id` int(10) unsigned DEFAULT NULL,
  `title` text,
  `slug` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `content` text,
  `priority` int(11) NOT NULL DEFAULT '0',
  `language` varchar(10) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_user_id` int(10) unsigned NOT NULL COMMENT 'Created User ID',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT 'Updated At',
  `updated_user_id` int(10) unsigned NOT NULL COMMENT 'Updated User ID',
  `deleted_at` datetime DEFAULT NULL COMMENT 'Deleted At',
  `deleted_user_id` int(10) unsigned DEFAULT NULL COMMENT 'Deleted User ID',
  PRIMARY KEY (`id`),
  KEY `category_ref_id` (`ref_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

LOCK TABLES `program_timeline` WRITE;
/*!40000 ALTER TABLE `program_timeline` DISABLE KEYS */;

INSERT INTO `program_timeline` (`id`, `ref_id`, `title`, `slug`, `month`, `content`, `priority`, `language`, `status`, `created_at`, `created_user_id`, `updated_at`, `updated_user_id`, `deleted_at`, `deleted_user_id`)
VALUES
	(1,1,'Tổng kết chương trình \"Mizuiku - Em yêu nước sạch\"','tong-ket-chuong-trinh-mizuiku-em-yeu-nuoc-sach','Tháng 12','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Lễ tổng kết chương tr&igrave;nh l&agrave; sự kiện nh&igrave;n lại chặng đường một năm hoạt động của chương tr&igrave;nh, v&agrave; gửi lời cảm ơn tới c&aacute;c đối t&aacute;c, nh&agrave; trường v&agrave; c&aacute;c đơn vị hỗ trợ hợp t&aacute;c, cũng như r&uacute;t kinh nghiệm để l&agrave;m tốt hơn v&agrave; c&ocirc;ng bố kế hoạch ph&aacute;t triển chương tr&igrave;nh trong năm tiếp theo.</span></p>',0,'vi',1,'2019-12-07 04:37:16',1,'2019-12-07 04:37:16',1,NULL,NULL),
	(2,1,'Closing ceremony of the \"Mizuiku - I love clean water\" program','closing-ceremony-of-the-mizuiku-i-love-clean-water-program','December','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">The closing ceremonies review the journey of Mizuiku throughout the year reflecting on the program\'s achievement, lesson learnt and announcing the new action plan for the following year. It is also an occasion for the Program to officially extend its gratitude to partners, schools and other supporting parties for their collaborations.&nbsp;</span></p>',0,'en',1,'2019-12-07 04:38:12',1,'2019-12-07 04:38:12',1,NULL,NULL),
	(3,3,'Tham quan nhà máy Suntory PepsiCo Việt Nam','tham-quan-nha-may-suntory-pepsico-viet-nam','Tháng 10 - 11','<p>Tham quan nh&agrave; m&aacute;y Suntory PepsiCo Việt Nam l&agrave; một hoạt động ngoại kh&oacute;a lu&ocirc;n được c&aacute;c em học sinh h&aacute;o hức đ&oacute;n chờ. Với thời lượng 3 tiếng đồng hồ, chuyến tham quan đ&atilde; đem lại cho c&aacute;c em nhiều hoạt động th&uacute; vị m&agrave; c&aacute;c em kh&oacute; l&ograve;ng c&oacute; thể trải nghiệm tại lớp học như: sử dụng giấy quỳ để kiểm tra độ PH của nước, sự thay đổi của chất lượng nước sau khi được lọc. Đặc biệt c&aacute;c em c&ograve;n được tự m&igrave;nh quan s&aacute;t c&ocirc;ng nghệ d&acirc;y chuyền kh&eacute;p k&iacute;n để sản xuất ra c&aacute;c sản phẩm nước giải kh&aacute;t quen thuộc trong cuộc sống h&agrave;ng ng&agrave;y như Tea+, Pepsi, Revive and My Cafe, để hiểu th&ecirc;m về c&ocirc;ng nghệ tiết kiệm nước v&agrave; xử l&yacute; nước thải tại nh&agrave; m&aacute;y của Suntory PepsiCo Việt Nam.</p>',0,'vi',1,'2019-12-07 06:49:20',1,'2019-12-07 06:49:20',1,NULL,NULL),
	(4,3,'Suntory PepsiCo Vietnam Plant tour','suntory-pepsico-vietnam-plant-tour','October - November','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Suntory PepsiCo Vietnam Plant tour is an extra-curricular activity within Mizuiku program that always excites students. The 3-hour plant tour consists of activities such as using litmus paper to test pH in water and the change in quality of water after filtration. Moreover, students get to observe the production lines of their favorite beverages such as Tea+, Pepsi, Revive, My Cafe, and learn about the water saving technology and wastewater treatment system at Suntory PepsiCo Vietnam\'s Plant.</span></p>',0,'en',1,'2019-12-07 06:50:20',1,'2019-12-07 06:50:20',1,NULL,NULL),
	(5,5,'Ngày hội Hiệp sĩ nước sạch','ngay-hoi-hiep-si-nuoc-sach','Tháng 9','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Ng&agrave;y hội \"Hiệp sĩ Nước sạch\" l&agrave; sự kiện thu h&uacute;t sự tham gia của h&agrave;ng ngh&igrave;n học sinh tại c&aacute;c trường tiểu học tham gia chương tr&igrave;nh \"Mizuiku - Em y&ecirc;u nước sạch\". Đ&acirc;y l&agrave; cơ hội để c&aacute;c em học sinh to&agrave;n trường được t&igrave;m hiểu, &ocirc;n lại kiến thức đ&atilde; học v&agrave; tham gia c&aacute;c tr&ograve; chơi tập thể vui nhộn, mang &yacute; nghĩa bảo vệ nguồn nước, bảo vệ m&ocirc;i trường. Một số hoạt động trong Ng&agrave;y hội như tr&igrave;nh diễn thời trang t&aacute;i chế, thi Rung chu&ocirc;ng v&agrave;ng, thi h&ugrave;ng biện \"T&ocirc;i l&agrave; nước\", văn nghệ chủ đề Em y&ecirc;u nước sạch nhằm gi&uacute;p c&aacute;c em học sinh r&egrave;n luyện &yacute; thức sử dụng nguồn nước sạch một c&aacute;ch hợp l&yacute; v&agrave; chia sẻ th&ocirc;ng điệp với bạn b&egrave; v&agrave; gia đ&igrave;nh.</span></p>',0,'vi',1,'2019-12-07 06:53:03',1,'2019-12-07 06:53:03',1,NULL,NULL),
	(6,5,'Clean Water Knight festival','clean-water-knight-festival','September','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">The \"Clean Water Knight\" festival events attract the participation of thousands of students from beneficiary elementary schools of \"Mizuiku - I love clean water\" program every year. These events gather students of the whole beneficiary school where every student can learn or review their lessons by participating in series of activities and educational fun games related to water resource preservation and environmental protection. For examples, recycle fashion show, Golden Bell contest, \"I am water\" storytelling contest, \"I love clean water\" music show are among many meaningful activities held in the Festivals to remind children not to waste water and encourage them to share this message with their friends and family.&nbsp;</span></p>',0,'en',1,'2019-12-07 06:53:54',1,'2019-12-07 06:53:54',1,NULL,NULL),
	(7,7,'Lớp sinh hoạt ngoại khóa Mizuiku về bảo vệ môi trường và nguồn nước cho trẻ em do Đại sứ Mizuiku triển khai','lop-sinh-hoat-ngoai-khoa-mizuiku-ve-bao-ve-moi-truong-va-nguon-nuoc-cho-tre-em-do-dai-su-mizuiku-trien-khai','Tháng 8','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">C&aacute;c đội h&igrave;nh t&igrave;nh nguyện vi&ecirc;n hay Đại sứ Mizuiku v&acirc;̣n dụng linh loạt những ki&ecirc;́n thức và kỹ năng của chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; đ&ecirc;̉ x&acirc;y dựng n&ocirc;̣i dung bài giảng phù hợp với hoàn cảnh của từng địa phương, khu d&acirc;n cư, trường học nơi họ tham gia hoạt động giảng dạy t&igrave;nh nguyện. Với sự nhi&ecirc;̣t tình v&agrave; sức trẻ của đội ngũ đại sứ Mizuiku, các lớp di&ecirc;̃n ra s&ocirc;i n&ocirc;̉i và nh&acirc;̣n được sự ủng h&ocirc;̣ tích cực của người d&acirc;n địa phương.&nbsp;</span></p>',0,'vi',1,'2019-12-07 06:54:40',1,'2019-12-07 06:54:40',1,NULL,NULL),
	(8,7,'Mizuiku extra curriculum conducted by Mizuiku Ambassadors about  water resource and environment education for children','mizuiku-extra-curriculum-conducted-by-mizuiku-ambassadors-about-water-resource-and-environment-education-for-children','August','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Groups of volunteer or Mizuiku Ambassadors apply the knowledge and skills acquired from the \"Mizuiku - I love clean water\" program to develop and customize teaching content to match with local communities and schools where they voluntarily deliver the Mizuiku class. The youthful spirit and enthusiasm of Mizuiku Ambassadors have brought exuberant feeling for the students, receiving positive feedback from local people.</span></p>',0,'en',1,'2019-12-07 06:55:35',1,'2019-12-07 06:55:35',1,NULL,NULL),
	(9,9,'Chương trình tập huấn cho các Đại sứ Mizuiku','chuong-trinh-tap-huan-cho-cac-dai-su-mizuiku','Tháng 7','<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Chương tr&igrave;nh Đại sứ Mizuiku l&agrave; hoạt động mở rộng cho c&aacute;c t&igrave;nh nguyện vi&ecirc;n c&oacute; nguyện vọng tham gia tập huấn, bồi dưỡng kỹ năng dạy học theo phương ph&aacute;p v&agrave; nội dung giảng dạy của chương tr&igrave;nh. C&aacute;c T&igrave;nh nguyện vi&ecirc;n Mizuiku sau đ&oacute; sẽ thực hiện c&aacute;c hoạt động gi&aacute;o dục m&ocirc;i trường v&agrave; hoạt động ngoại kh&oacute;a về chủ đề nước cho c&aacute;c em học sinh. Đội ngũ t&igrave;nh nguyện vi&ecirc;n được tuyển chọn khắp cả nước như c&aacute;c sinh vi&ecirc;n t&igrave;nh nguyện \"M&ugrave;a h&egrave; xanh\", sinh vi&ecirc;n từ c&aacute;c c&acirc;u lạc bộ DYNAMIC v&agrave; c&aacute;n bộ nh&acirc;n vi&ecirc;n thuộc c&aacute;c Ủy ban V&ograve;ng tay nh&acirc;n &aacute;i - Helping Hands của Suntory PepsiCo Việt Nam.&nbsp;</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">&nbsp;</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Ch&uacute; th&iacute;ch:</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">&ldquo;Dynamic - Sinh vi&ecirc;n nh&agrave; doanh nghiệp tương lai&rdquo; l&agrave; cuộc thi d&agrave;nh cho sinh vi&ecirc;n c&aacute;c trường đại học tr&ecirc;n cả nước do đại học Kinh tế th&agrave;nh phố Hồ Ch&iacute; Minh khởi xướng v&agrave; tổ chức từ năm 1996. Sau 12 lần tham gia đồng h&agrave;nh với cuộc thi ở vai tr&ograve; l&agrave; nh&agrave; t&agrave;i trợ ch&iacute;nh, năm 2017, Suntory PepsiCo Việt Nam đ&oacute;ng g&oacute;p với vai tr&ograve; đồng tổ chức cuộc thi. Trước khi đến với v&ograve;ng chung kết quốc gia, th&iacute; sinh sẽ lần lượt tham gia chuỗi hoạt động gồm: chương tr&igrave;nh đ&agrave;o tạo kỹ năng khởi nghiệp, cố vấn chương tr&igrave;nh, huấn luyện chuy&ecirc;n s&acirc;u, cuộc thi online về kỹ năng v&agrave; kiến thức vận h&agrave;nh doanh nghiệp ảo; v&ograve;ng tuyển chọn khu vực v&agrave; v&ograve;ng chung kết khu vực.</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Tổng gi&aacute; trị giải thưởng của cuộc thi l&ecirc;n đến 1,5 tỷ đồng v&agrave; 06 suất tham quan giao lưu với c&aacute;c trường Đại học v&agrave; Tập Đo&agrave;n Suntory tại Nhật Bản d&agrave;nh cho th&iacute; sinh, giảng vi&ecirc;n v&agrave; cố vấn của CLB đạt giải nhất. Ngo&agrave;i ra, th&iacute; sinh đạt giải thưởng Thủ lĩnh DYNAMIC &ndash; UEH sẽ nhận được học bổng Thạc sĩ Quản trị kinh doanh trường Western Sydney cấp bằng (trị gi&aacute; mỗi suất học bổng tương đương 300 triệu đồng), 02 c&acirc;u lạc bộ đạt giải Đầu tư DYNAMIC &ndash; bứt ph&aacute; c&ugrave;ng STING sẽ nhận được đầu tư cho sự ph&aacute;t triển bền vững của c&acirc;u lạc bộ Dynamic, trị gi&aacute; mỗi giải thưởng 100 triệu đồng, v&agrave; nhiều giải thưởng hấp dẫn kh&aacute;c.</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">&nbsp;</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Chương tr&igrave;nh &ldquo;V&ograve;ng tay nh&acirc;n &aacute;i - Helping Hands&rdquo;: Đ&acirc;y l&agrave; một s&aacute;ng kiến của C&ocirc;ng ty Suntory PepsiCo Việt Nam d&agrave;nh cho c&aacute;n bộ nh&acirc;n vi&ecirc;n c&ocirc;ng ty nhằm g&acirc;y quỹ hỗ trợ cộng đồng. Khởi động từ th&aacute;ng 8 năm 2011, mục ti&ecirc;u của chương tr&igrave;nh &ldquo;V&ograve;ng tay nh&acirc;n &aacute;i - Helping Hands&rdquo; nhằm n&acirc;ng cao gi&aacute; trị cốt l&otilde;i của Suntory PepsiCo Việt Nam v&agrave; x&acirc;y dựng văn ho&aacute; doanh nghiệp, kết nối nh&acirc;n vi&ecirc;n cam kết l&acirc;u d&agrave;i v&agrave; đ&oacute;ng g&oacute;p cho sự ph&aacute;t triển bền vững của doanh nghiệp v&agrave; x&atilde; hội. Đ&oacute; l&agrave; một nền tảng li&ecirc;n kết chăt chẽ của nh&acirc;n vi&ecirc;n, cộng đồng v&agrave; doanh nghiệp. Tổng số tiền huy động của nh&acirc;n vi&ecirc;n sẽ được c&ocirc;ng ty đối ứng. Hiện nay, tại c&aacute;c nh&agrave; m&aacute;y v&agrave; văn ph&ograve;ng của Suntory PepsiCo Việt Nam tr&ecirc;n to&agrave;n quốc c&oacute; 10 Ủy ban V&ograve;ng tay nh&acirc;n &aacute;i được th&agrave;nh lập, khởi xướng 103 chương tr&igrave;nh, hơn 3086 t&igrave;nh nguyện vi&ecirc;n tham gia, đ&oacute;ng g&oacute;p khoảng 17.650 giờ l&agrave;m việc, gần 8 tỷ đồng đ&atilde; được sử dụng để x&acirc;y dựng 3 trường học, 2 ng&ocirc;i nh&agrave; v&agrave; 3 thư viện cho trẻ em miền n&uacute;i, tặng h&agrave;ng ng&agrave;n suất học bổng, hỗ trợ 1600 ca phẫu thuật mắt, tặng qu&agrave; cho người khuyết tật v&agrave; người lớn tuổi ở c&aacute;c trung t&acirc;m x&atilde; hội.</div>',0,'vi',1,'2019-12-07 06:58:34',1,'2019-12-07 06:58:34',1,NULL,NULL),
	(10,9,'Constructing and upgrading clean water facilities at beneficiary elementary schools and community sites','constructing-and-upgrading-clean-water-facilities-at-beneficiary-elementary-schools-and-community-sites','July','<p><span style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">Every summer, \"Mizuiku - I love clean water\" program supports the construction of water filtration and sanitation facilities in schools and community sites in areas accross the country that are facing severe water shortage. \"Clean water for society\" is the key corporate social responsibility message that Suntory PepsiCo Vietnam aims to leverage across the country. Teachers, volunteers and students also collaborate to decorate the walls surrounding the facilities, which would encourage chidlren\'s appreciation and better use of the sponsored sanitation facilities.&nbsp;</span></p>',0,'en',1,'2019-12-07 06:59:32',1,'2019-12-07 07:00:49',1,NULL,NULL),
	(11,11,'Xây dựng và nâng cấp cơ sở vật chất nước sạch tại các trường tiểu học và cộng đồng','xay-dung-va-nang-cap-co-so-vat-chat-nuoc-sach-tai-cac-truong-tieu-hoc-va-cong-dong','Tháng 6','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">V&agrave;o dịp h&egrave; h&agrave;ng năm, chương tr&igrave;nh \"Mizuiku - Em y&ecirc;u nước sạch\" hỗ trợ x&acirc;y dựng hệ thống lọc nước v&agrave; c&aacute;c c&ocirc;ng tr&igrave;nh vệ sinh tại c&aacute;c trường học v&agrave; nơi c&ocirc;ng cộng thuộc c&aacute;c địa b&agrave;n thiếu nước sạch trầm trọng tr&ecirc;n cả nước. Chủ đề Nước sạch cho cộng đồng l&agrave; th&ocirc;ng điệp tr&aacute;ch nhiệm x&atilde; hội của doanh nghiệp xuy&ecirc;n suốt m&agrave; Suntory PepsiCo Việt Nam muốn lan tỏa. B&ecirc;n cạnh đ&oacute;, c&aacute;c thầy c&ocirc; gi&aacute;o, lực lượng t&igrave;nh nguyện vi&ecirc;n v&agrave; c&aacute;c em học sinh c&ugrave;ng tham gia vẽ trang tr&iacute; tường xung quanh c&aacute;c cơ sở vật chất được hỗ trợ. Hoạt động n&agrave;y gi&uacute;p c&aacute;c em nhỏ tr&acirc;n trọng th&agrave;nh quả chung v&agrave; c&oacute; &yacute; thức giữ g&igrave;n vệ sinh tốt hơn.&nbsp;</span></p>',0,'vi',1,'2019-12-07 07:00:08',1,'2019-12-07 07:00:08',1,NULL,NULL),
	(12,11,'Constructing and upgrading clean water facilities at beneficiary elementary schools and community sites','constructing-and-upgrading-clean-water-facilities-at-beneficiary-elementary-schools-and-community-sites-1','June','<p><span style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">Every summer, \"Mizuiku - I love clean water\" program supports the construction of water filtration and sanitation facilities in schools and community sites in areas accross the country that are facing severe water shortage. \"Clean water for society\" is the key corporate social responsibility message that Suntory PepsiCo Vietnam aims to leverage across the country. Teachers, volunteers and students also collaborate to decorate the walls surrounding the facilities, which would encourage chidlren\'s appreciation and better use of the sponsored sanitation facilities.</span></p>',0,'en',1,'2019-12-07 07:02:03',1,'2019-12-07 07:02:03',1,NULL,NULL),
	(13,13,'Lớp học Mizuiku về bảo vệ môi trường và nguồn nước cho học sinh tiểu học','lop-hoc-mizuiku-ve-bao-ve-moi-truong-va-nguon-nuoc-cho-hoc-sinh-tieu-hoc','Tháng 5','<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">C&aacute;c lớp học Mizuiku được c&aacute;c thầy c&ocirc; tổ chức cho c&aacute;c em học sinh khối lớp 3, 4 tại c&aacute;c trường tiểu học thụ hưởng trong khu&ocirc;n khổ chương tr&igrave;nh. Điểm nhấn của phương ph&aacute;p gi&aacute;o dục lấy học sinh l&agrave;m trung t&acirc;m, dạy v&agrave; học s&aacute;ng tạo, tương t&aacute;c cao n&agrave;y l&agrave; c&aacute;c em hiểu b&agrave;i giảng, nhớ kiến thức l&acirc;u hơn, từ đ&oacute; n&acirc;ng cao nhận thức v&agrave; dẫn tới h&agrave;nh động cụ thể bảo vệ m&ocirc;i trường, bảo vệ nguồn nước. Chương tr&igrave;nh kỳ vọng tạo sự lan tỏa kiến thức v&agrave; h&agrave;nh động tới cộng đồng.</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">C&aacute;c lớp học c&oacute; sự tham gia phối hợp, hỗ trợ chặt chẽ của c&aacute;c đối t&aacute;c gi&aacute;o dục nhằm đảm bảo chất lượng v&agrave; sự thống nhất với gi&aacute;o tr&igrave;nh ti&ecirc;u chuẩn v&agrave; bộ t&agrave;i liệu của chương tr&igrave;nh.</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Sau khi tham gia lớp học, c&aacute;c em nhỏ sẽ nhận được s&aacute;ch b&agrave;i tập Nhật k&yacute; nước, truyện tranh Nước l&agrave; một m&oacute;n qu&agrave;, gi&uacute;p c&aacute;c em tổng hợp v&agrave; &aacute;p dụng c&aacute;c kiến thức đ&atilde; học trong đời sống h&agrave;ng ng&agrave;y.</div>',0,'vi',1,'2019-12-07 07:02:36',1,'2019-12-07 07:02:36',1,NULL,NULL),
	(14,13,'Mizuiku classes about water resource and environment education for elementary school students','mizuiku-classes-about-water-resource-and-environment-education-for-elementary-school-students','May','<div style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">Mizuiku teaching classes are held for students in Grade 3 and 4 of beneficiary schools by teachers, who have been trained in the TOT courses. Thanks to Mizuiku\'s student-centered, innovative and interactive teaching methods, it is easier for students to comprehend and remember the water/environment-related information conveyed in these classes which would result in students\' specific actions to protect the environment and water resource. The program hopes that these actions taken by young children will spread out to the whole community.</div>\r\n<div style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">The classes are well coordinated by educational partners to ensure the quality and consistency with Mizuiku standard syllabus and teaching materials.</div>\r\n<div style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">After participating in these classes, students will receive \"Water Diary\" workbook and \"Water is a gift\" comic book to help them review and apply taught knowledge into their daily routine.</div>',0,'en',1,'2019-12-07 07:03:05',1,'2019-12-07 07:03:05',1,NULL,NULL),
	(15,15,'Chương trình tập huấn dành cho giáo viên tiểu học','chuong-trinh-tap-huan-danh-cho-giao-vien-tieu-hoc','Tháng 4','<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">C&aacute;c lớp tập huấn (t&ecirc;n tiếng Anh l&agrave; Training of Trainers - TOT) d&agrave;nh cho lực lượng gi&aacute;o vi&ecirc;n tiểu học khối lớp 3-4 trong khu&ocirc;n khổ chương tr&igrave;nh &ldquo;Mizuiku &ndash; Em y&ecirc;u nước sạch&rdquo; được tổ chức dưới sự hướng dẫn của c&aacute;c đối t&aacute;c gi&aacute;o dục gồm c&oacute; Trung t&acirc;m Gi&aacute;o dục Sức khỏe &amp; Ph&aacute;t triển Cộng đồng Tương Lai v&agrave; Trung t&acirc;m Sống v&agrave; Học tập v&igrave; M&ocirc;i trường v&agrave; Cộng đồng (Live &amp; Learn). Từ năm 2017, lớp tập huấn được mở rộng cho c&aacute;c thầy c&ocirc; Tổng phụ tr&aacute;ch của c&aacute;c trường tiểu học thụ hưởng chương tr&igrave;nh cũng như c&aacute;c thầy c&ocirc; Tổng phụ tr&aacute;ch ti&ecirc;u biểu của c&aacute;c trường tr&ecirc;n địa b&agrave;n.</div>\r\n<div style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">C&aacute;c thầy c&ocirc; được giới thiệu v&agrave; thực h&agrave;nh ứng dụng phương ph&aacute;p giảng dạy chủ động với nhiều hoạt động tương t&aacute;c, tr&ograve; chơi, th&iacute; nghiệm với h&igrave;nh thức đa dạng v&agrave; c&aacute;ch truyền tải th&acirc;n thiện, dễ hiểu, b&aacute;m s&aacute;t theo chương tr&igrave;nh giảng dạy ti&ecirc;u chuẩn v&agrave; bộ t&agrave;i liệu của chương tr&igrave;nh.</div>',0,'vi',1,'2019-12-07 07:03:45',1,'2019-12-07 07:03:45',1,NULL,NULL),
	(16,15,'Trainings for Elementary School Teachers','trainings-for-elementary-school-teachers','April','<div style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">\"Mizuiku- I love clean water\" program provides training courses for elementary school teachers of Grade 3 and 4&nbsp; i.e. Training of Trainers (TOT ), which take place with the instruction of educational non-governmental partners including Tuong Lai Center and Live &amp; Learn Center. Starting from 2017, in addition to head teachers of Grade 3 and 4, the TOTs also engage head teachers of school young pioneer units from beneficiary schools and outstanding head teachers of school young pioneer units in beneficiary locations.&nbsp;</div>\r\n<div style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">Teachers get to practice dynamic teaching methods that involve giving water-related lessons through a variety of interactive activities, games, and experiments in accordance with Mizuiku\'s standard syllabus and teaching materials.&nbsp;</div>',0,'en',1,'2019-12-07 07:04:20',1,'2019-12-07 07:04:20',1,NULL,NULL),
	(17,17,'Khởi động chương trình “Mizuiku - Em yêu nước sạch”','khoi-dong-chuong-trinh-mizuiku-em-yeu-nuoc-sach','Tháng 3','<p><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Hơn 1.3000 học sinh v&agrave; tr&ecirc;n 200 thầy c&ocirc; gi&aacute;o tỉnh Bến Tre đ&atilde; tham dự chương tr&igrave;nh. Đ&acirc;y l&agrave; một chương tr&igrave;nh mang t&iacute;nh tuy&ecirc;n truyền gi&aacute;o dục c&oacute; &yacute; nghĩa thực tế cao, dự &aacute;n tập trung v&agrave;o việc gi&aacute;o dục cho trẻ em về vai tr&ograve; của t&agrave;i nguy&ecirc;n nước tr&ecirc;n tr&aacute;i đất, từ đ&oacute; gi&uacute;p c&aacute;c em đảm bảo an to&agrave;n vệ sinh nước v&agrave; g&oacute;p phần duy tr&igrave; t&agrave;i nguy&ecirc;n nước cho thế hệ mai sau. Dự &aacute;n do Tập đo&agrave;n Suntory Holdings Ltd. (Nhật Bản) khởi xướng v&agrave; triển khai tại Nhật Bản từ năm 2004. Việt Nam l&agrave; đất nước đầu ti&ecirc;n ngo&agrave;i Nhật Bản được Tập đo&agrave;n Suntory chọn để triển khai chương tr&igrave;nh.</span><br style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\" /><br style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\" /><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Năm 2015-2016, Dự &aacute;n do Tập đo&agrave;n Suntory v&agrave; Suntory PepsiCo Việt Nam t&agrave;i trợ to&agrave;n bộ kinh ph&iacute;, triển khai tại H&agrave; Nội, Bắc Ninh v&agrave; Tp. Hồ Ch&iacute; Minh. Chương tr&igrave;nh đ&atilde; tổ chức hơn 400 lớp học cho khoảng 5.000 học sinh; 16 ng&agrave;y hội nước cho hơn 7.700 học sinh, 15 chuyến tham quan nh&agrave; m&aacute;y SPVBcho 1.300 học sinh; x&acirc;y dựng, cải tạo cơ sở vật chất, hệ thống lọc nước tại 16 trường tiểu học tham gia dự &aacute;n c&ugrave;ng h&agrave;ng ngh&igrave;n học sinh, thầy c&ocirc; gi&aacute;o v&agrave; người d&acirc;n tại c&aacute;c địa phương ghi nhận những t&iacute;n hiệu t&iacute;ch cực từ dự &aacute;n.</span><br style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\" /><br style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\" /><span style=\"color: #333333; font-family: Arial; font-size: 16px; text-align: justify;\">Năm 2017, dự &aacute;n &ldquo;Mizuiku &ndash; Em Y&ecirc;u Nước Sạch&rdquo; sẽ từng bước mở r&ocirc;̣ng quy m&ocirc; tri&ecirc;̉n khai tr&ecirc;n cả nước với sự tham gia của 30 trường ti&ecirc;̉u học tại tỉnh Bắc Ninh, H&agrave; Nội, Tp. Hồ Ch&iacute; Minh v&agrave; Bến Tre. C&aacute;c hoạt động ch&iacute;nh của dự &aacute;n bao gồm Triển khai lễ ph&aacute;t động tại tỉnh Bến Tre; Tặng bộ t&agrave;i liệu chương tr&igrave;nh cho 10 trường tiểu học đ&atilde; tham gia dự &aacute;n năm 2016; Tổ chức tập huấn cho đội ngũ T&igrave;nh nguyện vi&ecirc;n, lực lượng gi&aacute;o vi&ecirc;n tổng phụ tr&aacute;ch Đội, gi&aacute;o vi&ecirc;n trực tiếp giảng dạy khối lớp 3, 4 tại c&aacute;c trường được lựa chọn triển khai chương tr&igrave;nh; Tổ chức c&aacute;c lớp học tuy&ecirc;n truyền gi&aacute;o dục về nước, Ng&agrave;y hội Hiệp sỹ nước sạch, c&aacute;c chuyến tham quan nh&agrave; m&aacute;y SPVB cho học sinh c&aacute;c trường tham gia dự &aacute;n; Dự kiến x&acirc;y dựng 11 c&ocirc;ng tr&igrave;nh nước sạch tại c&aacute;c trường Tiểu học v&agrave; tại cộng đồng&hellip;</span></p>',0,'vi',1,'2019-12-07 07:04:48',1,'2019-12-07 07:04:48',1,NULL,NULL),
	(18,17,'Nationwide \"Mizuiku-I love clean water\" program kick-off ceremony','nationwide-mizuiku-i-love-clean-water-program-kick-off-ceremony','March','<div style=\"caret-color: #333333; color: #333333; font-family: Arial; font-size: 16px; text-align: justify; text-size-adjust: auto;\">On the annual World Water Day (March 22), \"Mizuiku - I love clean water\" co-hosting agencies including Suntory Holdings Limited, Suntory PepsiCo Vietnam, Vietnam National Union of Student, Ho Chi Minh Young Pioneer Organization, together with Vietnam Ministry of Education and Training&nbsp; organize kick-off ceremony with the participation of thousands of students, teachers and representatives from national and local authorities.</div>',0,'en',1,'2019-12-07 07:05:21',1,'2019-12-07 07:05:21',1,NULL,NULL);

/*!40000 ALTER TABLE `program_timeline` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table provinces
# ------------------------------------------------------------

DROP TABLE IF EXISTS `provinces`;

CREATE TABLE `provinces` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name_vi` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `provinces` WRITE;
/*!40000 ALTER TABLE `provinces` DISABLE KEYS */;

INSERT INTO `provinces` (`id`, `parent_id`, `name_vi`, `name_en`, `create_user`, `update_user`, `created_at`, `updated_at`, `deleted_at`)
VALUES
	(1,0,'An Giang','An Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(2,1,'An Phú','An Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(3,1,'Châu Đốc','Châu Đốc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(4,1,'Châu Phú','Châu Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(5,1,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(6,1,'Chợ Mới','Chợ Mới','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(7,1,'Long Xuyên','Long Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(8,1,'Phú Tân','Phú Tân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(9,1,'Tân Châu','Tân Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(10,1,'Thoại Sơn','Thoại Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(11,1,'Tịnh Biên','Tịnh Biên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(12,1,'Tri Tôn','Tri Tôn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(13,0,'Bà Rịa–Vũng Tàu','Bà Rịa–Vũng Tàu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(14,13,'Bà Rịa','Bà Rịa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(15,13,'Châu Đức','Châu Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(16,13,'Côn Đảo','Côn Đảo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(17,13,'Đất Đỏ','Đất Đỏ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(18,13,'Long Điền','Long Điền','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(19,13,'Tân Thành','Tân Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(20,13,'Vũng Tàu','Vũng Tàu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(21,13,'Xuyên Mộc','Xuyên Mộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(22,0,'Bắc Giang','Bắc Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(23,22,'Bắc Giang','Bắc Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(24,22,'Hiệp Hòa','Hiệp Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(25,22,'Lạng Giang','Lạng Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(26,22,'Lục Nam','Lục Nam','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(27,22,'Lục Ngạn','Lục Ngạn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(28,22,'Sơn Động','Sơn Động','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(29,22,'Tân Yên','Tân Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(30,22,'Việt Yên','Việt Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(31,22,'Yên Dũng','Yên Dũng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(32,22,'Yên Thế','Yên Thế','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(33,0,'Bắc Kạn','Bắc Kạn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(34,33,'Ba Bể','Ba Bể','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(35,33,'Bắc Kạn','Bắc Kạn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(36,33,'Bạch Thông','Bạch Thông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(37,33,'Chợ Đồn','Chợ Đồn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(38,33,'Chợ Mới','Chợ Mới','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(39,33,'Na Rì','Na Rì','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(40,33,'Ngân Sơn','Ngân Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(41,33,'Pác Nặm','Pác Nặm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(42,0,'Bạc Liêu','Bạc Liêu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(43,42,'Bạc Liêu','Bạc Liêu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(44,42,'Đông Hải','Đông Hải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(45,42,'Giá Rai','Giá Rai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(46,42,'Hòa Bình','Hòa Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(47,42,'Hồng Dân','Hồng Dân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(48,42,'Phước Long','Phước Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(49,42,'Vĩnh Lợi','Vĩnh Lợi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(50,0,'Bắc Ninh','Bắc Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(51,50,'Bắc Ninh','Bắc Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(52,50,'Gia Bình','Gia Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(53,50,'Lương Tài','Lương Tài','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(54,50,'Quế Võ','Quế Võ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(55,50,'Thuận Thành','Thuận Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(56,50,'Tiên Du','Tiên Du','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(57,50,'Từ Sơn','Từ Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(58,50,'Yên Phong','Yên Phong','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(59,0,'Bến Tre','Bến Tre','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(60,59,'Ba Tri','Ba Tri','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(61,59,'Bến Tre','Bến Tre','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(62,59,'Bình Đại','Bình Đại','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(63,59,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(64,59,'Chợ Lách','Chợ Lách','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(65,59,'Giồng Trôm','Giồng Trôm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(66,59,'Mỏ Cày','Mỏ Cày','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(67,59,'Thạnh Phú','Thạnh Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(68,0,'Bình Định','Bình Định','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(69,68,'An Lão','An Lão','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(70,68,'An Nhơn','An Nhơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(71,68,'Hoài Ân','Hoài Ân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(72,68,'Hoài Nhơn','Hoài Nhơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(73,68,'Phù Cát','Phù Cát','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(74,68,'Phù Mỹ','Phù Mỹ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(75,68,'Qui Nhơn','Qui Nhơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(76,68,'Tây Sơn','Tây Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(77,68,'Tuy Phước','Tuy Phước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(78,68,'Vân Canh','Vân Canh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(79,68,'Vĩnh Thạnh','Vĩnh Thạnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(80,0,'Bình Dương','Bình Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(81,80,'Bắc Tân Uyên','Bắc Tân Uyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(82,80,'Bàu Bàng','Bàu Bàng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(83,80,'Bến Cát','Bến Cát','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(84,80,'Dầu Tiếng','Dầu Tiếng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(85,80,'Dĩ An','Dĩ An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(86,80,'Phú Giáo','Phú Giáo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(87,80,'Tân Uyên','Tân Uyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(88,80,'Thủ Dầu Một','Thủ Dầu Một','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(89,80,'Thuận An','Thuận An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(90,0,'Bình Phước','Bình Phước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(91,90,'Bình Long','Bình Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(92,90,'Bù Đăng','Bù Đăng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(93,90,'Bù Đốp','Bù Đốp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(94,90,'Bù Gia Mập','Bù Gia Mập','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(95,90,'Chơn Thành','Chơn Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(96,90,'Đồng Phú','Đồng Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(97,90,'Đồng Xoài','Đồng Xoài','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(98,90,'Hớn Quản','Hớn Quản','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(99,90,'Lộc Ninh','Lộc Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(100,90,'Phước Long','Phước Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(101,0,'Bình Thuận','Bình Thuận','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(102,101,'Bắc Bình','Bắc Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(103,101,'Đức Linh','Đức Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(104,101,'Hàm Tân','Hàm Tân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(105,101,'Hàm Thuận Bắc','Hàm Thuận Bắc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(106,101,'Hàm Thuận Nam','Hàm Thuận Nam','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(107,101,'La Gi','La Gi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(108,101,'Phan Thiết','Phan Thiết','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(109,101,'Phú Quý','Phú Quý','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(110,101,'Tánh Linh','Tánh Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(111,101,'Tuy Phong','Tuy Phong','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(112,0,'Cà Mau','Cà Mau','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(113,112,'Cà Mau','Cà Mau','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(114,112,'Đầm Dơi','Đầm Dơi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(115,112,'Cái Nước','Cái Nước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(116,112,'Năm Căn','Năm Căn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(117,112,'Ngọc Hiển','Ngọc Hiển','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(118,112,'Phú Tân','Phú Tân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(119,112,'Thới Bình','Thới Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(120,112,'Trần Văn Thời','Trần Văn Thời','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(121,112,'U Minh','U Minh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(122,112,'Cần Thơ','Cần Thơ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(123,112,'Bình Thủy','Bình Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(124,112,'Cái Răng','Cái Răng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(125,112,'Cần Thơ','Cần Thơ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(126,112,'Cờ Đỏ','Cờ Đỏ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(127,112,'Ninh Kiều','Ninh Kiều','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(128,112,'Ô Môn','Ô Môn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(129,112,'Phong Điền','Phong Điền','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(130,112,'Thới Lai','Thới Lai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(131,112,'Thốt Nốt','Thốt Nốt','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(132,112,'Vĩnh Thạnh','Vĩnh Thạnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(133,0,'Cao Bằng','Cao Bằng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(134,133,'Bảo Lạc','Bảo Lạc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(135,133,'Bảo Lâm','Bảo Lâm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(136,133,'Cao Bằng','Cao Bằng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(137,133,'Hạ Lang','Hạ Lang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(138,133,'Hà Quảng','Hà Quảng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(139,133,'Hòa An','Hòa An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(140,133,'Nguyên Bình','Nguyên Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(141,133,'Phục Hòa','Phục Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(142,133,'Quảng Uyên','Quảng Uyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(143,133,'Thạch An','Thạch An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(144,133,'Thông Nông','Thông Nông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(145,133,'Trà Lĩnh','Trà Lĩnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(146,133,'Trùng Khánh','Trùng Khánh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(147,133,'Đà Nẵng','Đà Nẵng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(148,133,'Cẩm Lệ','Cẩm Lệ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(149,133,'Hải Châu','Hải Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(150,133,'Hòa Vang','Hòa Vang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(151,133,'Hoàng Sa','Hoàng Sa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(152,133,'Liên Chiểu','Liên Chiểu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(153,133,'Ngũ Hành Sơn','Ngũ Hành Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(154,133,'Sơn Trà','Sơn Trà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(155,133,'Thanh Khê','Thanh Khê','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(156,0,'Đắk Lắk','Đắk Lắk','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(157,156,'Buôn Đôn','Buôn Đôn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(158,156,'Buôn Hồ','Buôn Hồ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(159,156,'Buôn Ma Thuột','Buôn Ma Thuột','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(160,156,'Cư M\'gar','Cư M\'gar','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(161,156,'Cư Kuin','Cư Kuin','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(162,156,'Ea H\'leo','Ea H\'leo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(163,156,'Ea Kar','Ea Kar','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(164,156,'Ea Súp','Ea Súp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(165,156,'Krông Ana','Krông Ana','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(166,156,'Krông Bông','Krông Bông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(167,156,'Krông Buk','Krông Buk','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(168,156,'Krông Năng','Krông Năng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(169,156,'Krông Pắk','Krông Pắk','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(170,156,'Lắk','Lắk','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(171,156,'M\'Đrăk','M\'Đrăk','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(172,0,'Đắk Nông','Đắk Nông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(173,172,'Cư Jút','Cư Jút','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(174,172,'Đắk Glong','Đắk Glong','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(175,172,'Đắk Mil','Đắk Mil','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(176,172,'Đắk R\'Lấp','Đắk R\'Lấp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(177,172,'Đắk Song','Đắk Song','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(178,172,'Gia Nghĩa','Gia Nghĩa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(179,172,'Krông Nô','Krông Nô','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(180,172,'Tuy Đức','Tuy Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(181,0,'Điện Biên','Điện Biên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(182,181,'Điện Biên','Điện Biên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(183,181,'Điện Biên Đông','Điện Biên Đông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(184,181,'Điện Biên Phủ','Điện Biên Phủ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(185,181,'Mường Chà','Mường Chà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(186,181,'Mường Nhé','Mường Nhé','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(187,181,'Tủa Chùa','Tủa Chùa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(188,181,'Tuần Giáo','Tuần Giáo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(189,0,'Đồng Nai','Đồng Nai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(190,189,'Biên Hòa','Biên Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(191,189,'Cẩm Mỹ','Cẩm Mỹ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(192,189,'Định Quán','Định Quán','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(193,189,'Long Khánh','Long Khánh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(194,189,'Long Thành','Long Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(195,189,'Nhơn Trạch','Nhơn Trạch','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(196,189,'Tân Phú','Tân Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(197,189,'Thống Nhất','Thống Nhất','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(198,189,'Trảng Bom','Trảng Bom','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(199,189,'Vĩnh Cữu','Vĩnh Cữu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(200,189,'Xuân Lộc','Xuân Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(201,0,'Đồng Tháp','Đồng Tháp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(202,201,'Cao Lãnh','Cao Lãnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(203,201,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(204,201,'Hồng Ngự','Hồng Ngự','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(205,201,'Lai Vung','Lai Vung','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(206,201,'Lấp Vò','Lấp Vò','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(207,201,'Tam Nông','Tam Nông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(208,201,'Tân Hồng','Tân Hồng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(209,201,'Thanh Bình','Thanh Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(210,201,'Tháp Mười','Tháp Mười','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(211,0,'Gia Lai','Gia Lai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(212,211,'Ayun Pa','Ayun Pa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(213,211,'An Khê','An Khê','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(214,211,'Chư Păh','Chư Păh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(215,211,'Chư Prông','Chư Prông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(216,211,'Chư Pưh','Chư Pưh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(217,211,'Chư Sê','Chư Sê','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(218,211,'Đắk Đoa','Đắk Đoa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(219,211,'Đắk Pơ','Đắk Pơ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(220,211,'Đức Cơ','Đức Cơ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(221,211,'Ia Grai','Ia Grai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(222,211,'Ia Pa','Ia Pa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(223,211,'K\'Bang','K\'Bang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(224,211,'Kông Chro','Kông Chro','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(225,211,'Krông Pa','Krông Pa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(226,211,'Mang Yang','Mang Yang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(227,211,'Phú Thiện','Phú Thiện','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(228,211,'Pleiku','Pleiku','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(229,0,'Hà Giang','Hà Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(230,229,'Bắc Mê','Bắc Mê','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(231,229,'Bắc Quang','Bắc Quang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(232,229,'Đồng Văn','Đồng Văn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(233,229,'Hà Giang','Hà Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(234,229,'Hoàng Su Phì','Hoàng Su Phì','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(235,229,'Mèo Vạc','Mèo Vạc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(236,229,'Quản Bạ','Quản Bạ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(237,229,'Quảng Bình','Quảng Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(238,229,'Vị Xuyên','Vị Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(239,229,'Xín Mần','Xín Mần','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(240,229,'Yên Minh','Yên Minh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(241,0,'Hà Nam','Hà Nam','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(242,241,'Bình Lục','Bình Lục','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(243,241,'Duy Tiên','Duy Tiên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(244,241,'Kim Bảng','Kim Bảng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(245,241,'Lý Nhân','Lý Nhân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(246,241,'Phủ Lý','Phủ Lý','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(247,241,'Thanh Liêm','Thanh Liêm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(248,241,'Hà Nội','Hà Nội','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(249,241,'Ba Đình','Ba Đình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(250,241,'Cầu Giấy','Cầu Giấy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(251,241,'Đông Anh','Đông Anh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(252,241,'Đống Đa','Đống Đa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(253,241,'Gia Lâm','Gia Lâm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(254,241,'Hai Bà Trưng','Hai Bà Trưng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(255,241,'Hoàn Kiếm','Hoàn Kiếm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(256,241,'Hoàng Mai','Hoàng Mai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(257,241,'Mê Linh','Mê Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(258,241,'Long Biên','Long Biên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(259,241,'Sóc Sơn','Sóc Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(260,241,'Tây Hồ','Tây Hồ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(261,241,'Thanh Trì','Thanh Trì','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(262,241,'Thanh Xuân','Thanh Xuân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(263,241,'Từ Liêm','Từ Liêm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(264,241,'Ba Vì','Ba Vì','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(265,241,'Chương Mỹ','Chương Mỹ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(266,241,'Đan Phượng','Đan Phượng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(267,241,'Hà Đông','Hà Đông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(268,241,'Hoài Đức','Hoài Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(269,241,'Mỹ Đức','Mỹ Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(270,241,'Phú Xuyên','Phú Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(271,241,'Phúc Thọ','Phúc Thọ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(272,241,'Quốc Oai','Quốc Oai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(273,241,'Sơn Tây','Sơn Tây','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(274,241,'Thạch Thất','Thạch Thất','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(275,241,'Thanh Oai','Thanh Oai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(276,241,'Thường Tín','Thường Tín','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(277,241,'Ứng Hòa','Ứng Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(278,0,'Hà Tĩnh','Hà Tĩnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(279,278,'Cẩm Xuyên','Cẩm Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(280,278,'Can Lộc','Can Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(281,278,'Đức Thọ','Đức Thọ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(282,278,'Hà Tĩnh','Hà Tĩnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(283,278,'Hồng Lĩnh','Hồng Lĩnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(284,278,'Hương Khê','Hương Khê','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(285,278,'Hương Sơn','Hương Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(286,278,'Kỳ Anh','Kỳ Anh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(287,278,'Nghi Xuân','Nghi Xuân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(288,278,'Thạch Hà','Thạch Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(289,278,'Vũ Quang','Vũ Quang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(290,0,'Hải Dương','Hải Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(291,290,'Bình Giang','Bình Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(292,290,'Cẩm Giàng','Cẩm Giàng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(293,290,'Chí Linh','Chí Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(294,290,'Gia Lộc','Gia Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(295,290,'Hải Dương','Hải Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(296,290,'Kim Thành','Kim Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(297,290,'Kinh Môn','Kinh Môn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(298,290,'Nam Sách','Nam Sách','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(299,290,'Ninh Giang','Ninh Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(300,290,'Thanh Hà','Thanh Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(301,290,'Thanh Miện','Thanh Miện','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(302,290,'Tứ Kỳ','Tứ Kỳ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(303,290,'Hải Phòng','Hải Phòng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(304,290,'An Dương','An Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(305,290,'An Lão','An Lão','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(306,290,'Bạch Long Vĩ','Bạch Long Vĩ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(307,290,'Cát Hải','Cát Hải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(308,290,'Đồ Sơn','Đồ Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(309,290,'Hải An','Hải An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(310,290,'Hồng Bàng','Hồng Bàng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(311,290,'Kiến An','Kiến An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(312,290,'Kiến Thuỵ','Kiến Thuỵ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(313,290,'Lê Chân','Lê Chân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(314,290,'Ngô Quyền','Ngô Quyền','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(315,290,'Thủy Nguyên','Thủy Nguyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(316,290,'Tiên Lãng','Tiên Lãng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(317,290,'Vĩnh Bảo','Vĩnh Bảo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(318,290,'Dương Kinh','Dương Kinh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(319,0,'Hậu Giang','Hậu Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(320,319,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(321,319,'Châu Thành A','Châu Thành A','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(322,319,'Long Mỹ','Long Mỹ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(323,319,'Phụng Hiệp','Phụng Hiệp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(324,319,'Vị Thanh','Vị Thanh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(325,319,'Vị Thủy','Vị Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(326,319,'Ngã Bảy','Ngã Bảy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(327,0,'Hồ Chí Minh','Hồ Chí Minh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(328,327,'Bình Chánh','Bình Chánh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(329,327,'Bình Tân','Bình Tân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(330,327,'Bình Thạnh','Bình Thạnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(331,327,'Cần Giờ','Cần Giờ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(332,327,'Củ Chi','Củ Chi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(333,327,'Quận 1','Quận 1','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(334,327,'Quận 2','Quận 2','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(335,327,'Quận 3','Quận 3','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(336,327,'Quận 4','Quận 4','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(337,327,'Quận 5','Quận 5','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(338,327,'Quận 6','Quận 6','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(339,327,'Quận 7','Quận 7','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(340,327,'Quận 8','Quận 8','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(341,327,'Quận 9','Quận 9','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(342,327,'Quận 10','Quận 10','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(343,327,'Quận 11','Quận 11','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(344,327,'Quận 12','Quận 12','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(345,327,'Gò Vấp','Gò Vấp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(346,327,'Hóc Môn','Hóc Môn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(347,327,'Nhà Bè','Nhà Bè','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(348,327,'Phú Nhuận','Phú Nhuận','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(349,327,'Tân Bình','Tân Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(350,327,'Tân Phú','Tân Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(351,327,'Thủ Đức','Thủ Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(352,0,'Hòa Bình','Hòa Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(353,352,'Cao Phong','Cao Phong','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(354,352,'Đà Bắc','Đà Bắc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(355,352,'Hòa Bình','Hòa Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(356,352,'Kim Bôi','Kim Bôi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(357,352,'Kỳ Sơn','Kỳ Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(358,352,'Lạc Sơn','Lạc Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(359,352,'Lạc Thủy','Lạc Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(360,352,'Lương Sơn','Lương Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(361,352,'Mai Châu','Mai Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(362,352,'Tân Lạc','Tân Lạc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(363,352,'Yên Thủy','Yên Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(364,0,'Hưng Yên','Hưng Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(365,364,'Ân Thi','Ân Thi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(366,364,'Hưng Yên','Hưng Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(367,364,'Khoái Châu','Khoái Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(368,364,'Kim Động','Kim Động','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(369,364,'Mỹ Hào','Mỹ Hào','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(370,364,'Phù Cừ','Phù Cừ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(371,364,'Tiên Lữ','Tiên Lữ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(372,364,'Văn Giang','Văn Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(373,364,'Văn Lâm','Văn Lâm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(374,364,'Yên Mỹ','Yên Mỹ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(375,0,'Khánh Hòa','Khánh Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(376,375,'Cam Lâm','Cam Lâm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(377,375,'Cam Ranh','Cam Ranh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(378,375,'Diên Khánh','Diên Khánh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(379,375,'Khánh Sơn','Khánh Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(380,375,'Khánh Vĩnh','Khánh Vĩnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(381,375,'Nha Trang','Nha Trang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(382,375,'Ninh Hòa','Ninh Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(383,375,'Trường Sa','Trường Sa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(384,375,'Vạn Ninh','Vạn Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(385,0,'Kiên Giang','Kiên Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(386,385,'An Biên','An Biên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(387,385,'An Minh','An Minh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(388,385,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(389,385,'Giồng Riềng','Giồng Riềng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(390,385,'Gò Quao','Gò Quao','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(391,385,'Giang Thành','Giang Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(392,385,'Hà Tiên','Hà Tiên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(393,385,'Hòn Đất','Hòn Đất','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(394,385,'Kiên Hải','Kiên Hải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(395,385,'Kiên Lương','Kiên Lương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(396,385,'Phú Quốc','Phú Quốc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(397,385,'Rạch Giá','Rạch Giá','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(398,385,'Tân Hiệp','Tân Hiệp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(399,385,'Vĩnh Thuận','Vĩnh Thuận','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(400,385,'U Minh Thượng','U Minh Thượng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(401,0,'Kon Tum','Kon Tum','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(402,401,'Đắk Glei','Đắk Glei','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(403,401,'Đắk Hà','Đắk Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(404,401,'Đắk Tô','Đắk Tô','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(405,401,'Kon Plông','Kon Plông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(406,401,'Kon Rẫy','Kon Rẫy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(407,401,'Kon Tum','Kon Tum','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(408,401,'Ngọc Hồi','Ngọc Hồi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(409,401,'Sa Thầy','Sa Thầy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(410,401,'Tu Mơ Rông','Tu Mơ Rông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(411,0,'Lai Châu','Lai Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(412,411,'Lai Châu','Lai Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(413,411,'Mường Tè','Mường Tè','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(414,411,'Phong Thổ','Phong Thổ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(415,411,'Sìn Hồ','Sìn Hồ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:43','2018-11-07 08:18:43',NULL),
	(416,411,'Tam Đường','Tam Đường','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(417,411,'Than Uyên','Than Uyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(418,411,'Tân Uyên','Tân Uyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(419,0,'Lâm Đồng','Lâm Đồng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(420,419,'Bảo Lâm','Bảo Lâm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(421,419,'Bảo Lộc','Bảo Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(422,419,'Cát Tiên','Cát Tiên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(423,419,'Đạ Huoai','Đạ Huoai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(424,419,'Đà Lạt','Đà Lạt','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(425,419,'Đạ Tẻh','Đạ Tẻh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(426,419,'Đam Rông','Đam Rông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(427,419,'Di Linh','Di Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(428,419,'Đơn Dương','Đơn Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(429,419,'Đức Trọng','Đức Trọng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(430,419,'Lạc Dương','Lạc Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(431,419,'Lâm Hà','Lâm Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(432,0,'Lạng Sơn','Lạng Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(433,432,'Bắc Sơn','Bắc Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(434,432,'Bình Gia','Bình Gia','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(435,432,'Cao Lộc','Cao Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(436,432,'Chi Lăng','Chi Lăng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(437,432,'Đình Lập','Đình Lập','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(438,432,'Hữu Lũng','Hữu Lũng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(439,432,'Lạng Sơn','Lạng Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(440,432,'Lộc Bình','Lộc Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(441,432,'Tràng Định','Tràng Định','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(442,432,'Văn Lãng','Văn Lãng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(443,432,'Văn Quân','Văn Quân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(444,0,'Lào Cai','Lào Cai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(445,444,'Bắc Hà','Bắc Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(446,444,'Bảo Thắng','Bảo Thắng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(447,444,'Bảo Yên','Bảo Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(448,444,'Bát Xát','Bát Xát','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(449,444,'Lào Cai','Lào Cai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(450,444,'Mường Khương','Mường Khương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(451,444,'Sa Pa','Sa Pa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(452,444,'Si Ma Cai','Si Ma Cai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(453,444,'Văn Bàn','Văn Bàn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(454,0,'Long An','Long An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(455,454,'Bến Lức','Bến Lức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(456,454,'Cần Đước','Cần Đước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(457,454,'Cần Giuộc','Cần Giuộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(458,454,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(459,454,'Đức Hòa','Đức Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(460,454,'Đức Huệ','Đức Huệ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(461,454,'Kiến Tường','Kiến Tường','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(462,454,'Mộc Hóa','Mộc Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(463,454,'Tân An','Tân An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(464,454,'Tân Hưng','Tân Hưng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(465,454,'Tân Thạnh','Tân Thạnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(466,454,'Tân Trụ','Tân Trụ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(467,454,'Thạnh Hóa','Thạnh Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(468,454,'Thủ Thừa','Thủ Thừa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(469,454,'Vĩnh Hưng','Vĩnh Hưng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(470,0,'Nam Định','Nam Định','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(471,470,'Giao Thủy','Giao Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(472,470,'Hải Hậu','Hải Hậu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(473,470,'Mỹ Lộc','Mỹ Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(474,470,'Nam Định','Nam Định','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(475,470,'Nam Trực','Nam Trực','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(476,470,'Nghĩa Hưng','Nghĩa Hưng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(477,470,'Trực Ninh','Trực Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(478,470,'Vụ Bản','Vụ Bản','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(479,470,'Xuân Trường','Xuân Trường','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(480,470,'Ý Yên','Ý Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(481,0,'Nghệ An','Nghệ An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(482,481,'Anh Sơn','Anh Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(483,481,'Con Cuông','Con Cuông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(484,481,'Cửa Lò','Cửa Lò','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(485,481,'Diễn Châu','Diễn Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(486,481,'Đô Lương','Đô Lương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(487,481,'Hưng Nguyên','Hưng Nguyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(488,481,'Kỳ Sơn','Kỳ Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(489,481,'Nam Đàn','Nam Đàn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(490,481,'Nghi Lộc','Nghi Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(491,481,'Nghĩa Đàn','Nghĩa Đàn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(492,481,'Quế Phong','Quế Phong','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(493,481,'Quỳnh Lưu','Quỳnh Lưu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(494,481,'Quỳ Châu','Quỳ Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(495,481,'Quỳ Hợp','Quỳ Hợp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(496,481,'Tân Kỳ','Tân Kỳ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(497,481,'Thanh Chương','Thanh Chương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(498,481,'Tương Dương','Tương Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(499,481,'Vinh','Vinh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(500,481,'Yên Thành','Yên Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(501,481,'Thái Hòa','Thái Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(502,0,'Ninh Bình','Ninh Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(503,502,'Gia Viễn','Gia Viễn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(504,502,'Hoa Lư','Hoa Lư','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(505,502,'Kim Sơn','Kim Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(506,502,'Nho Quan','Nho Quan','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(507,502,'Ninh Bình','Ninh Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(508,502,'Tam Diệp','Tam Diệp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(509,502,'Yên Khánh','Yên Khánh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(510,502,'Yên Mô','Yên Mô','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(511,0,'Ninh Thuận','Ninh Thuận','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(512,511,'Ninh Hải','Ninh Hải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(513,511,'Ninh Phước','Ninh Phước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(514,511,'Ninh Sơn','Ninh Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(515,511,'Phan Rang–Tháp Chàm','Phan Rang–Tháp Chàm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(516,511,'Thuận Bắc','Thuận Bắc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(517,511,'Thuận Nam','Thuận Nam','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(518,0,'Phú Thọ','Phú Thọ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(519,518,'Cẩm Khê','Cẩm Khê','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(520,518,'Đoan Hùng','Đoan Hùng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(521,518,'Hạ Hòa','Hạ Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(522,518,'Lâm Thao','Lâm Thao','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(523,518,'Phù Ninh','Phù Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(524,518,'Phú Thọ','Phú Thọ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(525,518,'Tam Nông','Tam Nông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(526,518,'Tân Sơn','Tân Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(527,518,'Thanh Ba','Thanh Ba','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(528,518,'Thanh Sơn','Thanh Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(529,518,'Thanh Thủy','Thanh Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(530,518,'Việt Trì','Việt Trì','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(531,518,'Yên Lập','Yên Lập','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(532,0,'Phú Yên','Phú Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(533,532,'Đông Hòa','Đông Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(534,532,'Đồng Xuân','Đồng Xuân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(535,532,'Phú Hòa','Phú Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(536,532,'Sơn Hòa','Sơn Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(537,532,'Sông Cầu','Sông Cầu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(538,532,'Sông Hinh','Sông Hinh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(539,532,'Tây Hòa','Tây Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(540,532,'Tuy An','Tuy An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(541,532,'Tuy Hòa','Tuy Hòa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(542,0,'Quảng Bình','Quảng Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(543,542,'Bố Trạch','Bố Trạch','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(544,542,'Đồng Hới','Đồng Hới','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(545,542,'Lệ Thủy','Lệ Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(546,542,'Minh Hóa','Minh Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(547,542,'Quảng Ninh','Quảng Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(548,542,'Quảng Trạch','Quảng Trạch','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(549,542,'Tuyên Hóa','Tuyên Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(550,0,'Quảng Nam','Quảng Nam','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(551,550,'Bắc Trà My','Bắc Trà My','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(552,550,'Đại Lộc','Đại Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(553,550,'Điện Bàn','Điện Bàn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(554,550,'Đông Giang','Đông Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(555,550,'Duy Xuyên','Duy Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(556,550,'Hiệp Đức','Hiệp Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(557,550,'Hội An','Hội An','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(558,550,'Nam Giang','Nam Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(559,550,'Nam Trà My','Nam Trà My','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(560,550,'Núi Thành','Núi Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(561,550,'Phước Sơn','Phước Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(562,550,'Quế Sơn','Quế Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(563,550,'Tam Kỳ','Tam Kỳ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(564,550,'Tây Giang','Tây Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(565,550,'Thăng Bình','Thăng Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(566,550,'Tiên Phước','Tiên Phước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(567,550,'Nông Sơn','Nông Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(568,0,'Quảng Ngãi','Quảng Ngãi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(569,568,'Ba Tơ','Ba Tơ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(570,568,'Bình Sơn','Bình Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(571,568,'Đức Phổ','Đức Phổ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(572,568,'Lý Sơn','Lý Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(573,568,'Minh Long','Minh Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(574,568,'Mộ Đức','Mộ Đức','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(575,568,'Nghĩa Hành','Nghĩa Hành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(576,568,'Quảng Ngãi','Quảng Ngãi','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(577,568,'Sơn Hà','Sơn Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(578,568,'Sơn Tây','Sơn Tây','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(579,568,'Sơn Tịnh','Sơn Tịnh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(580,568,'Tây Trà','Tây Trà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(581,568,'Trà Bồng','Trà Bồng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(582,568,'Tư Nghĩa','Tư Nghĩa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(583,0,'Quảng Ninh','Quảng Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(584,583,'Ba Chẽ','Ba Chẽ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(585,583,'Bình Liêu','Bình Liêu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(586,583,'Cẩm Phả','Cẩm Phả','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(587,583,'Cô Tô','Cô Tô','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(588,583,'Đầm Hà','Đầm Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(589,583,'Đông Triều','Đông Triều','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(590,583,'Hạ Long','Hạ Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(591,583,'Hải Hà','Hải Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(592,583,'Hoành Bồ','Hoành Bồ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(593,583,'Móng Cái','Móng Cái','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(594,583,'Tiên Yên','Tiên Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(595,583,'Uông Bí','Uông Bí','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(596,583,'Vân Đồn','Vân Đồn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(597,583,'Yên Hưng','Yên Hưng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(598,0,'Quảng Trị','Quảng Trị','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(599,598,'Cam Lộ','Cam Lộ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(600,598,'Cồn Cỏ','Cồn Cỏ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(601,598,'Đa Krông','Đa Krông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(602,598,'Đông Hà','Đông Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(603,598,'Gio Linh','Gio Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(604,598,'Hải Lăng','Hải Lăng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(605,598,'Hướng Hóa','Hướng Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(606,598,'Quảng Trị','Quảng Trị','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(607,598,'Triệu Phong','Triệu Phong','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(608,598,'Vĩnh Linh','Vĩnh Linh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(609,0,'Sóc Trăng','Sóc Trăng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(610,609,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(611,609,'Cù Lao Dung','Cù Lao Dung','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(612,609,'Kế Sách','Kế Sách','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(613,609,'Long Phú','Long Phú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(614,609,'Mỹ Tú','Mỹ Tú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(615,609,'Mỹ Xuyên','Mỹ Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(616,609,'Sóc Trăng','Sóc Trăng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(617,609,'Thạnh Trị','Thạnh Trị','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(618,609,'Vĩnh Châu','Vĩnh Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(619,0,'Sơn La','Sơn La','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(620,619,'Bắc Yên','Bắc Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(621,619,'Mai Sơn','Mai Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(622,619,'Mộc Châu','Mộc Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(623,619,'Mường La','Mường La','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(624,619,'Phù Yên','Phù Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(625,619,'Quỳnh Nhai','Quỳnh Nhai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(626,619,'Sơn La','Sơn La','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(627,619,'Sông Mã','Sông Mã','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(628,619,'Sốp Cộp','Sốp Cộp','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(629,619,'Thuận Châu','Thuận Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(630,619,'Yên Châu','Yên Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(631,0,'Tây Ninh','Tây Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(632,631,'Bến Cầu','Bến Cầu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(633,631,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(634,631,'Dương Minh Châu','Dương Minh Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(635,631,'Gò Dầu','Gò Dầu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(636,631,'Hòa Thành','Hòa Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(637,631,'Tân Biên','Tân Biên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(638,631,'Tân Châu','Tân Châu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(639,631,'Tây Ninh','Tây Ninh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(640,631,'Trảng Bàng','Trảng Bàng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(641,0,'Thái Bình','Thái Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(642,641,'Đông Hưng','Đông Hưng','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(643,641,'Hưng Hà','Hưng Hà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(644,641,'Kiến Xương','Kiến Xương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(645,641,'Quỳnh Phụ','Quỳnh Phụ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(646,641,'Thái Bình','Thái Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(647,641,'Thái Thụy','Thái Thụy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(648,641,'Tiền Hải','Tiền Hải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(649,641,'Vũ Thư','Vũ Thư','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(650,0,'Thái Nguyên','Thái Nguyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(651,650,'Đại Từ','Đại Từ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(652,650,'Định Hóa','Định Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(653,650,'Đồng Hỷ','Đồng Hỷ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(654,650,'Phổ Yên','Phổ Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(655,650,'Phú Bình','Phú Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(656,650,'Phú Lương','Phú Lương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(657,650,'Sông Công','Sông Công','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(658,650,'Thái Nguyên','Thái Nguyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(659,650,'Võ Nhai','Võ Nhai','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(660,0,'Thanh Hóa','Thanh Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(661,660,'Bá Thước','Bá Thước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(662,660,'Bỉm Sơn','Bỉm Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(663,660,'Cẩm Thủy','Cẩm Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(664,660,'Đông Sơn','Đông Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(665,660,'Hà Trung','Hà Trung','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(666,660,'Hậu Lộc','Hậu Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(667,660,'Hoằng Hóa','Hoằng Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(668,660,'Lang Chánh','Lang Chánh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(669,660,'Mường Lát','Mường Lát','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(670,660,'Ngọc Lặc','Ngọc Lặc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(671,660,'Như Thanh','Như Thanh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(672,660,'Như Xuân','Như Xuân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(673,660,'Nông Cống','Nông Cống','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(674,660,'Quan Hóa','Quan Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(675,660,'Quan Sơn','Quan Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(676,660,'Quảng Xương','Quảng Xương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(677,660,'Sầm Sơn','Sầm Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(678,660,'Thạch Thành','Thạch Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(679,660,'Thanh Hóa','Thanh Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(680,660,'Thiệu Hóa','Thiệu Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(681,660,'Thọ Xuân','Thọ Xuân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(682,660,'Thường Xuân','Thường Xuân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(683,660,'Tĩnh Gia','Tĩnh Gia','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(684,660,'Triệu Sơn','Triệu Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(685,660,'Vĩnh Lộc','Vĩnh Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(686,660,'Yên Định','Yên Định','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(687,0,'Thừa Thiên–Huế','Thừa Thiên–Huế','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(688,687,'A Lưới','A Lưới','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(689,687,'Huế','Huế','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(690,687,'Hương Thủy','Hương Thủy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(691,687,'Hương Trà','Hương Trà','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(692,687,'Nam Đông','Nam Đông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(693,687,'Phong Điền','Phong Điền','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(694,687,'Phú Lộc','Phú Lộc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(695,687,'Phú Vang','Phú Vang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(696,687,'Quảng Điền','Quảng Điền','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(697,0,'Tiền Giang','Tiền Giang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(698,697,'Cái Bè','Cái Bè','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(699,697,'Cai Lậy','Cai Lậy','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(700,697,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(701,697,'Chợ Gạo','Chợ Gạo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(702,697,'Gò Công','Gò Công','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(703,697,'Gò Công Dông','Gò Công Dông','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(704,697,'Gò Công Tây','Gò Công Tây','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(705,697,'Mỹ Tho','Mỹ Tho','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(706,697,'Tân Phước','Tân Phước','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(707,0,'Trà Vinh','Trà Vinh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(708,707,'Càng Long','Càng Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(709,707,'Cầu Kè','Cầu Kè','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(710,707,'Cầu Ngang','Cầu Ngang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(711,707,'Châu Thành','Châu Thành','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(712,707,'Duyên Hải','Duyên Hải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(713,707,'Tiểu Cần','Tiểu Cần','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(714,707,'Trà Cú','Trà Cú','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(715,707,'Trà Vinh','Trà Vinh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(716,0,'Tuyên Quang','Tuyên Quang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(717,716,'Chiêm Hóa','Chiêm Hóa','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(718,716,'Hàm Yên','Hàm Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(719,716,'Nà Hang','Nà Hang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(720,716,'Sơn Dương','Sơn Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(721,716,'Tuyên Quang','Tuyên Quang','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(722,716,'Yên Sơn','Yên Sơn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(723,0,'Vĩnh Long','Vĩnh Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(724,723,'Bình Minh','Bình Minh','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(725,723,'Bình Tân','Bình Tân','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(726,723,'Long Hồ','Long Hồ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(727,723,'Mang Thít','Mang Thít','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(728,723,'Tâm Bình','Tâm Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(729,723,'Trà Ôn','Trà Ôn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(730,723,'Vĩnh Long','Vĩnh Long','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(731,723,'Vũng Liêm','Vũng Liêm','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(732,0,'Vĩnh Phúc','Vĩnh Phúc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(733,732,'Bình Xuyên','Bình Xuyên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(734,732,'Lập Thạch','Lập Thạch','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(735,732,'Phúc Yên','Phúc Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(736,732,'Tam Đảo','Tam Đảo','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(737,732,'Tam Dương','Tam Dương','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(738,732,'Vĩnh Tường','Vĩnh Tường','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(739,732,'Vĩnh Yên','Vĩnh Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(740,732,'Yên Lạc','Yên Lạc','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(741,0,'Yên Bái','Yên Bái','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(742,741,'Lục Yên','Lục Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(743,741,'Mù Cang Chải','Mù Cang Chải','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(744,741,'Nghĩa Lộ','Nghĩa Lộ','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(745,741,'Trạm Tấu','Trạm Tấu','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(746,741,'Trấn Yên','Trấn Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(747,741,'Văn Chấn','Văn Chấn','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(748,741,'Văn Yên','Văn Yên','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(749,741,'Yên Bái','Yên Bái','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL),
	(750,741,'Yên Bình','Yên Bình','admin@gmail.com','admin@gmail.com','2018-11-07 08:18:44','2018-11-07 08:18:44',NULL);

/*!40000 ALTER TABLE `provinces` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table seo
# ------------------------------------------------------------

DROP TABLE IF EXISTS `seo`;

CREATE TABLE `seo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `table_name` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `keywords` text,
  `description` text,
  `og_title` text,
  `og_description` text,
  `og_type` text,
  `og_url` text,
  `og_image` text,
  `language` varchar(10) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_user_id` int(10) unsigned NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_user_id` int(10) unsigned NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `deleted_user_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` int(11) DEFAULT NULL,
  `sex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `career` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `work_place` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `phone`, `sex`, `career`, `city`, `district`, `work_place`, `remember_token`, `created_at`, `updated_at`)
VALUES
	(1,'Admin','admin@gmail.com',NULL,'$2y$10$ZA9uaFSkQ2b4aqLTyXSaxOGXhcKTRDJs.EPG9eJE.hozF5k2.lET.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-02 02:49:07','2019-12-02 02:49:07'),
	(2,'asd','user@zaitenllc.com',NULL,'Aa,123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 03:21:03','2019-12-10 03:21:03'),
	(3,'asd','aaa@xxx.com',NULL,'12345678',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 03:24:38','2019-12-10 03:24:38'),
	(4,'thanh','nguyentrongthanh260196b@gmail.com',NULL,'Aa,123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:14:51','2019-12-10 04:14:51'),
	(6,'asd','nguyentrongthanh2601961b@gmail.com',NULL,'yuipobmt',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:26:26','2019-12-10 04:26:26'),
	(7,'asd','nguyentrongthanh260196c@gmail.com',NULL,'Aa,123456',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:34:09','2019-12-10 04:34:09'),
	(8,'asd','user12@zaitenllc.com','2019-12-10 04:36:14','$2y$10$gqnr4XaefpzNt8QsOIj9Su37HPv3u.gNZJAe2X15fFIwSTUQfmiWq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:35:56','2019-12-10 04:36:14'),
	(9,'asd','nguyentrongthanh260196b@gmail.co1m',NULL,'$2y$10$VMf2Ny1weu3pJsn/YXq0HO4FTuc.sMkeyZTq8xZo0ZQElV1Al6ML.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:45:45','2019-12-10 04:45:45'),
	(10,'asd','nguyentrongthanh260196b@gmail.com1',NULL,'$2y$10$yrPtsK6P3zheCiqAGmtSze.FEBUvZVkdxMSq/EKxaWlWP56gi/v36',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:49:46','2019-12-10 04:49:46'),
	(11,'asd','user@zaitenllc.com12',NULL,'$2y$10$isAYVph3flA2kV2nFRMwXOZCRdzfs5UplprTfPjtG5FCZoJUBYthu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:50:49','2019-12-10 04:50:49'),
	(12,'asd','user@zaitenllc.com3',NULL,'$2y$10$lBkS9AUJ6tbq9a/kd8igdeg7RfrNnC5I.1JeplJgrlHLHXeDgoX66',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:52:04','2019-12-10 04:52:04'),
	(14,'asd','nguyentrongthanh260196b@gmail.com12',NULL,'$2y$10$tnr2yV9f38L1eCDmEl9llOnYYdqyupnRTmuDTB0aSmcKGLleJr/4i',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:53:59','2019-12-10 04:53:59'),
	(15,'sf','nguyentrongthanh260196b@gmail.com0',NULL,'$2y$10$x5.95HGugtFcUMy5vpufSuomCfh0VBDu7f.73xdu8T...VLJ5Rmje',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 04:55:02','2019-12-10 04:55:02'),
	(16,'asd','nguyentrongthanh260196b@gmail.com4',NULL,'$2y$10$te2spaP5OJZ/g7YAGiTZ8ehVm4ARGYtyWPtHFVZYJqZpteHnCv2Xm',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 06:34:28','2019-12-10 06:34:28'),
	(17,'asd','nguyentrongthanh260196b@gmail.com5','2019-12-10 06:39:00','$2y$10$40X1BOkaBUSxKA8nw1dCK.jhUnhek304mxHaxZ2obcXfgLVTNBTr.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 06:37:37','2019-12-10 06:39:00'),
	(18,'ads','nguyentrongthanh260196b@gmail.com6','2019-12-10 06:40:24','$2y$10$jP3Jf6cNBM7rnXk/MlqEGuMEj71VItvSK2yYwbMUmt6kA2miZnh3O',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 06:39:37','2019-12-10 06:40:24'),
	(19,'123','nguyentrongthanh260196b@gmail.com7',NULL,'$2y$10$N3Or8rSqtdD3xNsndGkJBuaNv5Mig21t5EWVa5HY0PML9qDi6yzv.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 06:42:49','2019-12-10 06:42:49'),
	(20,'asd','user@zaitenllc.com13','2019-12-10 07:00:59','$2y$10$mIPdnylE2jjSU7Vfl6TE8uMzNZMRbyKQRh5lfwK8DQR7cLNp0s8hC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 06:59:58','2019-12-10 07:00:59'),
	(21,'asd','nguyentrongthanh260196b@gmail.com11','2019-12-10 07:02:03','$2y$10$Xw40zAGpkrpoVgCJkkVkvuN5SeWzGMFRCrh61gFrMeaIHR3yvqOk2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 07:01:50','2019-12-10 07:02:03'),
	(23,'asdas','nguyentrongthanh260196b@gmail.com13','2019-12-10 07:12:52','$2y$10$zLH2bLZENMgLdcURXT82deArDmwwvXIPvBoYsvmCrG./oIj4z6xsi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 07:11:20','2019-12-10 07:12:52'),
	(24,'asd','nguyentrongthanh260196b@gmail.com14','2019-12-10 07:15:50','$2y$10$LZ7S9efvhnrsWe9XUAxWdOG..mKvj1swBMUPGpd97NgSp6aj3GeW.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2019-12-10 07:15:42','2019-12-10 07:15:50');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
